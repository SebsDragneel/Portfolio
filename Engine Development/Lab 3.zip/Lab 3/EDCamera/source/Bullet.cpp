#include <windows.h>

#include "gl.h"
#include "glu.h"
#include "glut.h"
#include "extgl.h"

#include "Bullet.h"
#include "EDCommon.h"
#include "EDApp.h"


void CBullet::Update(float fTime)
{
	m_fAge += fTime;
	m_fTrailTimer += fTime;


	// Update the bullet trail...
	if( m_fTrailTimer >= 0.0666f )
	{
		memmove( m_trail, &m_trail[1], sizeof(vec3f) * (TRAILLEN-1) );
		m_trail[TRAILLEN-1] = m_Matrix.axis_pos;
		m_fTrailTimer = 0.0f;
	}

	if (m_fTrailTimer >= 30.0f)
	{
		Kill();
	}

	m_Matrix.translate_pre(0, 0, fTime * 0.5f);

	if (EDApp::GetInstance().m_pTarget != NULL)
	{
		TurnTo(m_Matrix, EDApp::GetInstance().m_pTarget->GetPosition(), fTime);
	}

	for (unsigned int i = 0; i < 20; i++)
	{

		vec3f D = m_Matrix.axis_pos - EDApp::GetInstance().m_Targets[i].GetPosition();

		if (D.magnitude() < (m_fRadius + EDApp::GetInstance().m_Targets[i].GetRadius()))
		{
			Kill();
			EDApp::GetInstance().m_Targets[i].Spin();
		}

	}


}

void CBullet::Render(void)
{
	float fScale = (rand() % 100) / 100.0f;

	GLUquadric * pQuad = gluNewQuadric();

	gluQuadricTexture( pQuad, true );

	glColor4f( 0.0f, 1.0f, 1.0f, 1.0f );

	glPushMatrix();
		glMultMatrixf( m_Matrix.ma );
		gluSphere( pQuad, fScale * 0.0625f, 15, 15 );
	glPopMatrix();

	glLineWidth( 2.0f );
	glBegin( GL_LINE_STRIP );
		for( unsigned int i = 0; i < TRAILLEN; ++i )
		{
			float fTemp = i/(float)TRAILLEN;

			glColor4f( fTemp*fTemp*fTemp*fTemp, fTemp*fTemp, fTemp*fTemp, fTemp );
			glVertex3fv( m_trail[i].v );
		}
	glEnd();
	glLineWidth( 1.0f );

	gluDeleteQuadric( pQuad );
}