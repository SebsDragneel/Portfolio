#include <windows.h>

#include "gl.h"
#include "glu.h"
#include "glut.h"
#include "extgl.h"

#include "EDApp.h"
#include "EDCommon.h"
#include "Crosshair.h"

unsigned int CCrosshair::m_uiRefCount = 0;
unsigned int CCrosshair::m_uiDrawList = 0;

void CCrosshair::Update(float fTime)
{
	// Reset the selected target to NULL
	EDApp::GetInstance().m_pTarget = NULL;
	m_Matrix = EDApp::GetInstance().m_Buggy.m_Frames[CBuggy::GUN].GetWorldMat();
	 m_Matrix.translate_pre(0.0f, 0.0f,25.0f);



	 EDTriangle *pTris;
	 unsigned int pTriCount;
	 vec3f Start = EDApp::GetInstance().m_Buggy.m_Frames[CBuggy::GUN].GetWorldMat().axis_pos;
	 vec3f End = m_Matrix.axis_pos;
	 EDApp::GetInstance().GetTriangles(&pTris, &pTriCount, Start, End);
	 vec3f Out;
	 unsigned int Index;
	 if (EDApp::GetInstance().LineSegment2Triangle(Out, Index, pTris, pTriCount, Start, End))
	 {
		 m_Matrix.axis_pos = Out;
	 }

	 for (unsigned int i = 0; i < 20; i++)
	 {
		 vec3f Ray = EDApp::GetInstance().m_Targets[i].GetPosition() - EDApp::GetInstance().m_Buggy.m_Frames[CBuggy::GUN].GetWorldMat().axis_pos;
		 float DotResult = dot_product(EDApp::GetInstance().m_Buggy.m_Frames[CBuggy::GUN].GetWorldMat().axis_z, Ray);

		 if (DotResult < 0)
			 continue;
		
		vec3f Nprime = EDApp::GetInstance().m_Buggy.m_Frames[CBuggy::GUN].GetWorldMat().axis_z * DotResult;

		vec3f ClosestPoint = Nprime + EDApp::GetInstance().m_Buggy.m_Frames[CBuggy::GUN].GetWorldMat().axis_pos;

		float Distance = (EDApp::GetInstance().m_Targets[i].GetPosition() - ClosestPoint).magnitude();

		if (Distance < EDApp::GetInstance().m_Targets[i].GetRadius())
		{
			
			EDApp::GetInstance().m_pTarget = &EDApp::GetInstance().m_Targets[i];
			m_Matrix = EDApp::GetInstance().m_pTarget->GetMatrix();
			break;
		}
	 }

	 
	 delete[] pTris;


}

CCrosshair::CCrosshair(void)
{
	m_fRadius = 0.375f;

	if( m_uiRefCount == 0 )
	{
		m_uiDrawList = glGenLists(1);

		GLUquadric *pQuad = gluNewQuadric();
		glNewList( m_uiDrawList, GL_COMPILE );
			// innner ring
			gluCylinder( pQuad, 0.125f, 0.125f, 0.125f, 15, 15 );

			glPushMatrix();
				glTranslatef( 0.0f, 0.0f, 0.125f );
				gluDisk( pQuad, 0.0f, 0.125f, 15, 15 );
			glPopMatrix();
			glPushMatrix();
				glRotatef( 180.0f, 0.0f, 1.0f, 0.0f );
				gluDisk( pQuad, 0.0f, 0.125f, 15, 15 );
			glPopMatrix();

			// outer ring
			gluCylinder( pQuad, 0.375f, 0.375f, 0.125f, 15, 15 );
			gluCylinder( pQuad, 0.25f, 0.25f, 0.125f, 15, 15 );

			glPushMatrix();
				glTranslatef( 0.0f, 0.0f, 0.125f );
				gluDisk( pQuad, 0.25f, 0.375f, 15, 15 );
			glPopMatrix();
			glPushMatrix();
				glRotatef( 180.0f, 0.0f, 1.0f, 0.0f );
				gluDisk( pQuad, 0.25f, 0.375f, 15, 15 );
			glPopMatrix();
		glEndList();
		gluDeleteQuadric(pQuad);
	}
	
	++m_uiRefCount;
	m_Matrix.make_identity();
}

CCrosshair::~CCrosshair()
{
	--m_uiRefCount;

	if( m_uiRefCount == 0 )
	{
		glDeleteLists( m_uiDrawList, 1 );
		m_uiDrawList = 0;
	}
}

void CCrosshair::Render(void)
{
	glColor3f( 0.5f, 0.5f, 0.5f );	
	//glDisable( GL_LIGHTING );
	glDisable( GL_CULL_FACE );

	glPushMatrix();
		glMultMatrixf( m_Matrix.ma );
		glCallList( m_uiDrawList );
	glPopMatrix();
	//glEnable( GL_LIGHTING );
	glEnable( GL_CULL_FACE );
}

