#pragma once

#include "vec3.h"
#include <vector>

// EDMesh
//
// Contains all the data for a collision mesh.
struct EDMesh
{
	// Vertex indices. 3 Per triangle.
	std::vector<unsigned int> m_VertIndices;
	// Vertices
	std::vector<vec3f> m_Vertices;
	// Centroids of all triangles
	std::vector<vec3f> m_Centroids;
	// Normals of all triangles
	std::vector<vec3f> m_TriNormals;
};