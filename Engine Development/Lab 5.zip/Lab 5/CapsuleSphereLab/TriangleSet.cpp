#include "TriangleSet.h"
#include "EDMesh.h"
#include <assert.h>
#include <Windows.h>

TriangleSet TriangleSet::generate(const EDMesh* mesh)
{
	TriangleSet result(mesh);

	if (result.m_pMesh)
	{
		for (unsigned int i = 0, j = 0; i < mesh->m_VertIndices.size(); i += 3, ++j)
			result.m_TriIndices.push_back(j);
	}

	return result;
}

namespace BVH
{
	// Specializations of CollectionMethods for BVH::Tree<TriangleSet>
	namespace CollectionMethods
	{
		size_t GetCount(TriangleSet* collection)
		{
			// Get the current number of triangles in the TriangleSet "collection"
			return collection->m_TriIndices.size();
		}

		template<>
		size_t GetStopCount<TriangleSet>()
		{
			// Get number of triangles to stop splitting at
			return 1;
		}

		void OnNodeDestruct(TriangleSet* collection)
		{
			// Containing node is being destroyed, so delete the TriangleSet
			delete collection;
		}

		AABB ComputeAABB(TriangleSet* collection)
		{
			// TODO:
			// Calculate the AABB of the vertices of the TriangleSet and return the result.
			// See the comment above "m_TriIndices" in "TriangleSet.h"

			vec3f Min = vec3f( FLT_MAX, FLT_MAX, FLT_MAX);
			vec3f Max = vec3f(-FLT_MAX, -FLT_MAX, -FLT_MAX);

			
			for (unsigned int  i = 0; i < collection->m_TriIndices.size(); i++)
			{
				for (unsigned int j = 0; j < 3; j++)
				{
					for (unsigned int k = 0; k < 3; k++)
					{
						float Vec = collection->m_pMesh->m_Vertices[collection->m_pMesh->m_VertIndices[collection->m_TriIndices[i] * 3 + j]].v[k];

						if (Vec < Min.v[k])
							Min.v[k] = Vec;

						if (Vec > Max.v[k])
							Max.v[k] = Vec;
					}
				}
			}
			AABB result;
			result.max = Max;
			result.min = Min;	

			return result;
		}

		void PartitionCollection(TriangleSet* in, TriangleSet*& resultOne, TriangleSet*& resultTwo)
		{
			// TODO:
			// Partition the TriangleSet "in" into two sets.
			// Use the "Splitting Along Object Mean" method from lecture. "Bounding Volume Hierarchies", slides 45-51.
			vec3f Centroid = vec3f(0, 0, 0);


			AABB Box;


			vec3f Min = vec3f(FLT_MAX, FLT_MAX, FLT_MAX);
			vec3f Max = vec3f(-FLT_MAX, -FLT_MAX, -FLT_MAX);
			Box.min = Min;
			Box.max = Max;

			vec3f &mMin = Box.min;
			vec3f &mMax = Box.max;

			const std::vector<vec3f>& CS = in->m_pMesh->m_Centroids;


			for (unsigned int i = 0; i < in->m_TriIndices.size(); i++)
			{
				Centroid += in->m_pMesh->m_Centroids[in->m_TriIndices[i]];

				for (unsigned int j = 0; j < 3; j++)
				{
					mMin.v[j] = min(mMin.v[j], in->m_pMesh->m_Centroids[in->m_TriIndices[i]].v[j]);
					mMax.v[j] = max(mMax.v[j], in->m_pMesh->m_Centroids[in->m_TriIndices[i]].v[j]);
				}
			}
			Centroid /= in->m_TriIndices.size();

			std::vector<unsigned int> R1I;

			resultTwo = new TriangleSet(in->m_pMesh);

			int SAxis = 2;

			float Dx = Box.max.x - Box.min.x;
			float Dy = Box.max.y - Box.min.y;
			float Dz = Box.max.z - Box.min.z;

			float M = max(max(Dx, Dy), Dz);

			if (M == Dx)
				SAxis = 0;
			else if (M == Dy)
				SAxis = 1;
			else
				SAxis = 2;

			for (unsigned int i = 0; i < in->m_TriIndices.size(); i++)
			{

				const unsigned int triIndex = in->m_TriIndices[i];
				const vec3f& C = in->m_pMesh->m_Centroids[triIndex];

				if (C.v[SAxis] > Centroid.v[SAxis])
					R1I.push_back(triIndex);
				else
					resultTwo->m_TriIndices.push_back(triIndex);
			}

			resultOne = in;
			resultOne->m_TriIndices = R1I;

			/*delete resultTwo;*/
			// You will only need to allocate one new TriangleSet for resultTwo.
			// "in" can be reused for resultOne.
		}
	}
}
