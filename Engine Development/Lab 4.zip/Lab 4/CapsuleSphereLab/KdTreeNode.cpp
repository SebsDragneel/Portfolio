#include "KdTreeNode.h"
#include "KdTree.h"

void KdTreeInternalNode::Traverse( TraversalData* pData )
{
	 //Use the PerSplitFunc from the TraversalData to determine the direction
	 //of the traversal through the tree from this node.
	 //If the result is 0, traverse only on the left child.

	int thing = pData->m_PerSplitFunc(this, pData);

	if (thing == 0)
		this->m_LeftChild->Traverse(pData);
	 //If the result is 1, traverse only on the right child.
	else if (thing == 1)
		this->m_RightChild->Traverse(pData);
	 //If the result is 2, traverse on the left and then right child.
	else if (thing == 2)
	{
		this->m_LeftChild->Traverse(pData);
		this->m_RightChild->Traverse(pData);
	}
	 //If the result is 3, traverse on the right and then left child.
	else if (thing == 3)
	{
		this->m_RightChild->Traverse(pData);
		this->m_LeftChild->Traverse(pData);
	}

}

void KdTreeLeafNode::Traverse( TraversalData* pData )
{
	// The PerLeafFunc of the TraversalData should be used on this node. 
	// If the PerLeafFunc is null OR if the PerLeafFunc returns true,

	if (pData->m_PerLeafFunc == NULL || pData->m_PerLeafFunc(this, pData))
	{
		// check the PerObjectFunc pointer, and if valid call the 
		if (pData->m_PerObjectFunc != NULL)
		{
			// PerObjectFunc on each object in this leaf
			for each (SceneObject * var in this->m_OverlappingObjects)
			{
				pData->m_PerObjectFunc(var, pData);
			}
		}
	}
}

