﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_2__7
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("What color Popsicle do you want from the freezer?");
            Console.WriteLine("-------------------");
            Console.WriteLine("1- Red");
            Console.WriteLine("2- Green");
            Console.WriteLine("3- blue");
            Console.WriteLine("13- Aquamabrown");
            Console.WriteLine("-------------------");

            Console.WriteLine("Choose a number whisely: ");
            string NUMBER = Console.ReadLine();
            int number = Convert.ToInt32(NUMBER);

            if (number == 1)
                Console.WriteLine("Ah! Red cherry, good choice");
            else if (number == 2)
                Console.WriteLine("Ah! better try it if it's not frozen");
            else if (number == 3)
                Console.WriteLine("Ah! better try it if it's frozen ");
            else if(number == 13)
                Console.WriteLine("Uh... I don't know how long that's been in there...");
            else
                Console.WriteLine("Are you stupid? There are only 4 options. Computer");

        }
    }
}
