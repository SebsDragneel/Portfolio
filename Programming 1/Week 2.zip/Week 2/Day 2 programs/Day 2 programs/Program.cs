﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FSPG;

namespace Day_2_programs
{
    class Program
    {
        static void Main(string[] args)
        {
            int randomnumber;
            int modresult;

            randomnumber = Utility.Rand();
            modresult = randomnumber % 2;

            Console.WriteLine("Press ENTER to flip a coin");

            if (modresult == 0) 
            Console.WriteLine("Heads");
            else
            Console.WriteLine("Tails");

            Console.SetCursorPosition(0, Console.WindowHeight);
            Console.WriteLine("Press ENTER to continue...");
            Console.ReadLine();




        }
    }
}
