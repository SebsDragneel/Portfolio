﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Activity_2
{
    class Program
    {
        static void Main(string[] args)
        {
            string name;
            string AGE;
            int age;
            string SEX;
            char sex;

            Console.WriteLine("Please enter your name:");
            name = Console.ReadLine();

            Console.WriteLine("Please enter your age:");
            AGE = Console.ReadLine();
            age = Convert.ToInt32(AGE);

            Console.WriteLine("Please enter your Sex:");
            SEX = Console.ReadLine();
            sex = Convert.ToChar(SEX);

            if (sex != 'm' && sex != 'M' && sex != 'f' || sex != 'F')
            {
              ;
            }
            if (sex == 'm' || sex == 'M')
                Console.WriteLine("Mr. " + name + " You are now President of the world, welcome Doctor");
           else if (sex == 'f' || sex == 'F')
                Console.WriteLine("Ms. " + name + " You are now President of the world, welcome Doctor");
           
            else
            {
                Console.WriteLine("Fuck you for doing it wrong");
            }
            

        }
    }
}
