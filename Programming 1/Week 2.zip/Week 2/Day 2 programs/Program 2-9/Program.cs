﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_2_9
{
    class Program
    {
        enum difficult

        {
            Easy,
            Medium,
            Hard,
            Expert,
        }

        static void Main(string[] args)
        {
            difficult mode;

            Console.WriteLine("Dificulty Level");
            Console.WriteLine("-------------------");
            Console.WriteLine("0- Easy");
            Console.WriteLine("1- Medium");
            Console.WriteLine("2- Hard");
            Console.WriteLine("3- Expert");
            Console.WriteLine("-------------------");

            Console.WriteLine("Choose a number wisely: ");
            string NUMBER = Console.ReadLine();
             mode = (difficult)Convert.ToInt32(NUMBER);

            switch (mode)
            {
                case difficult.Easy:
                    Console.WriteLine("Use 3 buttons and the strum");

                    break;
                case difficult.Medium:
                    Console.WriteLine("Use 4 buttons and the strum");
                    break;
                case difficult.Hard:
                    Console.WriteLine("Use 5 buttons and the strum");
                    break;
                case difficult.Expert:
                    Console.WriteLine("Use 5 buttons and the strum in a fast pase");
                    break;
                default:
                    break;
            }

        }
    }
}
