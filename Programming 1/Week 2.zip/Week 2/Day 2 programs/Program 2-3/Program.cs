﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_2_3
{
    class Program
    {
        static void Main(string[] args)
        {
            int score = 0;

            Console.WriteLine("True or false exam, T(t) or F(f)");


            Console.WriteLine("Question 1:");
            Console.WriteLine("\"elseif\" is a keyword in C#:");
            string ANSWER1 = Console.ReadLine();
            char answer1 = Convert.ToChar(ANSWER1);

            if (answer1 == 'f' || answer1 == 'F')
            { Console.WriteLine("Correct, your score is 1.");
                score= score + 1;
                    }
            else if (answer1 == 't' || answer1 == 'T')
                Console.WriteLine("Your answer is wrong");
            else
                Console.WriteLine("Your answer is wrong, only use T or F");



            Console.WriteLine("Question 2:");
            Console.WriteLine("Algorithms are usually written in C#:");
            string ANSWER2 = Console.ReadLine();
            char answer2 = Convert.ToChar(ANSWER2);

            if (answer1 == 'f' || answer1 == 'F')
            {
                Console.WriteLine("Your answer is Correct, +1 points");
                score = score + 1;
            }
            else if (answer1 == 't' || answer1 == 'T')
                Console.WriteLine("Incorrect!, AAlgorithms are language independent!");
            else
                Console.WriteLine("Your answer is wrong, only use T or F");

            Console.WriteLine("Question 3:");
            Console.WriteLine("Are you not gay?");
            string ANSWER3 = Console.ReadLine();
            char answer3 = Convert.ToChar(ANSWER3);

            if (answer1 == 'f' || answer1 == 'F')
            {
                Console.WriteLine("Your answer is Correct, +1 points");
                score = score + 1;
            }
            else if (answer1 == 't' || answer1 == 'T')
                Console.WriteLine("Incorrect!, because I want to");
            else
                Console.WriteLine("Your answer is wrong, only use T or F");

            Console.WriteLine("Your score is " + score + "of 3");



        }
    }
}
