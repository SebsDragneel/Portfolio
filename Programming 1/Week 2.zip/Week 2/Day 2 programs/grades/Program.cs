﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FSPG;
namespace grades
{
    class Program
    {
        static void Main(string[] args)
        {
            int modresult;
            string question;

           

            Console.WriteLine("Enter your grade:");
            question = Console.ReadLine();
            modresult = Convert.ToInt32(question);

            if (modresult >= 90)
                Console.WriteLine(" You have an A");
            else if (modresult >= 80 && modresult <= 89)
                Console.WriteLine("You have a B");
            else if (modresult >= 70 && modresult <= 79)
                Console.WriteLine("You have a C");
            else if (modresult >= 60 && modresult <= 69)
                Console.WriteLine("You have a D");
            else if (modresult >= 50 && modresult <= 59)
                Console.WriteLine("You have an E");
            else if (modresult <= 49)
                Console.WriteLine("You have a F");
            


            Console.SetCursorPosition(0, Console.WindowHeight);
            Console.WriteLine("Press ENTER to continue...");
            Console.ReadLine();
        }
    }
}
