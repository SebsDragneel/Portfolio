﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace program_2_1
{
    class Program
    {
        static void Main(string[] args)
        {
            string name;
            string AGE;
            int age;

            Console.WriteLine("Please enter your name:");
            name = Console.ReadLine();

            Console.WriteLine("Please enter your age:");
            AGE = Console.ReadLine();
            age = Convert.ToInt32(AGE);

            if (age >= 18)
                Console.WriteLine("Please leave, this content is inapropiate for cry babies");
            else
                Console.WriteLine("Elmo knows where you live....");
        }
    }
}
