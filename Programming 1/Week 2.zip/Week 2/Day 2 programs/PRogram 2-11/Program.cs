﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FSPG;
namespace PRogram_2_11
{
    class Program
    {
        enum Character

        {
            SwordsmanExpert,
            ProyectileExpert,
            CloseCombatExpert,
            MagicExpert,
        }
        static void Main(string[] args)
        {
            Character Char;

            int hi = Utility.Rand();
            int HP = Utility.Rand() % 101;
            int MP = Utility.Rand() % 101;

            Console.WriteLine("Press Enter to roll a Random Charecter...");
            Console.ReadLine();
            hi = hi % 5;
            Char = (Character)Convert.ToInt32(hi);

            

            switch (Char)
            {

                case Character.SwordsmanExpert:
                    Console.WriteLine("Type: SwordsmanExpert");
                    Console.WriteLine("HP: " + HP);
                    Console.WriteLine("MP: " + MP);

                    break;
                case Character.ProyectileExpert:
                    Console.WriteLine("Type: ProyectileExpert");
                    Console.WriteLine("HP: " + HP);
                    Console.WriteLine("MP: " + MP);
                    break;
                case Character.CloseCombatExpert:
                    Console.WriteLine("Type: CloseCombatExpert");
                    Console.WriteLine("HP: " + HP);
                    Console.WriteLine("MP: " + MP);
                    break;
                case Character.MagicExpert:
                    Console.WriteLine("Type: MagicExpert");
                    Console.WriteLine("HP: " + HP);
                    Console.WriteLine("MP: " + MP);
                    break;
                default:

                    break;
            }
        }
        
        }
    }
}
