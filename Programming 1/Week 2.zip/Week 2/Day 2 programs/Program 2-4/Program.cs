﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_2_4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter an even number:");
            string NUMBER = Console.ReadLine();
            int number = Convert.ToInt32(NUMBER);

            if (number % 2 == 0)
            {
                Console.WriteLine("Nice!");
            }
            else
                Console.WriteLine("Booooo!");
        }
    }
}
