﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FSPG;
namespace Program_2_5
{
    class Program
    {
        static void Main(string[] args)
        {
           
   


           int a = Utility.Rand();
            int b = Utility.Rand();
            int c = Utility.Rand();
            
            

            Console.WriteLine("Please enter a divisor:");
            string divisor = Console.ReadLine();
            int w = Convert.ToInt32(divisor);

            int x = a / w;
          int y = b / w;
            int z = c / w;

            if (a == x*w  )
            {
                Console.WriteLine(a + " - yes");
            }
            else
                Console.WriteLine(a+ " - no");

            if (b == y * w)
            {
                Console.WriteLine(b + " - yes");
            }
            else
                Console.WriteLine(b + " - no");

            if (c == z * w)
            {
                Console.WriteLine(c + " - yes");
            }
            else
                Console.WriteLine(c + " - no");




        }
    }
}
