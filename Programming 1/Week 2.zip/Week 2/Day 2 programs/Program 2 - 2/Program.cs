﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_2___2
{
    class Program
    {
        static void Main(string[] args)
        {
            

            Console.WriteLine("Please enter your Pacific time with a (.) instead of (:) if you want the Eastern time:");
           string TIME = Console.ReadLine();
           double time = Convert.ToDouble(TIME);

            if (time >= 1.00 && time <= 12.59)
            {
                double easterntime = time + 3.00;

                Console.WriteLine("Your easter time is: " + easterntime);
            }
            else
                Console.WriteLine("That is not a valid time you moron 0j0... ");

        }
    }
}
