﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_2_10
{
    class Program
    {
        static void Main(string[] args)
        {
            string swords;
            string shields;
            string potions;
            int sw;
            int gold1;
            int gold2;
            int gold3;
                
            Console.WriteLine("Welcome to Gentle Jerry's Generic Goods!");
            Console.WriteLine("----------------------------------------");

            Console.WriteLine("Sword - 5 gold each");
            Console.WriteLine("Shield - 8 gold each");
            Console.WriteLine("Potion - 3 gold per ounce");


            Console.WriteLine("----------------------------------------");
            Console.WriteLine("How many swords would you like?");
            swords = Console.ReadLine();
            sw = Convert.ToInt32(swords);
            gold1 = sw * 5;

            Console.WriteLine("----------------------------------------");
            Console.WriteLine("How many shields would you like?");
            shields = Console.ReadLine();
           int sh = Convert.ToInt32(shields);
            gold2 = sh * 8;

            Console.WriteLine("----------------------------------------");
            Console.WriteLine("How many potions would you like?");
            potions = Console.ReadLine();
           int po = Convert.ToInt32(potions);
            gold3 = po * 3;


            Console.WriteLine("----------------------------------------");
            Console.WriteLine(sw + " Swords      " + gold1 + " gold.");
            Console.WriteLine(sh + " Shields      " + gold2 + " gold.");
            Console.WriteLine(po + " Ounces of potion      " + gold3 + " gold.");

            int subtotal = gold1 + gold2 + gold3;
            Console.WriteLine("----------------------------------------");
            Console.WriteLine("Subtotal:      " + subtotal + " gold");
            double tax = subtotal * 0.05;
            Console.WriteLine("5 % Sales Tax      " + tax + " gold");
            Console.WriteLine("----------------------------------------");
            double Total = subtotal + tax;
            Console.WriteLine("Total      " + Total + " gold");

        }
    }
}
