﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FSPG;
namespace Program_2_12
{
    class Program
    {
        static void Main(string[] args)
        {
            int hi = Utility.Rand() % 50;
            int MP = Utility.Rand() % 50;
            int A = Utility.Rand() % 50;
            int B = Utility.Rand() % 50;
            int C = Utility.Rand() % 50;
            int D = Utility.Rand() % 50;
            int E = Utility.Rand() % 50;
            int F = Utility.Rand() % 50;
            int G = Utility.Rand() % 50;
            int H = Utility.Rand() % 50;
            int I = Utility.Rand() % 50;
            int J = Utility.Rand() % 50;
            int K = Utility.Rand() % 50;
            

            Console.SetCursorPosition(hi, MP);
            Console.WriteLine("Press ENTER to continue...");
            Console.ReadLine();
            Console.Clear();
            Console.SetCursorPosition(A, B);
            Console.WriteLine("Press ENTER to continue...");
            Console.ReadLine();
            Console.Clear();
            Console.SetCursorPosition(D, E);
            Console.WriteLine("Press ENTER to continue...");
            Console.ReadLine();
            Console.Clear();
            Console.SetCursorPosition(F, G);
            Console.WriteLine("Press ENTER to continue...");
            Console.ReadLine();
            Console.Clear();
            Console.SetCursorPosition(H, I);
            Console.WriteLine("Press ENTER to continue...");
            Console.ReadLine();
            Console.Clear();
            Console.SetCursorPosition(J, K);
            Console.WriteLine("Press ENTER to continue...");
            Console.ReadLine();
            Console.Clear();
        }
    }
}
