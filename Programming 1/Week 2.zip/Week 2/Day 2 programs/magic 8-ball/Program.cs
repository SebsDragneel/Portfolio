﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FSPG;
namespace magic_8_ball
{
    class Program
    {
        static void Main(string[] args)
        {
            int modresult;
            string question;

            modresult = Utility.Rand() %7;

            Console.WriteLine("Ask a yes or no question and press ENTER:");
            question = Console.ReadLine();

          if (modresult == 0)
                Console.WriteLine("Hell no");
            else if(modresult == 1)
                Console.WriteLine("no");
            else if (modresult == 2)
                Console.WriteLine("maybe no");
            else if (modresult == 3)
                Console.WriteLine("no");
            else if (modresult == 4)
                Console.WriteLine("I'm going to be neutral in that question");
            else if (modresult == 5)
                Console.WriteLine("maybe yes");
            else if (modresult == 6)
                Console.WriteLine("yes");
            else if (modresult == 7)
                Console.WriteLine("obviously yes");


            Console.SetCursorPosition(0, Console.WindowHeight);
            Console.WriteLine("Press ENTER to continue...");
            Console.ReadLine();
        }
    }
}
