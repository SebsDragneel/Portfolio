﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_2_6
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Quotes on demand");
            Console.WriteLine("-------------------");
            Console.WriteLine("1- Naruto");
            Console.WriteLine("2- Obito Uchiha");
            Console.WriteLine("3- ZombieKid");
            Console.WriteLine("-------------------");

            Console.WriteLine("Choose a number whisely: ");
            string NUMBER = Console.ReadLine();
            int number = Convert.ToInt32(NUMBER);

            if (number == 1)
                Console.WriteLine("I will never go back on my word. Naruto Uzumaki");
            else if (number == 2)
                Console.WriteLine(" Those who don't follow the rules to complete a mission are scum, but those who follow the rules and abandon their friends in the process are worse than scum. Obito Uchiha");
            else if (number == 3)
                Console.WriteLine("I like turtles. ZombieKid ");
            else
                Console.WriteLine("Are you stupid? there are only three options. Computer");

        }
    }
}
