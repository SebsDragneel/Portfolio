﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FSPG;
namespace Day_3_Activity_7
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter a number(1-10):");
            int number = Utility.ReadInt();

            while (!(number > 0 && number < 11))
            {
                Console.WriteLine("Please enter a number(1-10) you idiot:");
                int number2 = Utility.ReadInt();

                if ( number2 > 0 && number2 <11 )
                {

                    Console.WriteLine(" You entered:  " + number2 + " (finally)");
                    break;
                }
                
            }
            Console.WriteLine(" You entered:  " + number);

        }
    }
}
