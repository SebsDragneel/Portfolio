﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_3_8
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter a message to reverse: ");
            string input = Console.ReadLine();



            for (int i = 0; i < input.Length; i++)
            {

                Console.Write(input[i]);

            }

            Console.WriteLine();
            Console.WriteLine("Here is your message reversed:");
            for (int i = input.Length - 1; i >= 0; i--)
            {

                Console.Write(" " + input[i]);
                

            }
        }
    }
}
