﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_3_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Multiples of 10: ");
            Console.WriteLine("");
            for (int i = 1; i <= 100; i ++)
            {
                if (i % 10 != 0)
                    continue;
                Console.Write(i + "  ");
            }
        }
    }
}
