﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FSPG;
namespace Day_3_Activity_6
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] names = {"Mario", "Luigi", "Yoshi", "Peach" };
            Console.WriteLine("Who do you want to search for?");
            string query = Console.ReadLine();
            bool isInList = false;

          
            for (int i = 0; i < names.Length; i++)
            {
                if(names[i] == query)
                {
                    isInList = true;
                    break;
                }
                

            }
            if (isInList)
            {
                Console.WriteLine("Yep");

            }
            else
                Console.WriteLine("Sorry Mario but your Character is in another castle");

            Console.WriteLine("Available Characters: Mario, Luigi, Yoshi, Peach");


        }
    }
}
