﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day_3_Activity_3
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 0; i <= 100; i+=2)
            {
               
                Console.Write( i + "  ");
            }
            //int 1 = 0;
            //while ( 1<= 100)
            //{
             //   Console.Write(i + "  ");
           // }
        }
    }
}
