﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FSPG;
namespace Program_4
{
    class Program
    {
        static void Main(string[] args)
        {
            //int num1, num2, num3, num4, num5;
            int[] list = new int[10];
            for (int i = 0; i < 10; i++)
            {
                list[i] = 0;
            }
           // num1 = Utility.Rand();
           // num2 = Utility.Rand();
           // num3 = Utility.Rand();
           // num4 = Utility.Rand();
           // num5 = Utility.Rand();



           // Console.WriteLine(num1 + "  " + (num1 % 2 == 0));
           // Console.WriteLine(num2 + "  " + (num2 % 2 == 0));
           // Console.WriteLine(num3 + "  " + (num3 % 2 == 0));
           // Console.WriteLine(num4 + "  " + (num4 % 2 == 0));
           // Console.WriteLine(num5 + "  " + (num5 % 2 == 0));
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine(list[i] + "  " + (list[i] % 2 == 0));
                //bool ISEVEN;
                //if (list[i] % 2 == 0)
                
                   // ISEVEN = true;
               
                //else 
                //ISEVEN = false;
            }
            }

        }
    }
