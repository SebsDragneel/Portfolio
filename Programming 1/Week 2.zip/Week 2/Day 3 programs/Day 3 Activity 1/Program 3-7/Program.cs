﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FSPG;
namespace Program_3_7
{
    class Program
    {
        static void Main(string[] args)
        {
            
            int[] list = new int[10];
            for (int i = 0; i < 10; i++)
            {
                list[i] = Utility.Rand() % 101 + 1 ;
                Console.Write(list[i] + " " );
                

            }
          
            
        }
    }
}
