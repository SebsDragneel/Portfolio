﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FSPG;
namespace Program_3_6
{
    class Program
    {
        static void Main(string[] args)
        {
            
            int number = Utility.Rand() % 100 + 1;
            Console.WriteLine("Let's play Guess The Number (1-100):");
            Console.WriteLine("You can write 0 to exit the game before winning!");
            Console.WriteLine("What's your guess?");
           int i = Utility.ReadInt();


            
            while (i != number && i != 0)
            {
                Console.WriteLine(" Sorry again: What's your guess?");
                int I = Utility.ReadInt();
                if (I > number && I != 0)
                {
                    Console.WriteLine("Too high!");
                }
                else if (I < number && I != 0)
                {
                    Console.WriteLine("Too Low!");
                }
                else if (I == 0)
                {
                    Console.WriteLine("Thanks for playing!");
                    break;
                }
                   else
                {
                    Console.WriteLine("Game Over!");
                    break;
                }
                     
                
            }

            if (i == 0)
            {
                Console.WriteLine("Thanks for playing!");

            }
            else
            Console.WriteLine("Game Over!");
        }
    }
}
