﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FSPG;
namespace Day_3_Activity_1
{
    class Program
    {
        static void Main(string[] args)
        {
            int hp = 0, mp = 0, speed = 0, stam=0;
            bool reroll=true;
            while (reroll)
            {
                hp = Utility.Rand() % 21 + 30;
                mp = Utility.Rand() % 11;
                stam = Utility.Rand() % 11;
                speed = Utility.Rand() % 11 + 169;
                Console.Clear();
                Console.WriteLine("Possible stats:");
                Console.WriteLine("HP:   " + hp);
                Console.WriteLine("MP:   " + mp);
                Console.WriteLine("STM:   " + stam);
                Console.WriteLine("SPD:   " + speed);
                Console.WriteLine();

                Console.WriteLine("Do you want to reroll?");
                string input = Console.ReadLine();
                int yes = Convert.To
                




            }
            
            Console.Clear();
            Console.WriteLine("Your final stats are:");
            Console.WriteLine("HP:   " + hp);
            Console.WriteLine("MP:   " + mp);
            Console.WriteLine("STM:   " + stam);
            Console.WriteLine("SPD:   " + speed);
            Console.WriteLine();

        }
    }
}
