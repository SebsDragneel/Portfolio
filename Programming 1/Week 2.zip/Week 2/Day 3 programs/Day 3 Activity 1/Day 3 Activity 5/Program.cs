﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FSPG;
namespace Day_3_Activity_5
{
    class Program
    {
        static void Main(string[] args)
        {

            
            float[] sales = new float[10];
            float total = 0;
            float low = 0;
            float high = 0;

            for (int i = 0; i < sales.Length; i++)
            {
                sales[i] = Utility.Rand()% 1000 / 10.0f;
                Console.WriteLine(sales[i]);
            }
            Console.WriteLine();
            high = sales[0];
            low = sales[0];

            for (int i = 0; i < sales.Length; i++)
            {
                total += sales[i];
                if (sales[i] > high)
                    high = sales[i];
                if (sales[i] < low)
                    high = sales[i];

            }
            Console.WriteLine("Total:   " + total);
            Console.WriteLine("Averg:   " + total / sales.Length);
            Console.WriteLine("High:   " + high);
            Console.WriteLine("Low:   " + low);


        }

    }
}
