﻿using System;
using System.Threading;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FSPG;
namespace Activity_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int x, y, vx, vy;
            x = Console.WindowWidth / 2;
            y = Console.WindowHeight / 2;
            vx = 1;
            vy = 1;
            
            while (true)
                {
                if (Utility.GetKeyState(ConsoleKey.Escape)) 
                break;
                    x = x + vx;
                    y = y + vy;
                if (x > Console.WindowWidth - 1)
                {
                    x = Console.WindowWidth - 1;
                    vx = vx * -1;
                }
                else if (x < 0)
                {
                    x = 0;
                    vx = vx * -1;

                }
               else if (y > Console.WindowHeight - 1)
                {
                    y = Console.WindowHeight - 1;
                    vy = vy * -1;
    
            }
               else if (y < 0)
                {
                    y= 0;
                    vy = vy * -1;

                }
                Console.Clear();
                Console.SetCursorPosition(x, y);
                Console.WriteLine("O");
                Thread.Sleep(50);
                }
        }
    }
}
