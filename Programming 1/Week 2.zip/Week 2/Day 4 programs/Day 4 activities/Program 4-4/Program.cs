﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FSPG;
namespace Program_4_4
{
    class Program
    {
        static void Main(string[] args)
        {
            float radius;
            
            do
            {
                Console.WriteLine("What is the radius of the sphere?: ");
                radius = Utility.ReadFloat();
            } while ((!Utility.IsReadGood()) || !(radius > 0));
          



            Console.WriteLine("Your answer is: " + Volume(radius));


        }
        static double Volume(double radius)
        {
            double answer = 4 * Math.PI * Math.Pow(radius, 3) / 3;
            
            return answer;
        }
    }
    }

