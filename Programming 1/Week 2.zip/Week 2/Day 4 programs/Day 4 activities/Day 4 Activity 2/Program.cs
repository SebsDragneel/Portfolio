﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day_4_Activity_2
{
    class Program
    {
        enum FullNameFormat
        {
            FirstThenLast,
            LastThenFirst,
            Initials,
        }
        static void Main(string[] args)
        {
            Console.WriteLine(" Enter your first name:");
            string first = Console.ReadLine();

            Console.WriteLine(" Enter your last name:");
            string last = Console.ReadLine();
            
                Console.WriteLine();
            Console.WriteLine(FullName(first, last, FullNameFormat.FirstThenLast));
            Console.WriteLine(FullName(first, last, FullNameFormat.LastThenFirst));
            Console.WriteLine(FullName(first, last, FullNameFormat.Initials));

           
        }
        static string FullName (string f, string l, FullNameFormat format)
        {
            string full = "";
            switch (format)
            {
                case FullNameFormat.FirstThenLast:
                    full = f + " " + l;
                    break;
                case FullNameFormat.LastThenFirst:
                    full = l + " " + f;
                    break;
                case FullNameFormat.Initials:
                    full = f[0].ToString() + "," + l[0].ToString() + ",";
                    break;
                default:
                    break;
            }
            return full;
        }
    }
}
