﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FSPG;
namespace Program_4_6
{
    class Program
    {
        static void Main(string[] args)
        {
            int number;
            int max;
           
            do
            {
                Console.WriteLine("Enter a number: ");
                number = Utility.ReadInt();
            } while (!Utility.IsReadGood());
            do
            {
                Console.WriteLine("Enter a max: ");
                max = Utility.ReadInt();
            } while (!Utility.IsReadGood());

            Multiples(number, max);


        }



        static void Multiples(int number, int max)
        {
            Console.Write("The multiples of " + number + " up to " + max + " are: ");
            for (int i = 0; i <= max; i+= number)
            {
               
                Console.Write(i + "  ");
            }

           


        }
    }
}
