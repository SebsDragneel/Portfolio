﻿using System;
using System.Collections.Generic;
using System.Text;
using FSPG;
namespace ConsoleApplication1
{
    class Program
    {

       
        static int Factorial(int n)
        {
            if (n <= 1)
                return 1;
            int result = 1;
            for (int i = 2; i <= n; i++)
            {
                result = result * i;
            }
            return result;
        }


        static void Main(string[] args)
        {
            int n;
            int r;
            do
            {
                Console.WriteLine("What number would you like a factorial of ? ");
                n = Utility.ReadInt();
            } while (!Utility.IsReadGood());

            r = Factorial(n);
            Console.WriteLine("Calculating " + n + "!" + "...");
            Console.WriteLine("Your answer is:  " + r);


        }
    }
}
