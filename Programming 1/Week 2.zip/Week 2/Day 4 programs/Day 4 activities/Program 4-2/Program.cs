﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FSPG;
namespace Program_4_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int x;
            int exp;
            do
            {
                Console.WriteLine("Give me your number: ");
                 x = Utility.ReadInt();
            } while (!Utility.IsReadGood());
            do { 
            Console.WriteLine("Give me the exponet of your number: ");
             exp = Utility.ReadInt();

        } while (!Utility.IsReadGood());


            Console.WriteLine("Your answer is: " + Power(x, exp));


        }
        static int Power (int x, int exp)
        {
            double answer = Math.Pow(x, exp);
            int Answer = Convert.ToInt32(answer);
            return Answer;
        }
    }
}
