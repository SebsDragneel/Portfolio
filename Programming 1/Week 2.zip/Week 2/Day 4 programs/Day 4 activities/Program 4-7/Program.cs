﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FSPG;
namespace Program_4_7
{
    class Program
    {
        static void Main(string[] args)
        {
           
        }
        static long Factorial(long number)
        {
           
        }
        
    }
}
