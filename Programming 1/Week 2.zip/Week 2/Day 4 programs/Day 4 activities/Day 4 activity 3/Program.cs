﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day_4_activity_3
{
    class Program
    {
        static void Main(string[] args)
        {

        }
        static int Sum1ton(int n)
        {
            return n * (n + 1) / 2;

           // int sum = 0;
           // for (int i= 1; i<= n; i++)
           // {
             //   sum += i;
           // };
           // return sum;
        }
    }
}
