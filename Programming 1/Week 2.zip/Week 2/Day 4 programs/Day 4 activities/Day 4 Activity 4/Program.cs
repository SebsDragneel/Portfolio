﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day_4_Activity_4
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = Console.WindowWidth / 2;
            int y = Console.WindowHeight / 2;
           

            double radius = 10.0;

            
            for (int i = 0; i<= 360; i++)
            {
                double rads = i * (Math.PI / 180.0);
               int cx = (int)Math.Round(Math.Cos(rads) * radius);
                int cy = (int)Math.Round(Math.Sin(rads) * radius);
                Console.SetCursorPosition(x + cx, y + cy);
                Console.Write(".");
            }
        }
        static void DrawCircle(int x, int y, double radius, ConsoleColor color)
        {
           
            ConsoleColor prev = Console.ForegroundColor;
            Console.ForegroundColor = color;

                for (int i = 0; i <= 360; i++)
            {
                double rads = i * (Math.PI / 180.0);
                int cx = (int)Math.Round(Math.Cos(rads) * radius);
                int cy = (int)Math.Round(Math.Sin(rads) * radius);
                Console.SetCursorPosition(x + cx, y + cy);
                Console.Write(".");
            }
            Console.ForegroundColor = prev;
        }
    }
}
