﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_4_1
{
    class Program
    {
        static void Main(string[] args)
        {
            PrintGtreeting();
        }
        static void PrintGtreeting   () 
            {
            while(true)
            {
              Console.WriteLine("Hello, World!");
            }
        }


    }
}
