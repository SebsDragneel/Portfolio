﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day_4_Activity_5
{
    class Program
    {
        
        static void Main(string[] args)
        {
            Console.WriteLine("Look in the list");
            int[] numbers = new int[10] { 123, 456, 789, 987, 654, 321, 234, 675, 989, 678};
            string[] texts = new string[10] { "Sebs", "Sebastian", "Chimuro", "Jason", "Josue", "Tom", "Saulo", "Pato", "Roy", "Poncho" };
            
            Console.WriteLine("" + IsInList(numbers, 123));
            Console.WriteLine("" + IsInList(texts, "Sebs"));

        }
        static bool IsInList( int[] numbers, int  x)
        {
            bool found = false;
            
            
            for (int i=0; i<numbers.Length; i++)
            {
                if (x== numbers[i])
                {
                    found = true;
                    return found;

                }
            }
            return found;
        }
        static bool IsInList(string[] texts, string s)
        {
            bool found = false;


            for (int i = 0; i < texts.Length; i++)
            {
                if (s == texts[i])
                {
                    found = true;
                    return found;

                }
            }
            return found;
        }
    }
}
