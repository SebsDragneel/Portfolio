﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FSPG;
namespace Day_4_activities
{
    class Program
    {
        static void Main(string[] args)
        {
            
            int x = RandInRange(10, 20);
            int y = RandInRange(100, 200);
            int z = RandInRange(3, 5);

        }
        static int RandInRange(int min, int max)
        {
          return(Utility.Rand() % (max - min + 1) + min);
           
        }
    }
}
