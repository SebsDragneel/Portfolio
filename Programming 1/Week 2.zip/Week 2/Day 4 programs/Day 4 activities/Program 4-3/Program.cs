﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FSPG;
namespace Program_4_3
{
    class Program
    {
        static void Main(string[] args)
        {
            double degrees;
            
            do
            {
                Console.WriteLine("Give me degrees: ");
                degrees = Utility.ReadDouble();
            } while (!Utility.IsReadGood());
            


            Console.WriteLine("Your answer in Radians is: " + RadiansToDegrees(degrees));


        }
        static double RadiansToDegrees(double degrees)
        {
           double Answer = degrees * Math.PI / 180.0;
            return Answer;
        }
    }
    }

