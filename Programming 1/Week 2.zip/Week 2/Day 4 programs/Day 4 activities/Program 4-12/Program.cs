﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_4_12
{
    class Program
    {
        static void Recursive(int value)
        {
            // Write call number and call this method again.
            // ... The stack will eventually overflow.
            Console.WriteLine(value);
            Recursive(++value);
        }

        static void Main()
        {
            // Begin the infinite recursion.
            Recursive(0);
        }
    }
}
