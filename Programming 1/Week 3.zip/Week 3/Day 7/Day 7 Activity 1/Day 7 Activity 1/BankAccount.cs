﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day_7_Activity_1
{
    class BankAccount
    {
        string mCustomerName;
        float mInitialBalance;
       public BankAccount()
        {
          mCustomerName = "(No Name)";
          mInitialBalance = 0;

        }
        public BankAccount(string customerName, float initialBalance)
        {
            mCustomerName = customerName;
            mInitialBalance = initialBalance;

        }
        public void SetCustomer(string customerName)
        {
            mCustomerName = customerName;
        }
        public string GetCustomer()
        {
            return mCustomerName;
        }
        public float GetBalance()
        {
            return mInitialBalance;

        }
        public bool Deposit(float amount)
        {
            if (amount < 0) return false;

            mInitialBalance += amount;

            return true;
        }

        public bool Withdraw(float amount)
        {
            if (amount < 0) return false;
            if (amount > mInitialBalance) return false;

            mInitialBalance -= amount;

            return true;
        }
    }
}
