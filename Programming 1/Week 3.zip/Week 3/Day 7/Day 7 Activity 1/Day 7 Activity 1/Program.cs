﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FSPG;
namespace Day_7_Activity_1
{
    class Program
    {
        static void Main(string[] args)
        {
            BankAccount b = new BankAccount("Bob", 100);

            Console.WriteLine();


            int choice = 0;
            float amount = 0;


            Console.WriteLine("Welcome to Le Crappy ATM!");
            Console.WriteLine("------------------------");
            Console.WriteLine("(1) Display Account Info");
            Console.WriteLine("(2) Change CUstomer Name");
            Console.WriteLine("(3) Deposit");
            Console.WriteLine("(4) Withdraw");
            Console.WriteLine("(5) Exit");
            Console.WriteLine("------------------------");
            Console.Write("What do you want to do?");
                choice = Utility.ReadInt();
            

                    switch (choice)
                    {
                        case 1:
                            Console.WriteLine(b.GetCustomer() + " - " + b.GetBalance());
                            break;
                        case 2:
                    Console.WriteLine("What is the new name?");
                    
                            break;
                        case 3:
                            Console.Write("How much: ");
                            amount = Utility.ReadFloat();
                            if (!b.Deposit(amount))
                                Console.WriteLine("Error!");
                            break;
                        case 4:
                            Console.Write("How much: ");
                            amount = Utility.ReadFloat();
                            if (!b.Withdraw(amount))
                                Console.WriteLine("Error!");
                            break;
                        case 5:
                            Console.WriteLine("Thanks for using our ATM!");
                            break;
                        default:
                            Console.WriteLine("Invalid Choice!!!");
                            break;
                    }

            Console.SetCursorPosition(0, Console.WindowHeight - 1);
            Console.Write("Press ENTER to continue...");
            Console.ReadLine();
        }
        
            }
            

            
        }

    
        
    

