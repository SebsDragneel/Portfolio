﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day_5_Activity_1
{
    class Program
    {
        static string[] names = new string[3];
        static void Main(string[] args)
        {
           
            
            ReadNames(names);

            DisplayNames(names);

            ReverseNames(names);
        }
        static void ReadNames(string[] names)
        {
            for (int i = 0; i < names.Length; i++)
            {
                Console.WriteLine("Enter name" + (i + 1) + ": ");
                names[i] = Console.ReadLine();
            }
        }
        static void DisplayNames(string[] names)
        {
            Console.WriteLine("Names: ");
            for (int i = 0; i < names.Length-1; i++)
                Console.Write(names[i]+ ", "); 
            Console.Write(names[names.Length-1] + ", ");
            Console.WriteLine();

        }
        static void ReverseNames(string[] names)
        {
            string temp;
            for (int i = 0 ; i < names.Length / 2; i++)
            {
                temp = names[i];
                names[i] = names[names.Length - 1 - 1];
                 names[names.Length - 1 - 1]= temp;
                
            }
        }
    }
}
