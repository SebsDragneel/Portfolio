﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_5_2
{
    class MyFirstClass
    {
         

        public  MyFirstClass()
        {
            
            Console.WriteLine("Constructor!");
        }
         ~MyFirstClass()
        {
            Console.WriteLine("Destructor!");

        }
    }
}
