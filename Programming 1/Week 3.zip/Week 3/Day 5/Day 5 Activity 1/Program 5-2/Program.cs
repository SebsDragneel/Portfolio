﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_5_2
{
    class Program
    {

        static void Main(string[] args)
        {
            MyFirstClass a = new MyFirstClass();
            MyFirstClass b = new MyFirstClass();
            MyFirstClass c = new MyFirstClass();
            MyFirstClass d = new MyFirstClass();
            MyFirstClass e = new MyFirstClass();
            MyFirstClass f = new MyFirstClass();




        }
    }
}
