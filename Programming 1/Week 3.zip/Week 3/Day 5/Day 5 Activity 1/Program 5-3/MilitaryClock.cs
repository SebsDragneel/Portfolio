﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_5_3
{
    class MilitaryClock
    {
        short hours;
        short minutes;

       public MilitaryClock()
        {
            hours = 13;
            minutes = 30;
        }
      
       public MilitaryClock(short h, short m)
        {
            hours = h;
            minutes = m;

        }
        public void SetTime(short h, short m)
        {
            hours = h;
            minutes = m;
        }
        public void Display()
        {
            while ( minutes >= 60)
                {
                    minutes = (short)(minutes -60);
                    hours= (short)(hours + 1);

                 }
            while (hours > 24)
            {
                hours = (short)(hours - 24);
            }
            if (hours < 10)
                Console.Write("0" + hours);
            else
                Console.Write(hours);
            if (minutes < 10)
                Console.Write("0" + minutes);
            else
            Console.Write(minutes);

            Console.WriteLine();
        }
    }
}
