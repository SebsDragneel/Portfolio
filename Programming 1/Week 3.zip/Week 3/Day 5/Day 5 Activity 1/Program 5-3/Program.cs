﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_5_3
{
    class Program
    {
        static void Main(string[] args)
        {
            MilitaryClock mc = new MilitaryClock();
            mc.Display();
            mc = new MilitaryClock(07, 00);
            mc.Display();
            mc.SetTime(56, 71);
            mc.Display();
        }
    }
}
