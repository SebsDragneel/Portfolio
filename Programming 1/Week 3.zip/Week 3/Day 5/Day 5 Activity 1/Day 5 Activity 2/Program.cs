﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day_5_Activity_2
{
    class Circle
    {
        public int mx;
        public int my;
        float mRadius;
        ConsoleColor mColor;
        char mSymbol;

        public void Init(int x, int y, float r, ConsoleColor c, char s)
        {
         mx= x;
         my= y;
         mRadius= r;
         mColor= c;
         mSymbol= s;
    }
       public void Draw()
        {
            ConsoleColor prev = Console.ForegroundColor;
            for (int i = 0; i <= 360; i++)
            {
                double rads = i * (Math.PI / 180.0);
                int cx = (int)Math.Round(Math.Cos(rads) * mRadius);
                int cy = (int)Math.Round(Math.Sin(rads) * mRadius);
                int fx = mx + cx;
                int fy = my + cy;

                if (fx >= 0 &&  fx< Console.WindowWidth
                 || fy >= 0 &&  fy< Console.WindowHeight
                    )
                        Console.SetCursorPosition(mx + cx, my + cy);
                Console.Write(mSymbol);
            }
            Console.ForegroundColor = prev;
        }

    }
    class Program
    {

        static void Main(string[] args)
        {
            Circle[] circles = new Circle[5];
            Random prng = new Random();
            Console.BackgroundColor = ConsoleColor.White;
            Console.Clear();

            for (int i = 0; i < circles.Length; i++)
            {
                Circle[] c1 = new Circle[i];
                c1[i].Init(prng.Next(0, Console.WindowWidth - 1), prng.Next(0, Console.WindowHeight - 1), 3, (ConsoleColor)(prng.Next() % 15), '.');
                c1[i].Draw();
            }
        }
    
   
}
    }
    

