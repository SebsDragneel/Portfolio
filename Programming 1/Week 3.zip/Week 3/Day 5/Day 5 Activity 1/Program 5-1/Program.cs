﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_5_1
{
    class Program
    {
        static int number;
        
        static void Main(string[] args)
        {

            LoopNumbers(number);
            Gaussssum(number);

           

            
            



        }
        static void LoopNumbers( int number)
        {
            System.Diagnostics.Stopwatch whatch = new System.Diagnostics.Stopwatch();
            whatch.Start();
            for (int i = 0; i <= 10000; i++)
            {
                
                 number = i + number;
            }
            whatch.Stop();
            Console.WriteLine("Solution 1: loop through all numbers");
            Console.WriteLine("Sum: " +  number);
            Console.WriteLine("Ticks: " + whatch.ElapsedTicks);

        }
        static void Gaussssum( int number)
        {
            System.Diagnostics.Stopwatch whatch = new System.Diagnostics.Stopwatch();
            whatch.Start();
            int n = 10000;
            number= (n*(n + 1) )/ 2;
            whatch.Stop();
                Console.WriteLine("Solution 2: Gauss's sum");
            Console.WriteLine("Sum: " + number );
            Console.WriteLine("Ticks: " + whatch.ElapsedTicks);
        }
    }
}
