﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FSPG;
namespace Program_5_4
{
    class SalesSummary
    {
        float[] sales = new float[10];
        float total = 0;
        float low = 0;
        float high = 0;
        
       public void  PrintSales()
        {
            for (int i = 0; i < sales.Length; i++)
            {
                sales[i] = Utility.Rand() % 1000 / 10.0f;
                Console.Write(sales[i]+ ", ");
                
            }
           
        }
        public float GetTotalValue()
        {
            for (int i = 0; i < sales.Length; i++)
            {
                total += sales[i];

            }
            return total;
        }
        public float GetAverageSale()
        {
           float average = total / sales.Length;
            return average;
        }
        public float GetHighestSale()
        {
            high = sales[0];
            for (int i = 0; i < sales.Length; i++)
            {
                
                if (sales[i] > high)
                    high = sales[i];

            }
            return high;
        }
        public float GetLowestSale()
        {
            low = sales[0];
            for (int i = 0; i < sales.Length; i++)
            {
               
               
                if (sales[i] < low)
                    low = sales[i];

            }
            return low;
        }

    }
}
