﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_5_4
{
    class Program
    {
        static void Main(string[] args)
        {
            SalesSummary ss = new SalesSummary();
           
            ss.PrintSales();
            Console.WriteLine();
            Console.WriteLine("Total: " + ss.GetTotalValue());
            Console.WriteLine("Average: " + ss.GetAverageSale());
            Console.WriteLine("Highest: " + ss.GetHighestSale());
            Console.WriteLine("Lowest: " + ss.GetLowestSale());
        }
    }
}
