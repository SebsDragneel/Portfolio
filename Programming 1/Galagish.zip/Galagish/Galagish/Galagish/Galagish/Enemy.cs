﻿using System;
using System.Diagnostics;
using FSPG;


namespace Galagish
{
    class Enemy
    {
        public enum Type
        {
            Bomber,
            // Teleporter,
            Kamakazi,
        }

        public enum State
        {
            Idle,
            Attack
        }

        Game TheGame;
        Enemy.Type mType;
        Enemy.State mState;
        float mX;
        float mY;
        float mSpeed;
        int mFireRate;
        bool mAlive;
        Stopwatch mFireTimer;

        public Enemy(Game game, Enemy.Type type, int x, int y, float speed)
        {
            TheGame = game;

            mType = type;
            mX = x;
            mY = y;
            mSpeed = speed;

            mAlive = true;
            mFireTimer = new Stopwatch();
            mFireTimer.Start();
            mFireRate = Utility.Rand() % (4001) + 1000;
            mState = State.Idle;
        }

        public bool IsAlive()
        {
            return mAlive;
        }

        public int GetX()
        {
            return (int)mX;
        }

        public int GetY()
        {
            return (int)mY;
        }

        public Enemy.Type GetEnemyType()
        {
            return mType;
        }

        public void Kill()
        {
            mAlive = false;
        }

        public void Update()
        {
            if (!mAlive) return;

            switch (mType)
            {
                case Type.Bomber:
                    mX += mSpeed;
                    if (mX > Console.WindowWidth - 1)
                        mX = 0;
                    if (mFireTimer.ElapsedMilliseconds > mFireRate)
                    {
                        TheGame.FireBullet((int)mX, (int)mY, Bullet.Type.Enemy);
                        mFireTimer.Restart();
                    }
                    break;
                case Type.Kamakazi:
                    switch (mState)
                    {
                        case State.Idle:
                            if (mFireTimer.ElapsedMilliseconds > mFireRate)
                                mState = State.Attack;
                            break;
                        case State.Attack:
                            Player p = TheGame.GetPlayer();
                            if (p.GetX() > (int)mX)
                                mX += mSpeed;
                            else if (p.GetX() < (int)mX)
                                mX -= mSpeed;
                            mY += mSpeed;
                            if ((int)mY > Console.WindowHeight - 1)
                            {
                                mState = State.Idle;
                                mFireTimer.Restart();
                                mX = Utility.Rand() % Console.WindowWidth;
                                mY = Utility.Rand() % (Console.WindowHeight - Console.WindowHeight / 4);
                            }
                            break;
                        default:
                            break;
                    }
                    break;
                default:
                    break;
            }
        }

        public void Draw()
        {
            if (!mAlive) return;
            if ((int)mY > Console.WindowHeight - 1) return;

            ConsoleColor prev = Console.ForegroundColor;

            Console.SetCursorPosition((int)mX, (int)mY);

            switch (mType)
            {
                case Type.Bomber:
                    Console.Write('~');
                    break;
                case Type.Kamakazi:
                    switch (mState)
                    {
                        case State.Idle:
                            Console.Write((char)1);
                            break;
                        case State.Attack:
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.Write((char)2);
                            break;
                        default:
                            break;
                    }
                    break;
                default:
                    break;
            }

            Console.ForegroundColor = prev;
        }
    }
}