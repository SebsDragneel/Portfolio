﻿using System;
using FSPG;


namespace Galagish
{
    class Program
    {
        static void Main(string[] args)
        {
            Utility.SetupWindow("Galagish", 80, 32, true);
            Utility.EOLWrap(false);

            Game game = new Game();

            //game.Menu();
            game.Init();
            game.Run();
            game.End();

            Console.SetCursorPosition(0, Console.WindowHeight - 1);
            Console.Write("Press ENTER to continue...");
            Console.ReadLine();
        }
    }
}
