﻿using System;


namespace Galagish
{
    class Bullet
    {
        public enum Type
        {
            Player,
            Enemy
        }

        const float PlayerBulletSpeed = 1f;
        const float EnemyBulletSpeed = 0.5f;

        float mX;
        float mY;
        Bullet.Type mType;
        bool mAlive;

        public Bullet(int x, int y, Bullet.Type type)
        {
            mX = x;
            mY = y;
            mType = type;
            mAlive = true;
        }

        public int GetX()
        {
            return (int)mX;
        }

        public int GetY()
        {
            return (int)mY;
        }

        public bool IsAlive()
        {
            return mAlive;
        }

        public void Kill()
        {
            mAlive = false;
        }

        public Bullet.Type GetBulletType()
        {
            return mType;
        }

        public void Update()
        {
            // quick out
            if (!mAlive) return;

            switch (mType)
            {
                case Type.Player:
                    mY -= PlayerBulletSpeed;
                    if (mY < 0)
                        mAlive = false;
                    break;
                case Type.Enemy:
                    mY += EnemyBulletSpeed;
                    if (mY > Console.WindowHeight - 1)
                        mAlive = false;
                    break;
                default:
                    break;
            }
        }

        public void Draw()
        {
            // quick out
            if (!mAlive) return;

            Console.SetCursorPosition((int)mX, (int)mY);

            switch (mType)
            {
                case Type.Player:
                    Console.Write('°');
                    break;
                case Type.Enemy:
                    Console.Write("#");
                    break;
                default:
                    break;
            }
        }
    }
}