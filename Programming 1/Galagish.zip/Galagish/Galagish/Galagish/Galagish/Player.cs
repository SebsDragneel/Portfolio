﻿using System;
using FSPG;
using System.Diagnostics;


namespace Galagish
{
    class Player
    {
        const float Speed = 0.75f;
        const int FireRate = 200;

        Game TheGame;
        float mX;
        float mY;
        bool mAlive;
        Stopwatch mFireTimer;

        public Player(Game game)
        {
            TheGame = game;
            mFireTimer = new Stopwatch();

            mX = Console.WindowWidth / 2;
            mY = Console.WindowHeight - 1;
            
            mAlive = true;
            mFireTimer.Start();
        }

        public bool IsAlive()
        {
            return mAlive;
        }

        public int GetX()
        {
            return (int)mX;
        }

        public int GetY()
        {
            return (int)mY;
        }

        public void Kill()
        {
            mAlive = false;
        }

        public void Update()
        {
            if (Utility.GetKeyState(ConsoleKey.RightArrow))
                mX += Speed;
            else if (Utility.GetKeyState(ConsoleKey.LeftArrow))
                mX -= Speed;

            if (mX < 0)
                mX = 0;
            else if (mX > Console.WindowWidth - 1)
                mX = Console.WindowWidth - 1;

            if (Utility.GetKeyState(ConsoleKey.UpArrow))
            {
                if (mFireTimer.ElapsedMilliseconds > FireRate)
                {
                    //if (Utility.Rand() % 5 != 0)
                        TheGame.FireBullet((int)mX, (int)mY - 1, Bullet.Type.Player);
                    mFireTimer.Restart();
                }
            }
        }

        public void Draw()
        {
            Console.SetCursorPosition((int)mX, (int)mY);
            Console.Write((char)127);
        }
    }
}
