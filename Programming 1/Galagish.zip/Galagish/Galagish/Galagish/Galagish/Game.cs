﻿using System;
using System.Collections.Generic;
using System.Threading;
using FSPG;


namespace Galagish
{
    class Game
    {
        const int MaxEnemies = 30;

        Player mPlayer;
        List<Enemy> mEnemies;
        List<Bullet> mBullets;
        bool mGameOver;
        int mScore;

        public Game()
        {
        }

        public void Init()
        {
            mPlayer = new Player(this);

            mEnemies = new List<Enemy>();
            for (int i = 0; i < MaxEnemies-(MaxEnemies/5); i++)
            {
                Enemy e = new Enemy(this,
                    Enemy.Type.Bomber,
                    Utility.Rand() % Console.WindowWidth,
                    Utility.Rand() % (Console.WindowHeight - Console.WindowHeight / 4),
                    Utility.Rand() % 150 / 150.0f);
                mEnemies.Add(e);
            }
            for (int i = 0; i < MaxEnemies / 5; i++)
            {
                Enemy e = new Enemy(this,
                    Enemy.Type.Kamakazi,
                    Utility.Rand() % Console.WindowWidth,
                    Utility.Rand() % (Console.WindowHeight - Console.WindowHeight / 4),
                    Utility.Rand() % 150 / 150.0f);
                mEnemies.Add(e);
            }

            mBullets = new List<Bullet>();

            mGameOver = false;
            mScore = 0;
        }

        public void Run()
        {
            while (!mGameOver)
            {
                // catch input
                if (Utility.GetKeyState(ConsoleKey.Escape) ||
                    Utility.GetKeyState(ConsoleKey.Q))
                    break;

                // update
                Update();

                // draw
                Draw();

                // timestep
                Thread.Sleep(30);
            }
        }

        public void End()
        {
            bool winning = (mPlayer.IsAlive() && mEnemies.Count <= 0);

            if (winning)
                Utility.WriteCentered("You win!!");
            else
                Utility.WriteCentered("You suck!");

            Utility.WriteCentered("Final score: " + mScore, 2);
        }

        private void Update()
        {
            // update player
            mPlayer.Update();

            // update enemies
            for (int i = mEnemies.Count-1; i >= 0; i--)
            {
                mEnemies[i].Update();

                if (mEnemies[i].GetEnemyType() == Enemy.Type.Kamakazi)
                {
                    if (mEnemies[i].GetX() == mPlayer.GetX() &&
                        mEnemies[i].GetY() == mPlayer.GetY())
                    {
                        mEnemies[i].Kill();
                        mPlayer.Kill();
                    }
                }

                if (!mEnemies[i].IsAlive())
                    mEnemies.RemoveAt(i);
            }

            // update bullets
            for (int i = mBullets.Count-1; i >= 0; i--)
            {
                mBullets[i].Update();

                // enemy bullets
                if (mBullets[i].GetBulletType() == Bullet.Type.Enemy)
                {
                    if (mBullets[i].GetX() == mPlayer.GetX() &&
                        mBullets[i].GetY() == mPlayer.GetY())
                    {
                        mBullets[i].Kill();
                        mPlayer.Kill();
                    }
                }
                // player bullets
                else if (mBullets[i].GetBulletType() == Bullet.Type.Player)
                {
                    for (int j = 0; j < mEnemies.Count; j++)
                    {
                        if (mBullets[i].GetX() == mEnemies[j].GetX() &&
                            mBullets[i].GetY() == mEnemies[j].GetY())
                        {
                            mBullets[i].Kill();
                            mEnemies[j].Kill();
                            mScore += 10;
                        }
                    }
                }

                if (!mBullets[i].IsAlive())
                    mBullets.RemoveAt(i);
            }

            if (!mPlayer.IsAlive() || mEnemies.Count <= 0)
                mGameOver = true;
        }

        private void Draw()
        {
            Utility.LockConsole(true);

            Console.Clear();

            mPlayer.Draw();

            for (int i = 0; i < mEnemies.Count; i++)
                mEnemies[i].Draw();

            for (int i = 0; i < mBullets.Count; i++)
                mBullets[i].Draw();

            Console.SetCursorPosition(1, 0);
            Console.Write("Score: " + mScore);

            //Console.SetCursorPosition(Console.WindowWidth - 15, 0);
            //Console.Write("Bullets: " + mBullets.Count);

            Utility.LockConsole(false);
        }

        public void FireBullet(int x, int y, Bullet.Type type)
        {
            Bullet b = new Bullet(x, y, type);
            mBullets.Add(b);
        }

        public Player GetPlayer()
        {
            return mPlayer;
        }
    }
}
