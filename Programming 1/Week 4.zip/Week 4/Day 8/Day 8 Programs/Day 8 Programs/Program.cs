﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day_8_Programs
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Table of integral variable types in C#:");
            Console.WriteLine("-------------------------------------------------------------------------");
            Console.WriteLine("type    bytes       bits        combinations        min        max");
            Console.WriteLine("-------------------------------------------------------------------------");
            Console.WriteLine("sbyte   " + sizeof(sbyte) + "8       " + Math.Pow (2,8) + "        " + SByte.MinValue + "        " + SByte.MaxValue);
            Console.WriteLine("byte   " + sizeof(byte) + "8        " + Math.Pow(2, 8) + "        " + Byte.MinValue + "        " + Byte.MaxValue);
            Console.WriteLine("short   " + sizeof(short) + "16      " + Math.Pow(2, 16) + "        " + Int16.MinValue + "        " + Int16.MaxValue);
            Console.WriteLine("ushort   " + sizeof(ushort) + "16     " + Math.Pow(2, 16) + "        " + UInt16.MinValue + "        " + UInt16.MaxValue);
            Console.WriteLine("int   " + sizeof(int) + "32        " + Math.Pow(2, 32) + "       " + Int32.MinValue + "        " + Int32.MaxValue);
            Console.WriteLine("uint   " + sizeof(uint) + "32       " + Math.Pow(2, 32) + "        " + UInt32.MinValue + "        " + UInt32.MaxValue);
            Console.WriteLine("long   " + sizeof(long) + "64       " + Math.Pow(2, 64) + "        " + Int64.MinValue + "        " + Int64.MaxValue);
            Console.WriteLine("ulong   " + sizeof(ulong) + "64      " + Math.Pow(2, 64) + "        " + UInt64.MinValue + "        " + UInt64.MaxValue);



        }
    }
}
