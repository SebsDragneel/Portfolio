﻿using System;
using FSPG;

namespace FSPG
{
    class Program
   {
        static void Main(string[] args)
}


    Console.WriteLine("f");
        input = Console.ReadLine();
        min = Convert.ToInt32(input);


        Console.SetCursorPosition(0, Console.WindowHeight);
        Console.WriteLine("Press ENTER to continue...");
        Console.ReadLine();
        }
