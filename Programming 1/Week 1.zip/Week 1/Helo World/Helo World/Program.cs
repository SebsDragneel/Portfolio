﻿using System;
namespace FSPG
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = Console.WindowWidth / 2;
            int y = Console.WindowHeight / 2;
            string message = "Hello, World";

            Console.SetCursorPosition(x - (message.Length), y);

            Console.WriteLine(message);

            Console.SetCursorPosition(0, Console.WindowHeight);

            Console.WriteLine("Press ENTER to continue...");
            Console.ReadLine();

        }
    }

}
