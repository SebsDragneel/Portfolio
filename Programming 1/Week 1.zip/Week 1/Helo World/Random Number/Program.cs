﻿
using System;
using FSPG;

namespace FSPG
{
    class Program
    {
        static void Main(string[] args)
        {
            int max = 42;
            int min = 42;
            int number;
            string input;

            Console.Write("Please enter a min bound: ");
            input = Console.ReadLine();
            min = Convert.ToInt32(input);

            Console.Write("Please enter a max bound: ");
            input = Console.ReadLine();
            max = Convert.ToInt32(input);

            number = Utility.Rand() % (max - min + 1) + min;
            Console.WriteLine("You entered the number");
            Console.WriteLine(number);

            Console.SetCursorPosition(0, Console.WindowHeight);
            Console.WriteLine("Press ENTER to continue...");
            Console.ReadLine();
        }
    }
}
    
    
