﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_1_7
{
    class Program
    {
        static void Main(string[] args)
        {
            uint y=UInt32.MaxValue;
            uint z = UInt32.MinValue;
            double answer1;
            double answer2;

            Console.WriteLine("\t uint");
            Console.WriteLine("\t \t Minimum value of uint: " + z);
            answer1 = z  - 1;
            Console.WriteLine("\t \t Minimum value of uint - 1: " + answer1);
            Console.WriteLine("\t \t Maximum value of uint: " + y);
            answer2 = y + 1;
            Console.WriteLine("\t \t Maximum value of uint + 1: " + answer2);
        }
    }
}
