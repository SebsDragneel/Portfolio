﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_1_3
{
    class Program
    {
        static void Main(string[] args)
        {
            string name;
            string input;
            int number;
            int w = 0;
            int x = 0;
            int y = 0;
            int z = 0;

            Console.WriteLine("PLease enter a number:");
            input = Console.ReadLine();
            number = Convert.ToInt32(input);

            w = number / 1;
            x = number / 2;
            y = number / 4;
            z = number / 8;

            Console.Write(number);
            Console.Write(" /1= ");
            Console.WriteLine(w);

            Console.Write(number);
            Console.Write(" /2= ");
            Console.WriteLine(x);

            Console.Write(number);
            Console.Write(" /4= ");
            Console.WriteLine(y);

            Console.Write(number);
            Console.Write(" /8= ");
            Console.WriteLine(z);

        }
    }
}
