﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_1_4
{
    class Program
    {
        static void Main(string[] args)
        {
            string A;
            string B;
            string C;
            int a;
            int b;
            int c;
            int v1;
            int v2;

            Console.WriteLine("PLease enter 3 numbers");

            Console.WriteLine("PLease enter value for a:");
            A = Console.ReadLine();
            a = Convert.ToInt32(A);

            Console.WriteLine("PLease enter value for b:");
            B = Console.ReadLine();
            b = Convert.ToInt32(B);

            Console.WriteLine("PLease enter value for c:");
            C = Console.ReadLine();
            c = Convert.ToInt32(C);

            v1 = a + 1 * b + 2 - c;
            v2 = (a + 1) * (b + 2) - c;

            Console.WriteLine("a + 1 * b + 2 - c= "+ v1);
            
            Console.WriteLine("(a + 1) * (b + 2) - c= "+ v2);
            


        }
    }
}
