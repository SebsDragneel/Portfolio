﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_1_5
{
    class Program
    {
        static void Main(string[] args)
        {
            double F;
            string Fahrenheit;
            string Celsius;
            double f;
            double c;
            double C;

            Console.WriteLine("Temperature in F:");
            Fahrenheit = Console.ReadLine();
            f = Convert.ToInt32(Fahrenheit);

            C = (f - 32.0) * (5.0 / 9.0);
            Console.WriteLine("Temperature  F in C:" + C);

            Console.WriteLine("Temperature in C:");
            Celsius = Console.ReadLine();
            c = Convert.ToInt32(Celsius);         

            F = (c * 9.0) / (5.0 + 32.0);

            Console.WriteLine("Temperature C in F:" + F);
        }
    }
}
