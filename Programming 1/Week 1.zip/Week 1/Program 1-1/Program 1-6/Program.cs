﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_1_6
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Console.WriteLine("\t Table of integral variable type ranges in C#:");

            Console.WriteLine("\t sbyte");
            Console.WriteLine("\t \t minimum: " + SByte.MinValue);
            Console.WriteLine("\t \t maximum: " + SByte.MaxValue);

            Console.WriteLine("\t byte");
            Console.WriteLine("\t \t minimum: " + Byte.MinValue);
            Console.WriteLine("\t \t maximum: " + Byte.MaxValue);

            Console.WriteLine("\t short");
            Console.WriteLine("\t \t minimum: " + Int16.MinValue);
            Console.WriteLine("\t \t maximum: " + Int16.MaxValue);

            Console.WriteLine("\t ushort");
            Console.WriteLine("\t \t minimum: " + UInt16.MinValue);
            Console.WriteLine("\t \t maximum: " + UInt16.MaxValue);

            Console.WriteLine("\t int");
            Console.WriteLine("\t \t minimum: " +Int32.MinValue);
            Console.WriteLine("\t \t maximum: " +Int32.MaxValue);

            Console.WriteLine("\t uint");
            Console.WriteLine("\t \t minimum: " + UInt32.MinValue);
            Console.WriteLine("\t \t maximum: " + UInt32.MaxValue);

            Console.WriteLine("\t long");
            Console.WriteLine("\t \t minimum: " + Int64.MinValue);
            Console.WriteLine("\t \t maximum: " + Int64.MaxValue);

            Console.WriteLine("\t ulong");
            Console.WriteLine("\t \t minimum: " + UInt64.MinValue);
            Console.WriteLine("\t \t maximum: " + UInt64.MaxValue);

        }
    }
}
