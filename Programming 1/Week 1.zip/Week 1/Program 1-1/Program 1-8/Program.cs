﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_1_8
{
    class Program
    {
        static void Main(string[] args)
        {
            string A;
            string B;
            int a;
            int b;
            int C;

            Console.WriteLine("PLease enter a number");
            A = Console.ReadLine();
            a = Convert.ToInt32(A);

            Console.WriteLine("PLease enter a number");
            B = Console.ReadLine();
            b = Convert.ToInt32(B);

            C = a + b;

            Console.WriteLine("The answer is: " + C);

            // the answer has more than int 32, thats why the program cracks.
        }
    }
}
