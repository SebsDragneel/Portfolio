﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_1_2
{
    class Program
    {
        static void Main(string[] args)
        {
            string name;
            string input;
            int age;
            int days = 0;


            Console.WriteLine("PLease enter your name:");
            name= Console.ReadLine();
            Console.WriteLine("PLease enter your age:");
            input = Console.ReadLine();
            age = Convert.ToInt32(input);

            days = age * 165;

            Console.Write(name);
            Console.Write(" did you know you're at least ");
            Console.Write(days);
            Console.Write(" days old? ");

        }
    }
}
