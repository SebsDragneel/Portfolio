﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_1_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, my name is Sebastian Diaz");
            Console.WriteLine("I researched Activision Blizzard Inc.");
            Console.WriteLine("They currently have 6,800 employees");

        }
    }
}
