﻿//=============================================================================
// Program's Item class
//=============================================================================

namespace Shop
{
    class Item
    {
        string mName;
        int mCost;
        public Item()
        {
            mName = "";
            mCost = 0;
        }
        public Item(string name, int cost)
        {
            mName = name;
            mCost = cost;
        }
        public string GetName()
        {
            return mName;
        }
        public int GetCost()
        {
            return mCost;
        }

        public void SetName(string name)
        {
            mName = name;
           
        }
        public void SetCost(int cost)
        {
            mCost = cost;
        }
    }

    // TODO: Write a class called Item that contains 2 data members:
    //       A string called name and an int called cost.
    //       This class should have a default constructor that sets name to ""
    //       and cost to 0.
    //       It should also have an overloaded constructor.
    //
    //       Write accessors for each data member. They should be called GetName
    //       GetCost.
    //       Write mutators for each data member. They should be called SetName
    //       and SetCost.
   

}
