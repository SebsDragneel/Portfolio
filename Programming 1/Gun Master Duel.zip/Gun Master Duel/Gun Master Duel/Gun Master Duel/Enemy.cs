﻿using System;
using System.Diagnostics;
using FSPG;


namespace Gun_Master_Duel
{
    class Enemy
    {
        public enum Type
        {
            Bomber,
            Bomber2
   
        }


        GamePlay TheGame;
        Enemy.Type mType;
        float mX;
        float mY;
        float mSpeed;
        int mFireRate;
        bool mAlive;
        Stopwatch mFireTimer;

        public Enemy(GamePlay game, Enemy.Type type, int x, int y, float speed)
        {
            TheGame = game;

            mType = type;
            mX = x;
            mY = y;
            mSpeed = speed;

            mAlive = true;
            mFireTimer = new Stopwatch();
            mFireTimer.Start();
            mFireRate = Utility.Rand() % (2001) + 1000;
        }

        public bool IsAlive()
        {
            return mAlive;
        }

        public int GetX()
        {
            return (int)mX;
        }

        public int GetY()
        {
            return (int)mY;
        }

        public Enemy.Type GetEnemyType()
        {
            return mType;
        }

        public void Kill()
        {
            mAlive = false;
        }

        public void Update()
        {
            if (!mAlive) return;

            switch (mType)
            {
                case Type.Bomber:
                    mY += mSpeed;

                    if (mY > Console.WindowHeight - 1)
                        mY = 1;
                    if (mFireTimer.ElapsedMilliseconds > mFireRate)
                    {
                        TheGame.FireBullet((int)mX, (int)mY, Bullet.Type.Enemy2);
                        mFireTimer.Restart();
                    }
                    break;
                case Type.Bomber2:
                    mY -= mSpeed;
                    if (mY < 1)
                        mY = Console.WindowHeight - 1;
                    if (mFireTimer.ElapsedMilliseconds > mFireRate)
                    {
                        TheGame.FireBullet((int)mX, (int)mY, Bullet.Type.Enemy1);
                        mFireTimer.Restart();
                    }
                    break;
                default:
                    break;
            }
        }

        public void Draw()
        {
            if (!mAlive) return;
            

            ConsoleColor prev = Console.ForegroundColor;

            Console.SetCursorPosition((int)mX, (int)mY);

            switch (mType)
            {
                case Type.Bomber:
                    Console.ForegroundColor = ConsoleColor.DarkGreen;
                    Console.Write('»');
                    break;
                case Type.Bomber2:
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.Write('«');
                    break;
                default:
                    break;
            }

            Console.ForegroundColor = prev;
        }
    }
}