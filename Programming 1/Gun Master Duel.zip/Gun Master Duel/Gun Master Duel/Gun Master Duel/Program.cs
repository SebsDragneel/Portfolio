﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FSPG;

namespace Gun_Master_Duel
{
    class Program
    {
        static void Main(string[] args)
        {
            Utility.SetupWindow("Gun Master Duel", 180, 60, true);
            Utility.EOLWrap(false);

            GamePlay game = new GamePlay();

            game.Menu();
            game.Instructions();
            game.Init();
            game.Run();
            game.End();

            Console.SetCursorPosition(Console.WindowWidth / 2 - 13, Console.WindowHeight - 1);
            Console.Write("Press ENTER to continue...");
            Console.ReadLine();

        }
    }
}
