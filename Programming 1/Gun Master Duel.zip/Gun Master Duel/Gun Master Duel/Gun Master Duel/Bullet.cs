﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gun_Master_Duel
{
    class Bullet
    {
        public enum Type
        {
            Player1,
            Player2,
            Enemy1,
            Enemy2,
        }
        const float Player1BulletSpeed = 1f;
        const float Player2BulletSpeed = 1f;
        const float EnemyBulletSpeed = 0.5f;

        float mX;
        float mY;
        Bullet.Type mType;
        bool mAlive;

        public Bullet(int x, int y, Bullet.Type type)
        {
            mX = x;
            mY = y;
            mType = type;
            mAlive = true;
        }

        public int GetX()
        {
            return (int)mX;
        }

        public int GetY()
        {
            return (int)mY;
        }

        public bool IsAlive()
        {
            return mAlive;
        }

        public void Kill()
        {
            mAlive = false;
        }

        public Bullet.Type GetBulletType()
        {
            return mType;
        }

        public void Update()
        {
            // quick out
            if (!mAlive) return;

            switch (mType)
            {
                case Type.Player1:
                    
                    mX += Player1BulletSpeed;
                    if (mX > Console.WindowWidth - 1)
                        mAlive = false;
                    break;
                case Type.Player2:
                    
                    mX -= Player2BulletSpeed;
                    if (mX < 1)
                        mAlive = false;
                    break;
                case Type.Enemy1:
                    
                    mX -= EnemyBulletSpeed;
                    
                    if (mX < 1)
                        mAlive = false;
                    break;
                case Type.Enemy2:
                    
                    mX += EnemyBulletSpeed;
                    if (mX > Console.WindowWidth - 1)
                        mAlive = false;
                    break;

                default:
                    break;
            }
        }

        public void Draw()
        {
            // quick out
            if (!mAlive) return;

            Console.SetCursorPosition((int)mX, (int)mY);

            switch (mType)
            {
                case Type.Player1:
                    if (!IsAlive()) return;
                    ConsoleColor prev = Console.ForegroundColor;
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write('°');
                    Console.ForegroundColor = prev;
                    break;
                case Type.Player2:
                    if (!IsAlive()) return;
                    ConsoleColor prev2 = Console.ForegroundColor;
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.Write('°');
                    Console.ForegroundColor = prev2;
                    break;
                case Type.Enemy1:
                    if (!IsAlive()) return;
                    ConsoleColor prev3 = Console.ForegroundColor;
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.Write("-");
                    Console.ForegroundColor = prev3;
                    break;
                case Type.Enemy2:
                    if (!IsAlive()) return;
                    ConsoleColor prev4 = Console.ForegroundColor;
                    Console.ForegroundColor = ConsoleColor.DarkGreen;
                    Console.Write("-");
                    Console.ForegroundColor = prev4;
                    break;
                default:
                    break;
            }
        }
    }
}

