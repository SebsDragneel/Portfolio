﻿using System;
using System.Collections.Generic;
using System.Threading;
using FSPG;


namespace Gun_Master_Duel
{
    class GamePlay
    {
        const int MaxEnemies = 5;

        Player1 mPlayer1;
        Player2 mPlayer2;
        List<Enemy> mEnemies;
        List<Bullet> mBullets;
        bool mGameOver;
        int mScore1;
        int mScore2;

        public GamePlay()
        {

        }
        public void Menu()
        {


            ConsoleColor prev = Console.ForegroundColor;
            ConsoleColor prev2 = Console.BackgroundColor;
            ConsoleColor intro = ConsoleColor.Gray;
            ConsoleColor font = ConsoleColor.DarkMagenta;
            Console.BackgroundColor = intro;
            Console.ForegroundColor = font;
            Console.Clear();

            Console.SetCursorPosition(Console.WindowWidth / 2 - (17 / 2), Console.WindowHeight / 2);
            Console.WriteLine("\"Gun Master Duel\"");

            Console.SetCursorPosition(Console.WindowWidth / 2 - (16 / 2), Console.WindowHeight / 2 + 4);
            Console.WriteLine("Game Created by:");
            Console.SetCursorPosition(Console.WindowWidth / 2 - (14 / 2), Console.WindowHeight / 2 + 6);
            Console.WriteLine("Sebastian Diaz");
            Console.SetCursorPosition(Console.WindowWidth / 2 - (3 / 2), Console.WindowHeight / 2 + 8);
            Console.WriteLine("and");
            Console.SetCursorPosition(Console.WindowWidth / 2 - (14 / 2), Console.WindowHeight / 2 + 10);
            Console.WriteLine("Jayson Levario");

            Console.SetCursorPosition(Console.WindowWidth / 2 - (23 / 2), Console.WindowHeight - 1);
            Console.Write("Press Enter to Continue");
            Console.ReadLine();


            Console.BackgroundColor = prev2;
            Console.ForegroundColor = prev;
            Console.Clear();
        }

        public void Instructions()
        {


            ConsoleColor prev = Console.ForegroundColor;
            ConsoleColor prev2 = Console.BackgroundColor;
            ConsoleColor intro = ConsoleColor.Gray;
            ConsoleColor font = ConsoleColor.DarkMagenta;
            Console.BackgroundColor = intro;
            Console.ForegroundColor = font;
            Console.Clear();

            Utility.WriteCentered("Instructions:");
            Utility.WriteCentered("Player 1:                          Player 2:", 4);
            Utility.WriteCentered("Move up: W                         Move up: NumPad8", 6);
            Utility.WriteCentered(" Move down: S                       Move down: NumPad5", 8);
            Utility.WriteCentered(" Move left: A                       Move left: NumPad4", 10);
            Utility.WriteCentered("  Move right: D                      Move right: NumPad6", 12);
            Utility.WriteCentered("Fire: SpaceBar                     Move left: NumPad0", 14);
            Console.SetCursorPosition(Console.WindowWidth / 2 - (23 / 2), Console.WindowHeight - 1);
            Console.Write("Press Enter to Continue");
            Console.ReadLine();


            Console.BackgroundColor = prev2;
            Console.ForegroundColor = prev;
            Console.Clear();
        }
        public void Init()
        {
            mPlayer1 = new Player1(this);
            mPlayer2 = new Player2(this);

            mEnemies = new List<Enemy>();
            for (int i = 0; i < MaxEnemies - (MaxEnemies / 5); i++)
            {
                Enemy e = new Enemy(this,
                    Enemy.Type.Bomber,
                    // revise this stuff
                    Utility.Rand() % 46 + 45,
                    Utility.Rand() % (Console.WindowHeight),
                    Utility.Rand() % 150 / 150.0f);
                mEnemies.Add(e);
            }
            for (int i = 0; i < MaxEnemies - (MaxEnemies / 5); i++)
            {
                Enemy e = new Enemy(this,
                    Enemy.Type.Bomber2,
                    // revise this stuff
                    Utility.Rand() % 46 + 45,
                    Utility.Rand() % (Console.WindowHeight),
                    Utility.Rand() % 150 / 150.0f);
                mEnemies.Add(e);
            }


            mBullets = new List<Bullet>();

            mGameOver = false;
            mScore1 = 0;
            mScore2 = 0;

        }

        public void Run()
        {
            while (!mGameOver)
            {
                // catch input
                if (Utility.GetKeyState(ConsoleKey.Escape))
                    break;

                // update
                Update();

                // draw
                Draw();

                // timestep
                Thread.Sleep(30);
            }
        }

        public void End()
        {
            bool winning1 = (mPlayer1.IsAlive() && (mEnemies.Count <= 0 && !mPlayer2.IsAlive()));
            bool winning2 = (mPlayer2.IsAlive() && (mEnemies.Count <= 0 && !mPlayer1.IsAlive()));
            bool Loosing = (!mPlayer1.IsAlive() && !mPlayer2.IsAlive());

            if (winning1)
                Utility.WriteCentered("Player 1 Wins!");
            else if (winning2)
                Utility.WriteCentered("Player 2 Wins!");
            else if(Loosing)
                Utility.WriteCentered("Enemy Team Wins!");



            Utility.WriteCentered("Player 1 Final score: " + mScore1, 2);
            Utility.WriteCentered("Player 2 Final score: " + mScore2, 4);

        }

        private void Update()
        {
            // update player 1
            mPlayer1.Update();
            
                


                // update player 2
                mPlayer2.Update();
            
            

            // update enemies
            for (int i = mEnemies.Count - 1; i >= 0; i--)
            {
                mEnemies[i].Update();

                if (!mEnemies[i].IsAlive())
                    mEnemies.RemoveAt(i);
            }

            // update bullets
            for (int i = mBullets.Count - 1; i >= 0; i--)
            {
                mBullets[i].Update();

                // enemy bullets
                if (mBullets[i].GetBulletType() == Bullet.Type.Enemy1)
                {
                    if (mBullets[i].GetX() == mPlayer1.GetX() &&
                        mBullets[i].GetY() == mPlayer1.GetY())
                    {
                        mBullets[i].Kill();
                        mPlayer1.Kill();
                    }
                }
                if (mBullets[i].GetBulletType() == Bullet.Type.Enemy2)
                {
                    if (mBullets[i].GetX() == mPlayer2.GetX() &&
                        mBullets[i].GetY() == mPlayer2.GetY())
                    {
                        mBullets[i].Kill();
                        mPlayer2.Kill();
                    }
                }

                // player 1 bullets
                else if (mBullets[i].GetBulletType() == Bullet.Type.Player1)
                {
                    for (int j = 0; j < mEnemies.Count; j++)
                    {
                        if (mBullets[i].GetX() == mEnemies[j].GetX() &&
                            mBullets[i].GetY() == mEnemies[j].GetY())
                        {
                            mBullets[i].Kill();
                            mEnemies[j].Kill();
                            mScore1 += 10;
                        }
                        else if (mBullets[i].GetX() == mPlayer2.GetX() &&
                        mBullets[i].GetY() == mPlayer2.GetY())
                        {
                            mBullets[i].Kill();
                            mPlayer2.Kill();
                        }
                    }
                }
                else if (mBullets[i].GetBulletType() == Bullet.Type.Player2)
                {
                    for (int j = 0; j < mEnemies.Count; j++)
                    {
                        if (mBullets[i].GetX() == mEnemies[j].GetX() &&
                            mBullets[i].GetY() == mEnemies[j].GetY())
                        {
                            mBullets[i].Kill();
                            mEnemies[j].Kill();
                            mScore2 += 10;
                        }
                        else if (mBullets[i].GetX() == mPlayer1.GetX() &&
                        mBullets[i].GetY() == mPlayer1.GetY())
                        {
                            mBullets[i].Kill();
                            mPlayer1.Kill();
                        }
                    }
                }

                if (!mBullets[i].IsAlive())
                    mBullets.RemoveAt(i);
            }

            if (mPlayer1.IsAlive() && (mEnemies.Count <= 0 && !mPlayer2.IsAlive()))
            {
                mGameOver = true;
            }
            if (mPlayer2.IsAlive() && (mEnemies.Count <= 0 && !mPlayer1.IsAlive()))
            {
                mGameOver = true;
            }
            if ((!mPlayer1.IsAlive() && !mPlayer2.IsAlive()))
            {
                mGameOver = true;
            }

        }

        private void Draw()
        {
            


            Utility.LockConsole(true);

            Console.Clear();

            mPlayer1.Draw();
            mPlayer2.Draw();


            for (int i = 0; i < mEnemies.Count; i++)
                mEnemies[i].Draw();

            for (int i = 0; i < mBullets.Count; i++)
                mBullets[i].Draw();

            Console.SetCursorPosition(1, 0);
            Console.Write("Player 1 Score: " + mScore1);

            Console.SetCursorPosition(Console.WindowWidth - 20, 0);
            Console.Write("Player 2 Score: " + mScore2);

            

            Utility.LockConsole(false);
        }

        public void FireBullet(int x, int y, Bullet.Type type)
        {
            Bullet b = new Bullet(x, y, type);
            mBullets.Add(b);
        }

        public Player1 GetPlayer1()
        {
            return mPlayer1;
        }
        public Player2 GetPlayer2()
        {
            return mPlayer2;
        }
    }
}
