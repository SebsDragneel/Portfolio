﻿using System;
using System.Diagnostics;
using FSPG;


namespace Gun_Master_Duel
{
    class Player2
    {
        GamePlay TheGame;
        const float Speed = 0.75f;
        const int FireRate = 200;
        float mX;
        float mY;
        bool mAlive;
        Stopwatch mFireTimer;

        public Player2(GamePlay game)
        {
            TheGame = game;
            mFireTimer = new Stopwatch();

            mX = Console.WindowWidth - 1;
            mY =  Console.WindowHeight / 2;

            mAlive = true;
            mFireTimer.Start();
        }

        public bool IsAlive()
        {
            return mAlive;
        }

        public int GetX()
        {
            return (int)mX;
        }

        public int GetY()
        {
            return (int)mY;
        }

        public void Kill()
        {
            mAlive = false;
        }

        public void Update()
        {
            if (Utility.GetKeyState(ConsoleKey.NumPad8))
                mY -= Speed;
            else if (Utility.GetKeyState(ConsoleKey.NumPad5))
                mY += Speed;
            else if (Utility.GetKeyState(ConsoleKey.NumPad4))
                mX -= Speed;
            else if (Utility.GetKeyState(ConsoleKey.NumPad6))
                mX += Speed;

            if (mY < 0)
                mY = mY + 1;
            else if (mY > Console.WindowHeight - 1)
                mY = Console.WindowHeight - 1;

            
            if (mX >= Console.WindowWidth)
                mX = mX - 1 ;
            else if (mX < Console.WindowWidth - (Console.WindowWidth / 4))
                mX = Console.WindowWidth - (Console.WindowWidth / 4);


            if (Utility.GetKeyState(ConsoleKey.NumPad0))
            {
                if (!IsAlive()) return;
                if (mFireTimer.ElapsedMilliseconds > FireRate)
                {
                    //if (Utility.Rand() % 5 != 0)
                    TheGame.FireBullet((int)mX - 1, (int)mY, Bullet.Type.Player2);
                    mFireTimer.Restart();
                }
            }

        }

        public void Draw()
        {
            if (!IsAlive()) return;
            Console.SetCursorPosition((int)mX, (int)mY);
            ConsoleColor prev = Console.ForegroundColor;
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write('◄');
            Console.ForegroundColor = prev;
        }
    }
}
