﻿using System;
using System.Diagnostics;
using FSPG;


namespace Gun_Master_Duel
{
    class Player1
    {
        GamePlay TheGame;
        const float Speed = 0.75f;
        const int FireRate = 200;
        float mX;
        float mY;
        bool mAlive;
        Stopwatch mFireTimer;

        public Player1(GamePlay game)
        {
            TheGame = game;
            mFireTimer = new Stopwatch();

            mX = 0 + 1;
            mY = Console.WindowHeight /2 ;

            mAlive = true;
            mFireTimer.Start();
        }

        public bool IsAlive()
        {
            return mAlive;
        }

        public int GetX()
        {
            return (int)mX;
        }

        public int GetY()
        {
            return (int)mY;
        }

        public void Kill()
        {
            mAlive = false;
        }

        public void Update()
        {
            if (Utility.GetKeyState(ConsoleKey.W))
                mY -= Speed;
            else if (Utility.GetKeyState(ConsoleKey.S))
                mY += Speed;
            else if (Utility.GetKeyState(ConsoleKey.A))
                mX -= Speed;
            else if (Utility.GetKeyState(ConsoleKey.D))
                mX += Speed;

            if (mY < 0)
                mY = 0;
            else if (mY > Console.WindowHeight - 1)
                mY = Console.WindowHeight - 1;

            if (mX < 0)
                mX = 0;
            
            else if (mX > (Console.WindowWidth / 4) - 1)
                mX = (Console.WindowWidth / 4) - 1 ;


            if (Utility.GetKeyState(ConsoleKey.Spacebar))
            {
                if (!IsAlive()) return;
                if (mFireTimer.ElapsedMilliseconds > FireRate)
                {
                    //if (Utility.Rand() % 5 != 0)
                    TheGame.FireBullet((int)mX -1, (int)mY, Bullet.Type.Player1);
                    mFireTimer.Restart();
                }
            }

        }

        public void Draw()
        {
            
            if (!IsAlive()) return;
            Console.SetCursorPosition((int)mX, (int)mY);
            ConsoleColor prev = Console.ForegroundColor;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write('►');
            Console.ForegroundColor = prev;
        }
    }
}
