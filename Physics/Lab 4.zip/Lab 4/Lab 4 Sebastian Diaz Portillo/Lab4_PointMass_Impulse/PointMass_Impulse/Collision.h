
#ifndef _COLLISION_H
#define _COLLISION_H


class Collision
{
   Collision();
   ~Collision();


