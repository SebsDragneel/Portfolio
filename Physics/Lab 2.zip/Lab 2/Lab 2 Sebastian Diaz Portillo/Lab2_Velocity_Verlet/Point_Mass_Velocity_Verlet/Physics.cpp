

#include"Physics.h"



Physics::Physics()
{

}

Physics::~Physics() 
{

}


void Physics::Update(float dt)
{        
	// sum the forces applied to the ball   to TotalFoce= Force + Weight ( Newton's  second law) 
	totalForces = force + weight;
	// using newton second law, m*a=F calculate a=F/m   
	acceleration = totalForces / mass;

		// use Velocity Verlet Position equation to compute the future position: r(t+dt)=r(t)+ v(t0)*dt + 0.5*a(t)dt*dt 
	position = position + velocity*dt + 0.5f*acceleration*dt*dt;
       
		// use Velocity Verlet velocity equation to compute the future velocity: v(t+dt)=v(t)+ ( a(t) + a(t+dt))/2
         // that is : new velocity = old velocity + 0.5*(current acceleration + next acceleration)*deltaTime
	velocity = velocity + 0.5*(prevAcceleration + acceleration)*dt;

	     // set the body previous acceleration(=prevAcceleration) equal to the new acceleration(=acceleration)
	prevAcceleration = acceleration;
          
	    // using DirectX built-in translation matrix,  D3DXMatrixTranslation(), to move the particle.The referenced matrix name will be WorldMatrix.
	D3DXMatrixTranslation(&WorldMatrix, position.x, position.y, position.z);

   
}
