
#ifndef _MODEL_H
#define _MODEL_H

class GameModel{
	
private:
	    struct 


public:
	GameModel();
    GameModel(const GameModel& theModel)