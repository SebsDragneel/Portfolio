﻿namespace Game_of_Life_Sebastian_Diaz
{
    partial class Options_Dialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Tab_Controll = new System.Windows.Forms.TabControl();
            this.General_Tab = new System.Windows.Forms.TabPage();
            this.Height_Label = new System.Windows.Forms.Label();
            this.Width_Label = new System.Windows.Forms.Label();
            this.TimerInterval_Label = new System.Windows.Forms.Label();
            this.Height_NumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.Width_NumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.TimerInterval_NumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.View_Tab = new System.Windows.Forms.TabPage();
            this.LiveCellColor_Label = new System.Windows.Forms.Label();
            this.BackgroundColor_Label = new System.Windows.Forms.Label();
            this.GridColor_Label = new System.Windows.Forms.Label();
            this.LiveCell_Button = new System.Windows.Forms.Button();
            this.BackgroundColor_Button = new System.Windows.Forms.Button();
            this.GridColor_Button = new System.Windows.Forms.Button();
            this.Advanced_Tab = new System.Windows.Forms.TabPage();
            this.BoundaryType_GroupBox = new System.Windows.Forms.GroupBox();
            this.Infinite_RadioButton = new System.Windows.Forms.RadioButton();
            this.Finite_RadioButton = new System.Windows.Forms.RadioButton();
            this.Toroidal_RadioButton = new System.Windows.Forms.RadioButton();
            this.Ok_Button = new System.Windows.Forms.Button();
            this.Cancel_Button = new System.Windows.Forms.Button();
            this.Tab_Controll.SuspendLayout();
            this.General_Tab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Height_NumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Width_NumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TimerInterval_NumericUpDown)).BeginInit();
            this.View_Tab.SuspendLayout();
            this.Advanced_Tab.SuspendLayout();
            this.BoundaryType_GroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // Tab_Controll
            // 
            this.Tab_Controll.Controls.Add(this.General_Tab);
            this.Tab_Controll.Controls.Add(this.View_Tab);
            this.Tab_Controll.Controls.Add(this.Advanced_Tab);
            this.Tab_Controll.Dock = System.Windows.Forms.DockStyle.Top;
            this.Tab_Controll.Location = new System.Drawing.Point(0, 0);
            this.Tab_Controll.Name = "Tab_Controll";
            this.Tab_Controll.SelectedIndex = 0;
            this.Tab_Controll.Size = new System.Drawing.Size(451, 282);
            this.Tab_Controll.TabIndex = 0;
            // 
            // General_Tab
            // 
            this.General_Tab.Controls.Add(this.Height_Label);
            this.General_Tab.Controls.Add(this.Width_Label);
            this.General_Tab.Controls.Add(this.TimerInterval_Label);
            this.General_Tab.Controls.Add(this.Height_NumericUpDown);
            this.General_Tab.Controls.Add(this.Width_NumericUpDown);
            this.General_Tab.Controls.Add(this.TimerInterval_NumericUpDown);
            this.General_Tab.Location = new System.Drawing.Point(4, 22);
            this.General_Tab.Name = "General_Tab";
            this.General_Tab.Padding = new System.Windows.Forms.Padding(3);
            this.General_Tab.Size = new System.Drawing.Size(443, 256);
            this.General_Tab.TabIndex = 0;
            this.General_Tab.Text = "General";
            this.General_Tab.UseVisualStyleBackColor = true;
            // 
            // Height_Label
            // 
            this.Height_Label.AutoSize = true;
            this.Height_Label.Location = new System.Drawing.Point(8, 80);
            this.Height_Label.Name = "Height_Label";
            this.Height_Label.Size = new System.Drawing.Size(131, 13);
            this.Height_Label.TabIndex = 5;
            this.Height_Label.Text = "Height of Universe in Cells";
            // 
            // Width_Label
            // 
            this.Width_Label.AutoSize = true;
            this.Width_Label.Location = new System.Drawing.Point(8, 54);
            this.Width_Label.Name = "Width_Label";
            this.Width_Label.Size = new System.Drawing.Size(128, 13);
            this.Width_Label.TabIndex = 4;
            this.Width_Label.Text = "Width of Universe in Cells";
            // 
            // TimerInterval_Label
            // 
            this.TimerInterval_Label.AutoSize = true;
            this.TimerInterval_Label.Location = new System.Drawing.Point(8, 26);
            this.TimerInterval_Label.Name = "TimerInterval_Label";
            this.TimerInterval_Label.Size = new System.Drawing.Size(136, 13);
            this.TimerInterval_Label.TabIndex = 3;
            this.TimerInterval_Label.Text = "Timer Interval in Millisecons";
            // 
            // Height_NumericUpDown
            // 
            this.Height_NumericUpDown.Location = new System.Drawing.Point(151, 78);
            this.Height_NumericUpDown.Name = "Height_NumericUpDown";
            this.Height_NumericUpDown.Size = new System.Drawing.Size(48, 20);
            this.Height_NumericUpDown.TabIndex = 2;
            this.Height_NumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Height_NumericUpDown.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // Width_NumericUpDown
            // 
            this.Width_NumericUpDown.Location = new System.Drawing.Point(151, 52);
            this.Width_NumericUpDown.Name = "Width_NumericUpDown";
            this.Width_NumericUpDown.Size = new System.Drawing.Size(48, 20);
            this.Width_NumericUpDown.TabIndex = 1;
            this.Width_NumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Width_NumericUpDown.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // TimerInterval_NumericUpDown
            // 
            this.TimerInterval_NumericUpDown.Location = new System.Drawing.Point(151, 24);
            this.TimerInterval_NumericUpDown.Name = "TimerInterval_NumericUpDown";
            this.TimerInterval_NumericUpDown.Size = new System.Drawing.Size(48, 20);
            this.TimerInterval_NumericUpDown.TabIndex = 0;
            this.TimerInterval_NumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TimerInterval_NumericUpDown.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            // 
            // View_Tab
            // 
            this.View_Tab.Controls.Add(this.LiveCellColor_Label);
            this.View_Tab.Controls.Add(this.BackgroundColor_Label);
            this.View_Tab.Controls.Add(this.GridColor_Label);
            this.View_Tab.Controls.Add(this.LiveCell_Button);
            this.View_Tab.Controls.Add(this.BackgroundColor_Button);
            this.View_Tab.Controls.Add(this.GridColor_Button);
            this.View_Tab.Location = new System.Drawing.Point(4, 22);
            this.View_Tab.Name = "View_Tab";
            this.View_Tab.Padding = new System.Windows.Forms.Padding(3);
            this.View_Tab.Size = new System.Drawing.Size(443, 256);
            this.View_Tab.TabIndex = 1;
            this.View_Tab.Text = "View";
            this.View_Tab.UseVisualStyleBackColor = true;
            // 
            // LiveCellColor_Label
            // 
            this.LiveCellColor_Label.AutoSize = true;
            this.LiveCellColor_Label.Location = new System.Drawing.Point(63, 89);
            this.LiveCellColor_Label.Name = "LiveCellColor_Label";
            this.LiveCellColor_Label.Size = new System.Drawing.Size(74, 13);
            this.LiveCellColor_Label.TabIndex = 6;
            this.LiveCellColor_Label.Text = "Live Cell Color";
            // 
            // BackgroundColor_Label
            // 
            this.BackgroundColor_Label.AutoSize = true;
            this.BackgroundColor_Label.Location = new System.Drawing.Point(63, 60);
            this.BackgroundColor_Label.Name = "BackgroundColor_Label";
            this.BackgroundColor_Label.Size = new System.Drawing.Size(92, 13);
            this.BackgroundColor_Label.TabIndex = 5;
            this.BackgroundColor_Label.Text = "Background Color";
            // 
            // GridColor_Label
            // 
            this.GridColor_Label.AutoSize = true;
            this.GridColor_Label.Location = new System.Drawing.Point(63, 31);
            this.GridColor_Label.Name = "GridColor_Label";
            this.GridColor_Label.Size = new System.Drawing.Size(53, 13);
            this.GridColor_Label.TabIndex = 4;
            this.GridColor_Label.Text = "Grid Color";
            // 
            // LiveCell_Button
            // 
            this.LiveCell_Button.Location = new System.Drawing.Point(22, 84);
            this.LiveCell_Button.Name = "LiveCell_Button";
            this.LiveCell_Button.Size = new System.Drawing.Size(35, 23);
            this.LiveCell_Button.TabIndex = 2;
            this.LiveCell_Button.UseVisualStyleBackColor = true;
            this.LiveCell_Button.Click += new System.EventHandler(this.LiveCell_Button_Click);
            // 
            // BackgroundColor_Button
            // 
            this.BackgroundColor_Button.Location = new System.Drawing.Point(22, 55);
            this.BackgroundColor_Button.Name = "BackgroundColor_Button";
            this.BackgroundColor_Button.Size = new System.Drawing.Size(35, 23);
            this.BackgroundColor_Button.TabIndex = 1;
            this.BackgroundColor_Button.UseVisualStyleBackColor = true;
            this.BackgroundColor_Button.Click += new System.EventHandler(this.BackgroundColor_Button_Click);
            // 
            // GridColor_Button
            // 
            this.GridColor_Button.Location = new System.Drawing.Point(22, 26);
            this.GridColor_Button.Name = "GridColor_Button";
            this.GridColor_Button.Size = new System.Drawing.Size(35, 23);
            this.GridColor_Button.TabIndex = 0;
            this.GridColor_Button.UseVisualStyleBackColor = true;
            this.GridColor_Button.Click += new System.EventHandler(this.GridColor_Button_Click);
            // 
            // Advanced_Tab
            // 
            this.Advanced_Tab.Controls.Add(this.BoundaryType_GroupBox);
            this.Advanced_Tab.Location = new System.Drawing.Point(4, 22);
            this.Advanced_Tab.Name = "Advanced_Tab";
            this.Advanced_Tab.Size = new System.Drawing.Size(443, 256);
            this.Advanced_Tab.TabIndex = 2;
            this.Advanced_Tab.Text = "Advanced";
            this.Advanced_Tab.UseVisualStyleBackColor = true;
            // 
            // BoundaryType_GroupBox
            // 
            this.BoundaryType_GroupBox.Controls.Add(this.Infinite_RadioButton);
            this.BoundaryType_GroupBox.Controls.Add(this.Finite_RadioButton);
            this.BoundaryType_GroupBox.Controls.Add(this.Toroidal_RadioButton);
            this.BoundaryType_GroupBox.Location = new System.Drawing.Point(25, 22);
            this.BoundaryType_GroupBox.Name = "BoundaryType_GroupBox";
            this.BoundaryType_GroupBox.Size = new System.Drawing.Size(113, 93);
            this.BoundaryType_GroupBox.TabIndex = 0;
            this.BoundaryType_GroupBox.TabStop = false;
            this.BoundaryType_GroupBox.Text = "Boundary Type";
            // 
            // Infinite_RadioButton
            // 
            this.Infinite_RadioButton.AutoSize = true;
            this.Infinite_RadioButton.Location = new System.Drawing.Point(7, 61);
            this.Infinite_RadioButton.Name = "Infinite_RadioButton";
            this.Infinite_RadioButton.Size = new System.Drawing.Size(56, 17);
            this.Infinite_RadioButton.TabIndex = 2;
            this.Infinite_RadioButton.Text = "Infinite";
            this.Infinite_RadioButton.UseVisualStyleBackColor = true;
            // 
            // Finite_RadioButton
            // 
            this.Finite_RadioButton.AutoSize = true;
            this.Finite_RadioButton.Location = new System.Drawing.Point(7, 38);
            this.Finite_RadioButton.Name = "Finite_RadioButton";
            this.Finite_RadioButton.Size = new System.Drawing.Size(50, 17);
            this.Finite_RadioButton.TabIndex = 1;
            this.Finite_RadioButton.Text = "Finite";
            this.Finite_RadioButton.UseVisualStyleBackColor = true;
            // 
            // Toroidal_RadioButton
            // 
            this.Toroidal_RadioButton.AutoSize = true;
            this.Toroidal_RadioButton.Checked = true;
            this.Toroidal_RadioButton.Location = new System.Drawing.Point(7, 19);
            this.Toroidal_RadioButton.Name = "Toroidal_RadioButton";
            this.Toroidal_RadioButton.Size = new System.Drawing.Size(63, 17);
            this.Toroidal_RadioButton.TabIndex = 0;
            this.Toroidal_RadioButton.TabStop = true;
            this.Toroidal_RadioButton.Text = "Toroidal";
            this.Toroidal_RadioButton.UseVisualStyleBackColor = true;
            // 
            // Ok_Button
            // 
            this.Ok_Button.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.Ok_Button.Location = new System.Drawing.Point(4, 288);
            this.Ok_Button.Name = "Ok_Button";
            this.Ok_Button.Size = new System.Drawing.Size(75, 23);
            this.Ok_Button.TabIndex = 1;
            this.Ok_Button.Text = "Ok";
            this.Ok_Button.UseVisualStyleBackColor = true;
            this.Ok_Button.Click += new System.EventHandler(this.Ok_Button_Click);
            // 
            // Cancel_Button
            // 
            this.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Cancel_Button.Location = new System.Drawing.Point(85, 288);
            this.Cancel_Button.Name = "Cancel_Button";
            this.Cancel_Button.Size = new System.Drawing.Size(75, 23);
            this.Cancel_Button.TabIndex = 2;
            this.Cancel_Button.Text = "Cancel";
            this.Cancel_Button.UseVisualStyleBackColor = true;
            this.Cancel_Button.Click += new System.EventHandler(this.Cancel_Button_Click);
            // 
            // Options_Dialog
            // 
            this.AcceptButton = this.Ok_Button;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.CancelButton = this.Cancel_Button;
            this.ClientSize = new System.Drawing.Size(451, 314);
            this.Controls.Add(this.Cancel_Button);
            this.Controls.Add(this.Ok_Button);
            this.Controls.Add(this.Tab_Controll);
            this.MaximizeBox = false;
            this.Name = "Options_Dialog";
            this.Text = "Options";
            this.Tab_Controll.ResumeLayout(false);
            this.General_Tab.ResumeLayout(false);
            this.General_Tab.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Height_NumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Width_NumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TimerInterval_NumericUpDown)).EndInit();
            this.View_Tab.ResumeLayout(false);
            this.View_Tab.PerformLayout();
            this.Advanced_Tab.ResumeLayout(false);
            this.BoundaryType_GroupBox.ResumeLayout(false);
            this.BoundaryType_GroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl Tab_Controll;
        private System.Windows.Forms.TabPage General_Tab;
        private System.Windows.Forms.TabPage View_Tab;
        private System.Windows.Forms.Button Ok_Button;
        private System.Windows.Forms.Button Cancel_Button;
        private System.Windows.Forms.Label Height_Label;
        private System.Windows.Forms.Label Width_Label;
        private System.Windows.Forms.Label TimerInterval_Label;
        private System.Windows.Forms.NumericUpDown Height_NumericUpDown;
        private System.Windows.Forms.NumericUpDown Width_NumericUpDown;
        private System.Windows.Forms.NumericUpDown TimerInterval_NumericUpDown;
        private System.Windows.Forms.TabPage Advanced_Tab;
        private System.Windows.Forms.Label LiveCellColor_Label;
        private System.Windows.Forms.Label BackgroundColor_Label;
        private System.Windows.Forms.Label GridColor_Label;
        private System.Windows.Forms.Button LiveCell_Button;
        private System.Windows.Forms.Button BackgroundColor_Button;
        private System.Windows.Forms.Button GridColor_Button;
        private System.Windows.Forms.GroupBox BoundaryType_GroupBox;
        private System.Windows.Forms.RadioButton Infinite_RadioButton;
        private System.Windows.Forms.RadioButton Finite_RadioButton;
        private System.Windows.Forms.RadioButton Toroidal_RadioButton;
    }
}