﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

namespace Game_of_Life_Sebastian_Diaz
{
    public partial class Form1 : Form
    {

        //Global Variables
        bool[,] universe = new bool[100, 100];
        bool[,] scratchpad = new bool[100, 100];
        Timer timer = new Timer();
        int Generations = 0;
        int mInterval = 20;
        int mAlive;
        int mSeed = 0;
        Color Background = Properties.Settings.Default.PanelColor;
        SolidBrush cellcolor = new SolidBrush(Properties.Settings.Default.LivigCellColor);
        Pen gridcolor = new Pen(Properties.Settings.Default.GrdColor);
        bool Toroidal = true;
        bool Finite = false;

        // Form 1 Constructor
        public Form1()
        {
            InitializeComponent();
            // Set Interval  and tick of the timer and se enabled to false
            Pause_Button.Enabled = false;
            timer.Interval = mInterval;
            timer.Enabled = false;
            timer.Tick += Timer_Tick;
            // Display glogl variables in the status bar
            toolStripStatusLabel1.Text = "Generations = " + Generations.ToString();
            toolStripStatusLabel2.Text = "Interval = " + mInterval.ToString();
            toolStripStatusLabel3.Text = "Alive = " + mAlive.ToString();
            toolStripStatusLabel4.Text = "Seed = " + mSeed.ToString();
            // Set the color of the background to the color in global that is set to the property
            graphicsPanel1.BackColor = Background;

        }
        //Timer
        private void Timer_Tick(object sender, EventArgs e)
        {
            // Call the Next Generation Function
            NextGeneration();
            //Increse number of generations
            Generations++;
            //Update status bar
            toolStripStatusLabel1.Text = "Generations = " + Generations.ToString();
            toolStripStatusLabel2.Text = "Interval = " + mInterval.ToString();
            toolStripStatusLabel3.Text = "Alive = " + mAlive.ToString();
            toolStripStatusLabel4.Text = "Seed = " + mSeed.ToString();

            // Invalidate Paint Event
            graphicsPanel1.Invalidate();

        }

        private void graphicsPanel1_Paint(object sender, PaintEventArgs e)
        {   //floats
            float Width = ((float)graphicsPanel1.ClientSize.Width) / ((float)universe.GetLength(0));
            float Height = ((float)graphicsPanel1.ClientSize.Height) / ((float)universe.GetLength(1));

            for (int y = 0; y < universe.GetLength(1); y++)
            {
                for (int x = 0; x < universe.GetLength(0); x++)
                {
                    //Tis code is to draw with lines, but the program runs slower, so I used rectangles instead
                        /*PointF PX1 = new PointF(0, Height * x);
                        PointF PX2 = new PointF(graphicsPanel1.ClientSize.Width, Height * x);
                        PointF PY1 = new PointF(Width * y, 0);
                        PointF PY2 = new PointF(Width * y, graphicsPanel1.ClientSize.Height);*/

                    //Draw Rectangles for the grid and living cells
                    RectangleF rect = RectangleF.Empty;
                    rect.X = x * Width;
                    rect.Y = y * Height;
                    rect.Width = Width;
                    rect.Height = Height;
                    if (universe[x, y] == true)
                    {
                        e.Graphics.FillRectangle(cellcolor, rect.X, rect.Y, rect.Width, rect.Height);
                    }

                    e.Graphics.DrawRectangle(gridcolor, rect.X, rect.Y, rect.Width, rect.Height);

                    //Draw Rectangles for the grid and living cells
                         /* e.Graphics.DrawLine(Pens.Black, PX1, PX2);
                         e.Graphics.DrawLine(Pens.Black, PY1, PY2);*/
                }
            }
        }

        //MouseClick Event
        private void graphicsPanel1_MouseClick(object sender, MouseEventArgs e)
        {
            //If you do a left click turn off or on the cell and increase alive by one
            if(e.Button == MouseButtons.Left)
            {
                float Width = ((float)graphicsPanel1.ClientSize.Width) / ((float)universe.GetLength(0));
                float Height = ((float)graphicsPanel1.ClientSize.Height) / ((float)universe.GetLength(1));

                float x = e.X / Width;
                float y = e.Y / Height;
                universe[(int)x, (int)y] = !universe[(int)x,(int) y];
                if (universe[(int)x, (int)y] == true)
                    mAlive++;
                else if(universe[(int)x, (int)y] == false)
                    mAlive--;

                //Update Alive Cells Status
                toolStripStatusLabel3.Text = "Alive = " + mAlive.ToString();
                // Invalidate Paint Event
                graphicsPanel1.Invalidate();
            }
        }

        //New Event Button
        private void newToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            //Set all cells to false
            for (int y = 0; y < universe.GetLength(1); y++)
            {
                for (int x = 0; x < universe.GetLength(0); x++)
                {

                    universe[x, y] = false;
                   
                }
            }
            // Stop the timer and set variables to 0
            timer.Stop();
            Generations = 0;
            mAlive = 0;
            mSeed = 0;
            //Update Status Bar
            toolStripStatusLabel1.Text = "Generations = " + Generations.ToString();
            toolStripStatusLabel2.Text = "Interval = " + mInterval.ToString();
            toolStripStatusLabel3.Text = "Alive = " + mAlive.ToString();
            toolStripStatusLabel4.Text = "Seed = " + mSeed.ToString();
            //Invalidate Paint Event
            graphicsPanel1.Invalidate();
        }
       
        //Count Neighbors Function
        private int CountNeighbors(int x, int y)
        {
            int count = 0;

            //Crete Form 2 object and set Form 1 as it's owner

            if (Toroidal == true)
            {

                if (universe[((x - 1) + universe.GetLength(0)) % universe.GetLength(0),(y - 1 + universe.GetLength(1)) % universe.GetLength(1)] == true) { ++count; }
                if (universe[((x - 1 )+ universe.GetLength(0)) % universe.GetLength(0), y] == true) { ++count; }
                if (universe[((x - 1) + universe.GetLength(0)) % universe.GetLength(0),(y + 1) % universe.GetLength(1)] == true) { ++count; }
                if (universe[x,((y - 1) + universe.GetLength(1)) % universe.GetLength(1)] == true) { ++count; }
                if (universe[x,(y + 1) % universe.GetLength(1)] == true) { ++count; }
                if (universe[(x + 1) % universe.GetLength(0),(y - 1 + universe.GetLength(1)) % universe.GetLength(1)] == true) { ++count; }
                if (universe[(x + 1) % universe.GetLength(0),y] == true) { ++count; }
                if (universe[(x + 1) % universe.GetLength(0),(y + 1) % universe.GetLength(1)] == true) { ++count; }
            }
            else if (Finite == true)
            {
                //East
                if (x < universe.GetLength(0) - 1 && universe[x + 1, y] == true)
                    ++count;
                //West
                if (x > 0 && universe[x - 1, y] == true)
                    ++count;
                //South
                if (y < universe.GetLength(1) - 1 && universe[x, y + 1] == true)
                    ++count;
                //North
                if (y > 0 && universe[x, y - 1] == true)
                    ++count;
                //SouthEast
                if (x < universe.GetLength(0) - 1 && y < universe.GetLength(1) - 1 && universe[x + 1, y + 1] == true)
                    ++count;
                //NorthEast
                if (x < universe.GetLength(0) - 1 && y > 0 && universe[x + 1, y - 1] == true)
                    ++count;
                //SouthWest
                if (x > 0 && y < universe.GetLength(1) - 1 && universe[x - 1, y + 1] == true)
                    ++count;
                //NorthWest
                if (x > 0 && y > 0 && universe[x - 1, y - 1] == true)
                    ++count;
            }
            return count;
        }

        //Next Generation Function
        private void NextGeneration()
        { 
            //Define alive 
            mAlive = 0;
            // Call Clear fuction
            Clear();
            //Apply the rules for next generation and finally increase or decreace alive for living and dying cells
                for (int y = 0; y < universe.GetLength(1); y++)
                {
                    for (int x = 0; x < universe.GetLength(0); x++)
                    {
                        if (universe[x, y] == true)
                        {
                            if (CountNeighbors(x, y) < 2)
                            {
                                //Rule #1:
                                scratchpad[x, y] = false;
                                mAlive--;
                            }
                            if (CountNeighbors(x, y) > 3)
                            {
                                //Rule #2:
                                scratchpad[x, y] = false;
                                mAlive--;
                            }
                            if (CountNeighbors(x, y) == 2 || CountNeighbors(x, y) == 3)
                            {
                                //Rule #3:
                                scratchpad[x, y] = universe[x, y];
                                mAlive++;
                            }
                        }
                        //Rule #4:
                        else
                        {
                            if (CountNeighbors(x, y) == 3)
                            {
                                scratchpad[x, y] = true;
                                mAlive++;
                            }
                        }

                   


                    }
                }
                // Swap between universe and scratchpad
            bool[,] temp = universe;
            universe = scratchpad;
            scratchpad = temp;
        }

        //Start Button Event
        private void Start_Button_Click(object sender, EventArgs e)
        {
            // Disable start and Enable pause
            while ( Start_Button.Enabled == true)
            {
                Start_Button.Enabled = false;
                Pause_Button.Enabled = true;
            }
           
            //start timer
            timer.Start();
        }

        //Start Button Event
        private void Pause_Button_Click(object sender, EventArgs e)
        {
            // Disable pause and Enable start
            while(Pause_Button.Enabled == true)
            {
                Pause_Button.Enabled = false;
                Start_Button.Enabled = true;
            }
            
            //Stop timer
            timer.Stop();
        }

        // Next Button Event
        private void Next_Button_Click(object sender, EventArgs e)
        {
            //Call Next Generation function
            NextGeneration();
            //Update Generations
            Generations++;
            //Invalidate Paint Event
            graphicsPanel1.Invalidate();
            // Update Status bar
            toolStripStatusLabel1.Text = "Generations = " + Generations.ToString();
            toolStripStatusLabel2.Text = "Interval = " + mInterval.ToString();
            toolStripStatusLabel3.Text = "Alive = " + mAlive.ToString();
            toolStripStatusLabel4.Text = "Seed = " + mSeed.ToString();


        }

        //Clear function
        private void Clear()
        {
           // Loop through the universe and set all set to false
            for (int y = 0; y < universe.GetLength(1); y++)
            {
                for (int x = 0; x < universe.GetLength(0); x++)
                {
                    scratchpad[x, y] = false;
                }
            }
        }

        //Options StoolTrip Meu Button Event
        private void optionsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Crete Form 2 object and set Form 1 as it's owner
            Options_Dialog window = new Options_Dialog();
            window.Owner = this;
            //Call properties from form 2 and set them equal to their respective variables
            window.SetWidth = universe.GetLength(0);
            window.SetHeight = universe.GetLength(1);
            window.SetInterval = mInterval;

            // Open window , set colors from Form2 and  Invalidat Paint Function
            if (window.ShowDialog() == DialogResult.OK)
            {
                Background = Properties.Settings.Default.PanelColor;
                graphicsPanel1.BackColor = Background;
                cellcolor = new SolidBrush(Properties.Settings.Default.LivigCellColor);
                gridcolor = new Pen(Properties.Settings.Default.GrdColor);
                
                graphicsPanel1.Invalidate();
            }
           
        }

        //Information Resize function
        public void InformationResize(int w, int h,int inter)
        {
            // Set universe  and interval to the values from Form 2
            universe = new bool[w, h];
            scratchpad = new bool[w, h];
            timer.Interval = inter;
            mInterval = inter;
         //Update Status Bar and Invalidate Paint Event
            toolStripStatusLabel2.Text = "Interval = " + mInterval.ToString();
            graphicsPanel1.Invalidate();
        }

        //Save Toolstrip Butoon Event
        private void saveToolStripButton_Click(object sender, EventArgs e)
        {
            // Create a SaveFileDialog Object and set filters
            SaveFileDialog Save = new SaveFileDialog();
            Save.Filter = "All Files|*.*|Cells|*.cells";
            Save.FilterIndex = 2; Save.DefaultExt = "cells";
            //Open Window 
            if (DialogResult.OK == Save.ShowDialog())
            {
                //Create StreamWriter Object
                StreamWriter Write = new StreamWriter(Save.FileName);

                //Save the living cells with 'O''s and '.' to dead cells
                for (int y = 0; y < universe.GetLength(1); y++)
                {
                    string CurRow = string.Empty;

                    for (int x = 0; x < universe.GetLength(0); x++)
                    {
                        if (universe[x, y] == true)
                        {
                            CurRow += 'O';
                        }
                        if (universe[x, y] == false)
                        {
                            CurRow += '.';
                        }
                    }
                    Write.WriteLine(CurRow);
                }
                //close Stremwriter
                Write.Close();
            }
        }

        private void openToolStripButton_Click(object sender, EventArgs e)
        {
            // Create a OpenFileDialog with respective Filters
            OpenFileDialog Open = new OpenFileDialog();
            Open.Filter = "All Files|*.*|Cells|*.cells";
            Open.FilterIndex = 2; Open.DefaultExt = "cells";

            //Open  "Open" Window
            if (DialogResult.OK == Open.ShowDialog())
            {
                //Crate StreamReader
                StreamReader Read = new StreamReader(Open.FileName);

                int RWidtht = 0;
                int RHight = 0;

                //Read until End of the file

                    while (!Read.EndOfStream)
                {
                    string Row = Read.ReadLine();
                    if (Row.Contains('O') || Row.Contains('.'))
                    {
                        RWidtht = Row.Length;
                        RHight++;
                    }

                }
                //Set Universe and Scratch Path
                universe = new bool[RWidtht, RHight];
                scratchpad = new bool[RWidtht, RHight];
                Read.BaseStream.Seek(0, SeekOrigin.Begin);


                // Read 'O' as alive and '.' as dead
                    int YPosition = 0;
                    while (!Read.EndOfStream)
                    {
                        string Row = Read.ReadLine();

                        if (Row.Contains('O') || Row.Contains('.'))
                        {
                            for (int XPosition = 0; XPosition < Row.Length; XPosition++)
                            {
                                if (Row[XPosition] == 'O')
                                {
                                    universe[XPosition, YPosition] = true;
                                }
                                else if (Row[YPosition] == '.')
                                {
                                    universe[XPosition, YPosition] = false;
                                }
                            }
                            YPosition++;
                        }
                    }
 
                //Close the Stream Writer and Invalidate the Paint Function
                Read.Close();
                graphicsPanel1.Invalidate();
            }

            }

        //Randomize Event
        private void randomizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Creaters a random number and turns cells to alive in a 50 by 50 chance
            int whatever;
            Random r = new Random();

            for (int y = 0; y < universe.GetLength(1); y++)
            {

                for (int x = 0; x < universe.GetLength(0); x++)
                {
                    whatever = r.Next();
                    mSeed = whatever;
                    if (whatever % 2 == 0)
                        universe[x, y] = true;
                    else
                        universe[x, y] = false;
                }

            }
            // Update Status Bar and Invalidate Paint Function
            toolStripStatusLabel4.Text = "Seed = " + mSeed.ToString();
            graphicsPanel1.Invalidate();
                }
        //Exit ToolStrip Event
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Close the Program
            this.Close();
        }

        //Import Event
        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Create a OpenFileDialog with respective Filters
            OpenFileDialog Open = new OpenFileDialog();
            Open.Filter = "All Files|*.*|Cells|*.cells";
            Open.FilterIndex = 2; Open.DefaultExt = "cells";

            //Open  "Open" Window
            if (DialogResult.OK == Open.ShowDialog())
            {
                //Crate StreamReader
                StreamReader Read = new StreamReader(Open.FileName);

                int RWidtht = 0;
                int RHight = 0;

                //Read until End of the file

                while (!Read.EndOfStream)
                {
                    string Row = Read.ReadLine();
                    if (Row.Contains('O') || Row.Contains('.'))
                    {
                        RWidtht = Row.Length;
                        RHight++;
                    }

                }
                //Set Universe and Scratch Path
                universe = new bool[RWidtht, RHight];
                scratchpad = new bool[RWidtht, RHight];
                Read.BaseStream.Seek(0, SeekOrigin.Begin);


                // Read 'O' as alive and '.' as dead
                int YPosition = 0;
                while (!Read.EndOfStream)
                {
                    string Row = Read.ReadLine();

                    if (Row.Contains('O') || Row.Contains('.'))
                    {
                        for (int XPosition = 0; XPosition < Row.Length; XPosition++)
                        {
                            if (Row[XPosition] == 'O')
                            {
                                universe[XPosition, YPosition] = true;
                            }
                            else if (Row[YPosition] == '.')
                            {
                                universe[XPosition, YPosition] = false;
                            }
                        }
                        YPosition++;
                    }
                }

                //Close the Stream Writer and Invalidate the Paint Function
                Read.Close();
                graphicsPanel1.Invalidate();
            }
        }

        private void exampleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("https://www.youtube.com/watch?v=R9Plq-D1gEk");
        }
        // Setting toroidal
        public void SetToroidal()
        {
            Toroidal = true;
            Finite = false;
        }
        // Setting Finite
        public void SetFinite()
        {
            Toroidal = false;
            Finite = true;
        }

        private void sebsPikachuSampleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("https://www.youtube.com/watch?v=CO21DY6uvjg");
        }
    }
}
