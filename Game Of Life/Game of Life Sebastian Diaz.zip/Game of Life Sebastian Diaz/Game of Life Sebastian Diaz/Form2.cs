﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Game_of_Life_Sebastian_Diaz
{
    public partial class Options_Dialog : Form
    {
        // Form 2 Constructor
        public Options_Dialog()
        {
            InitializeComponent();
            // Set Buttons to their properties
            Infinite_RadioButton.Enabled = false;
            GridColor_Button.BackColor = Properties.Settings.Default.GrdColor;
            BackgroundColor_Button.BackColor = Properties.Settings.Default.PanelColor;         
            LiveCell_Button.BackColor = Properties.Settings.Default.LivigCellColor;
        }

        // Ok Button Event
        private void Ok_Button_Click(object sender, EventArgs e)
        {
            // Call Information Rezise Function from Form 1 and set parameters with the NumericUpDown
            ((Form1)this.Owner).InformationResize((int)Width_NumericUpDown.Value, (int)Height_NumericUpDown.Value, (int)TimerInterval_NumericUpDown.Value);

            // Don't know why, using properties for my radio buttons was a mess ,I was debugging for more than 24 hrs, so 
            //I jus change Toroidal and Finite to if statements, although toroidal is the checked when you open the window, the system works perfectly
            if ( Toroidal_RadioButton.Checked == true)
            {
                ((Form1)this.Owner).SetToroidal();
            }
            if(Finite_RadioButton.Checked == true)
            {
                ((Form1)this.Owner).SetFinite();
            }
            //Close Window
            this.Close();
        }

        // Properties for the NumericUpDowns
        public bool CheckToroidal { set { Toroidal_RadioButton.Checked = value; } }
        public bool CheckFinite {set { Toroidal_RadioButton.Checked = value; } }

        public int SetWidth { set { Width_NumericUpDown.Value = value; } }
        public int SetHeight { set { Height_NumericUpDown.Value = value; } }
        public int SetInterval { set { TimerInterval_NumericUpDown.Value = value; } }


        private void Cancel_Button_Click(object sender, EventArgs e)
        {
            //Close Window
            this.Close();
        }

        // Event to set the color of the GridColor property to respective buttons color and save it 
        private void GridColor_Button_Click(object sender, EventArgs e)
        {
            ColorDialog dlg1 = new ColorDialog();
            dlg1.Color = GridColor_Button.BackColor;
            if (DialogResult.OK == dlg1.ShowDialog())
            {
                GridColor_Button.BackColor = dlg1.Color;
                Properties.Settings.Default.GrdColor = GridColor_Button.BackColor;
                Properties.Settings.Default.Save();
            }
        }

        // Event to set the color of the BackgroundColor property to respective buttons color and save it 
        private void BackgroundColor_Button_Click(object sender, EventArgs e)
        {
            ColorDialog dlg2 = new ColorDialog();
            dlg2.Color = BackgroundColor_Button.BackColor;
            if (DialogResult.OK == dlg2.ShowDialog())
            {
                BackgroundColor_Button.BackColor = dlg2.Color;
                Properties.Settings.Default.PanelColor = BackgroundColor_Button.BackColor;
                Properties.Settings.Default.Save();
            }
        }

        // Event to set the color of the LiveCellColor property to respective buttons color and save it 
        private void LiveCell_Button_Click(object sender, EventArgs e)
        {
            ColorDialog dlg3 = new ColorDialog();
            dlg3.Color = LiveCell_Button.BackColor;
            if (DialogResult.OK == dlg3.ShowDialog())
            {
                LiveCell_Button.BackColor = dlg3.Color;
                Properties.Settings.Default.LivigCellColor = LiveCell_Button.BackColor;
                Properties.Settings.Default.Save();
            }
        }
    }
}
