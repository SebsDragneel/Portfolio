﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Modal_Dialog
{
    public partial class Modal_dialog_2 : Form
    {
        public Color Color
        {
            get
            {
              if (GreenButton2.Checked) return Color.Green;
              if (BlueButton3.Checked) return Color.Blue;

              return Color.Red;
            }
            set
            {
                if(value == Color.Green)
                {
                    GreenButton2.Checked = true;
                }
                else if (value == Color.Blue)
                {
                    BlueButton3.Checked = true;
                }
                else if (value == Color.Red)
                {
                    RedButton1.Checked = true;
                }
            }
        }
        public Modal_dialog_2()
        {
            InitializeComponent();

        }
        public string FormTitle { get { return textBoxTitle.Text; } set { textBoxTitle.Text = value; } }
    }
}
