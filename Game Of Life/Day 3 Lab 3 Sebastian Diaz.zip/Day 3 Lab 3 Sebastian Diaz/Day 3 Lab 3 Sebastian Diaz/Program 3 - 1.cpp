#include <iostream>
using namespace std;

int main(void)
{
	int num = 13;

	cout << "Here is the value of num: " << num << '\n';
	cout << "Here is the memory address of num: " << &num <<'\n';

	cout << "What would you like the new value to be? ";
	while (true)
	{
		if (cin >> num)
			break;
		else
		{
			cin.clear();
			cin.ignore(INT_MAX, '\n');

			cout << "You're an idiot.  Please use integers: \n";
		}
	}
	cout << '\n';

	cout << "Here is the value of num: " << num << '\n';
	cout << "Here is the memory address of num: " << &num << '\n';




	cout << "\n\n\n\n\n";
	system("pause");
	return 0;
}
