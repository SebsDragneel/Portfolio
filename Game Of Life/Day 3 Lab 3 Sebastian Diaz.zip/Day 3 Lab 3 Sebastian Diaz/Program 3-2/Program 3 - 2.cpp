#include <Windows.h>

#define _CRTDBG_MAP_ALLOC
#include <cstdlib>
#include <crtdbg.h>
#include <iostream>
using namespace std;

struct Person
{
	char name[32];
	int age;
};

int main(void)
{
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
	_CrtSetBreakAlloc(-1);

	int num = 13;

	cout << "How many records would you like? ";
	int Records = -1;
	while (true)
	{
		if (cin >> Records)
			break;
		else
		{
			cin.clear();
			cin.ignore(INT_MAX, '\n');

			cout << "You're an idiot.  Please use integers: \n";
		}
	}

	Person* people = new Person[Records];
	cin.ignore(INT_MAX, '\n');



	int i = 0;
	for (; i < Records; ++i)
	{

		cout << "What is the name for record " << i + 1 << "? ";
		cin.get(people[i].name, 32, '\n');
		cin.ignore(INT_MAX, '\n');

		cout << "What is the age for record " << i + 1 << "? ";
		cin >> people[i].age;
		cin.ignore(INT_MAX, '\n');

	}

	for (i = 0; i < Records; ++i)
	{
		cout << "Record " << i + 1 << " Name: " << people[i].name << " Age: " << people[i].age << '\n';
	}


	delete[] people;




	cout << "\n\n\n\n\n";
	system("pause");
	return 0;
}
