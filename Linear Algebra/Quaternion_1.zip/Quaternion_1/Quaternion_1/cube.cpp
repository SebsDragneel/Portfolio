
#include"cube.h"
#include "commonFile.h"


Cube::Cube()
{
  cubeTexture=0;
  cubeMesh=0;
  buffer=0;
}

Cube::~Cube()
{
	SAFE_RELEASE(cubeTexture);
	SAFE_RELEASE(cubeMesh);
	SAFE_RELEASE(buffer);
}

void Cube::CreateCube(LPDIRECT3DDEVICE9 theDevice,LPCSTR textureFilename)
{
  // create the box
  D3DXCreateBox(theDevice,5.0f,5.0f,5.0f,&cubeMesh,0);
  //box texture
  D3DXCreateTextureFromFile(theDevice,textureFilename,&cubeTexture);

  cubeMesh->CloneMeshFVF(NULL,FVF,theDevice,&cubeMesh);
  int numberOfVertice=cubeMesh->GetNumVertices()/4;
  cubeMesh->GetVertexBuffer(&buffer);
  CubeVertex* vertex=NULL;
  buffer->Lock(0,0,(void**)&vertex,0);
  for(int i=0;i<numberOfVertice;i++)
  {
	  vertex[4*i].texCoord.x=0;
	  vertex[4*i].texCoord.y=0;

	  vertex[4*i+1].texCoord.x=1;
	  vertex[4*i+1].texCoord.y=0;

	  vertex[4*i+2].texCoord.x=1;
	  vertex[4*i+2].texCoord.y=1;

	  vertex[4*i+3].texCoord.x=0;
	  vertex[4*i+3].texCoord.y=1;
  }

  buffer->Unlock();



  // create the box texture state
	theDevice->SetSamplerState(0,D3DSAMP_MAGFILTER,D3DTEXF_LINEAR);
	theDevice->SetSamplerState(0,D3DSAMP_MINFILTER,D3DTEXF_LINEAR);
	theDevice->SetSamplerState(0,D3DSAMP_MIPFILTER,D3DTEXF_POINT);
	
}

void Cube::Render(LPDIRECT3DDEVICE9 theDevice)
{
	
    theDevice->GetTransform(D3DTS_WORLD, &saveWorldMatrix);
	theDevice->SetTransform(D3DTS_WORLD, &worldMatrix);
	theDevice->SetMaterial(&WHITEMATERIAL);
	theDevice->SetTexture(0,cubeTexture);
	cubeMesh->DrawSubset(0);
    theDevice->SetTransform(D3DTS_WORLD,&saveWorldMatrix);
}

void Cube::Update(float dt)
{
    static float angle=0.0f;
	D3DXVECTOR3 v; // axis of rotation vector
	D3DXQUATERNION q; // box quaternion orientation
	D3DXMATRIX M; // box matrix orientation 
	D3DXMATRIX translate; // box translation matrix
	// set v=(1,1,1);

	// normalize v by calling D3DXVec3Normalize(D3DXMATRIX *a,D3DXMATRIX *b);
	D3DXVec3Normalize(&v,&v);

	angle=angle + dt;
	// write the IF condition to set angle = 0 if angle=2PI 
	if (angle == 2 * D3DX_PI)
		angle = 0;
	// construct the quaternion q by calling the constructor D3DXQUATERNION(x,y,z,w);
	// q=[cos(a/2) ,v*sin(a/2)]=[cos(a/2) ,v.x*sin(a/2), v.y*sin(a/2),v.z*sin(a/2)]
	 q = D3DXQUATERNION(cosf(angle / 2), v.x*sinf(angle / 2), v.y*sinf(angle / 2), v.z*sinf(angle / 2));
	// orthonormalize the quaternion q by calling D3DXQuaternionNormalize(..*Q , ..*Q);
	D3DXQuaternionNormalize(&q, &q);
	//  transform the quaternion to a rotation matrix 
	 // by calling D3DXMatrixRotationQuaternion(D3DXMATRIX *mat,D3DXQUATERNION *quat)
	D3DXMatrixRotationQuaternion(&M, &q);
	// transpose the built rotation matrix by calling
    //D3DXMatrixTranspose(D3DXMATRIX *mat,D3DXMATRIX *mat), quaternion are Right-handed
	//and DirectX is left-handed API;
	D3DXMatrixTranspose(&M, &M);
	// update the cube position:  newPosition=oldPosition + velocity*dt
	position = position + velocity*dt;
	// create the translation matrix that locate the box in world space
  //  by calling D3DXMatrixTranslation(D3DXMATRIX *M,float x,..y,..z)
	D3DXMatrixTranslation(&translate, position.x, position.y, position.z);
	// set the world matrix as the concatenation of the rotation matrix(M)
  // and the translation matrix (translate)
	worldMatrix = M * translate;

}
  