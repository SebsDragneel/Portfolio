/**
* @file EngineMath.cpp
*
*/

#include "EngineMath.h"

//////////////////////////////////////////////////////////////////////////
// Common math functions
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////
// General Utility functions
//////////////////////////////////////////////////////////////////////////

// Are two floating point numbers equal to each other
// Floating Point Error Safe
//
// IN:		a		The first number
//			b		The second number
//
// RETURN: TRUE iff |a-b| < Tolerance
//
// NOTE:	EPSILON is tolerance
bool IsEqual(float a, float b)
{
	// NOTE: Do not modify.
	return fabs(a - b) < EPSILON;
}

// Is a floating point value equal to zero
// Floating Point Error Safe
//
// IN:		a		The number to check
//
// RETURN:	TRUE iff |a| < Tolerance
//
// NOTE:	Tolerance set by EPSILON
bool IsZero(float a)
{
	// NOTE: Do not modify
	return (fabs(a))<EPSILON;
}

// RETURN: MAX of two numbers
float Max(float a, float b)
{
	// NOTE: Do not modify.
	return (a > b) ? a : b;
}

// RETURN: MIN of two numbers
float Min(float a, float b)
{
	// NOTE: Do not modify.
	return (a < b) ? a : b;
}

// RETURN: Converts input to radian measure
float Degrees_To_Radians(float Deg)
{
	// NOTE: Do not modify.
	return Deg * PI / 180.0f;
}

// RETURN: Converts input to degree measure
float Radians_To_Degrees(float Rad)
{
	// NOTE: Do not modify.
	return Rad * 180.0f / PI;
}
////////////////////////////////////////////////////////////////////////
// Linear Algebra Functions Day 1
///////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
// Vector Functions
//////////////////////////////////////////////////////////////////////////

// Check if two TVECTOR's are equal to each other
//
// IN:		v		First Vector
//			w		Second Vector
//
// RETURN:  True if v==w, False otherwise
//
// NOTE:	Use's all four components
//			Should be floating point error safe.
bool Vector_IsEqual(TVECTOR v, TVECTOR w)
{
	if (IsEqual(v.x, w.x) && IsEqual(v.y, w.y) && IsEqual(v.z, w.z) && IsEqual(v.w, w.w))
		return true;

	return false;
}

// ADD two TVECTOR's togother
//
// IN:		v		First Vector. Left Hand Side
//			w		Second Vector. Right Hand Side
//
// RETURN:  v + w
//
// NOTE:	Use's all four components
TVECTOR Vector_Add(TVECTOR v, TVECTOR w)
{
	v.x = v.x + w.x;
	v.y = v.y + w.y;
	v.z = v.z + w.z;
	v.w = v.w + w.w;

	return v;
}

// SUBTRACT one TVECTOR from another
//
// IN:		v		First Vector. Left Hand Side
//			w		Second Vector. Right Hand Side
//
// RETURN:  v - w
//
// NOTE:	Use's all four components
TVECTOR Vector_Sub(TVECTOR v, TVECTOR w)
{
	v.x = v.x - w.x;
	v.y = v.y - w.y;
	v.z = v.z - w.z;
	v.w = v.w - w.w;

	return v;
}

// MULTIPLY all four components of a TVECTOR by a scalar
//
// IN:		v		The vector to scale
//			s		The value to scale by
//
// RETURN:  s * v
TVECTOR Vector_Scalar_Multiply(TVECTOR v, float s)
{
	v.x = v.x * s;
	v.y = v.y * s;
	v.z = v.z * s;
	v.w = v.w * s;

	return v;
}

// NEGATE all the components of a TVECTOR
//
// IN:		v		The vector to negate
//
// RETURN:	-1 * v
//
// NOTE:	Use's all four components
TVECTOR Vector_Negate(TVECTOR v)
{
	v.x = v.x * -1;
	v.y = v.y * -1;
	v.z = v.z * -1;
	v.w = v.w * -1;

	return v;
}

// Perform a Dot Product on two TVECTOR's
//
// IN:		v		First Vector. Left Hand Side
//			w		Second Vector. Right Hand Side
//
// RETURN:  v (DOT) w
//
// NOTE:	Use's all four components
float Vector_Dot(TVECTOR v, TVECTOR w)
{
	float mTemp = 0.0f;
	v.x = v.x * w.x;
	v.y = v.y * w.y;
	v.z = v.z * w.z;
	v.w = v.w * w.w;
	mTemp =  v.x + v.y + v.z + v.w;

	return  mTemp;
}

// Perform a Cross Product on two TVECTOR's
//
// IN:		v		First Vector. Left Hand Side
//			w		Second Vector. Right Hand Side
//
// RETURN:  v (CROSS) w
//
// NOTE:	The w-component of each vector is not used.
//			The resultant vector will have a w-component of zero.
TVECTOR Vector_Cross(TVECTOR v, TVECTOR w)
{ 
	TVECTOR mTemp;
	mTemp.x = (v.y * w.z) - (v.z * w.y);
	mTemp.y = (v.z * w.x) - (v.x * w.z);
	mTemp.z = (v.x * w.y) - (v.y * w.x);
	mTemp.w = 0;

	return mTemp;
}

// Find the squared length of a TVECTOR
//
// IN:		v		The vector to find the squared length of
//
// RETURN:	Squared Length of TVECTOR
//
// NOTE:	Use's all four components
float Vector_LengthSq(TVECTOR v)
{
	float mTemp = 0.0f;
	mTemp = pow(v.x , 2) + pow(v.y , 2) + pow(v.z , 2) + pow(v.w, 2);

	return mTemp;
}

// Find the length of a TVECTOR
//
// IN:		v		The vector to find the length of
//
// RETURN:	Length of TVECTOR
//
// NOTE:	Use's all four components
float Vector_Length(TVECTOR v)
{
	float mTemp = 0.0f;
	mTemp = sqrt(Vector_LengthSq(v));

	return mTemp;
}

// Normalize a TVECTOR
//
// IN:		v		The vector to normalize
//
// RETURN:	Normalized version of v
//
// NOTE:	Use's all four components
TVECTOR Vector_Normalize(TVECTOR v)
{
	TVECTOR mTemp;
	mTemp.x = v.x / Vector_Length(v);
	mTemp.y = v.y / Vector_Length(v);
	mTemp.z = v.z / Vector_Length(v);
	mTemp.w = v.w / Vector_Length(v);

	return mTemp;
}

// Makes a TVECTOR's w-component normalized
//
// IN:		v		The vector (point object) to homogenise
//
// RETURN:	The homogenised vector (point)
//
// NOTE:	If the w-component of the vector is 0 then the
//			function will return a zero vector with a w-component
//			of 0.
TVECTOR Vector_Homogenise(TVECTOR v)
{
	v.x = v.x / v.w;
	v.y = v.y / v.w;
	v.z = v.z / v.w;
	v.w = v.w / v.w;

	if ( IsZero(v.w) == true)
	{
		v.x = 0;
		v.y = 0;
		v.z = 0;
	}

	return v;
}

// Get a TVECTOR made from the maximun components of two TVECTORs
//
// IN:		v		The first vector
//			w		The second vector
//
// RETURN:	A maximized vector
//
// NOTE:	Use's all four components
TVECTOR Vector_Maximize(TVECTOR v, TVECTOR w)
{
	TVECTOR mTemp;
	mTemp.x = Max(v.x, w.x);
	mTemp.y = Max(v.y, w.y);
	mTemp.z = Max(v.z, w.z);
	mTemp.w = Max(v.w, w.w);

	return mTemp;
}

// Get a TVECTOR made from the minimum components of two TVECTOR's
//
// IN:		v		The first vector
//			w		The second vector
//
// RETURN:	A minimum vector
//
// NOTE:	Use's all four components
TVECTOR Vector_Minimize(TVECTOR v, TVECTOR w)
{
	TVECTOR mTemp;
	mTemp.x = Min(v.x, w.x);
	mTemp.y = Min(v.y, w.y);
	mTemp.z = Min(v.z, w.z);
	mTemp.w = Min(v.w, w.w);

	return mTemp;
}

// Get a TVECTOR made from the average of two TVECTORs
//
// IN:		v		The first vector
//			w		The second vector
//
// RETURN:	A vector made from the average of two vectors
//
// NOTE:	Use's all four components

TVECTOR Vector_Average(TVECTOR v, TVECTOR w)
{
	TVECTOR mTemp = Vector_Add(v, w);
	mTemp.x = mTemp.x * 0.5f;
	mTemp.y = mTemp.y * 0.5f;
	mTemp.z = mTemp.z * 0.5f;
	mTemp.w = mTemp.w * 0.5f;

	return mTemp;
}

// Find the angle between two TVECTORs
//
// IN:		v		The first vector
//			w		The second vector
//
// RETURN:  The angle in degrees between the two vectors
//
// NOTE:	If either vector is a zero vector then the return
//			value will be 0.
float Vector_AngleBetween(TVECTOR v, TVECTOR w)
{
	float mTemp = 0.0f;
	mTemp = Radians_To_Degrees(acosf(Vector_Dot(v, w) / (Vector_Length(v) * Vector_Length(w))));

		if ((v.x == 0 && v.y == 0 && v.z == 0 && v.w == 0) || (w.x == 0 && w.y == 0 && w.z == 0 && w.w == 0))
			return 0;
		else
			return mTemp;
}

// Get the distance one TVECTOR points in the direction of another
// TVECTOR
//
// IN:		v		The first vector
//			w		The direction of the component
//
// RETURN:	The distance that v points in the direction of w.
//
// NOTE:	If w or v is a zero vector then the return value is zero.
float Vector_Component(TVECTOR v, TVECTOR w)
{
	float mTemp = 0.0f;
	mTemp = Vector_Dot(v, w) / Vector_Length(w);
	if ((v.x == 0 && v.y == 0 && v.z == 0 && v.w == 0) || (w.x == 0 && w.y == 0 && w.z == 0 && w.w == 0))
		return 0;
	else
		return mTemp;
}

// Get the TVECTOR that represents v projected on w.
//
// IN:		v		The first vector
//			w		The direction of the projection
//
// RETURN:	The projection of v onto w
//
// NOTE:	If w or v is a zero vector then the return value is zero.
TVECTOR Vector_Project(TVECTOR v, TVECTOR w)
{
	TVECTOR mTemp;
	mTemp = Vector_Normalize(w);
	mTemp.x = mTemp.x * Vector_Component(v, w);
	mTemp.y = mTemp.y * Vector_Component(v, w);
	mTemp.z = mTemp.z * Vector_Component(v, w);
	mTemp.w = mTemp.w * Vector_Component(v, w);

	if ((v.x == 0 && v.y == 0 && v.z == 0 && v.w == 0) || (w.x == 0 && w.y == 0 && w.z == 0 && w.w == 0))
	{
		mTemp.x = 0;
		mTemp.y = 0;
		mTemp.z = 0;
		mTemp.w = 0;
	}
		return mTemp;
}

////////////////////////////////////////////////////////////////////////
// Functions Lab  #2
///////////////////////////////////////////////////////////////////////


// Get the reflection of v across w
//
// IN:		v		The vector to reflect
//			w		The "axis" to reflect across
//
// RETURN:	v reflected across w
//
// NOTE:	If w is a zero vector then return -v.
TVECTOR Vector_Reflect(TVECTOR v, TVECTOR w)
{
	//R = 2*(V dot N)*N - V
	float mTempLenght = Vector_Length(w);
	TVECTOR mTempNormalized = Vector_Normalize(w);

	if (IsZero(mTempLenght) == false)
	{
		return Vector_Negate(Vector_Add(Vector_Scalar_Multiply(mTempNormalized, -2 * (Vector_Dot(v,mTempNormalized))), v));
		
	}

	return Vector_Negate(v);
	
}

//////////////////////////////////////////////////////////////////////////
// Matrix Functions
//////////////////////////////////////////////////////////////////////////

// Get a [0] matrix
//
// RETURN: A 0 4x4 matrix
TMATRIX Matrix_Zero(void)
{
	TMATRIX m;
	m._e11 = 0;
	m._e12 = 0;
	m._e13 = 0;
	m._e14 = 0;
	m._e21 = 0;
	m._e22 = 0;
	m._e23 = 0;
	m._e24 = 0;
	m._e31 = 0;
	m._e32 = 0;
	m._e33 = 0;
	m._e34 = 0;
	m._e41 = 0;
	m._e42 = 0;
	m._e43 = 0;
	m._e44 = 0;

	return m;
}

// Get a [I] matrix
//
// RETURN: A 4x4 Identity matrix
TMATRIX Matrix_Identity(void)
{
	TMATRIX m = { 1, 0, 0, 0,
				  0, 1, 0, 0,
				  0, 0, 1, 0,
				  0, 0, 0, 1};
	return m;
}

// Get a translation matrix
//
// IN:		x		Amount of translation in the x direction
//			y		Amount of translation in the y direction
//			z		Amount of translation in the z direction
//
// RETURN:	The translation matrix
TMATRIX Matrix_Create_Translation(float x, float y, float z)
{
	TMATRIX m = { 1, 0, 0, x,
				  0, 1, 0, y,
		          0, 0, 1, z,
		          0, 0, 0, 1 };
	return m;
}

// Create a scale matrix
//
// IN:		x		Amount to scale in the x direction
//			y		Amount to scale in the y direction
//			z		Amount to scale in the z direction
//
// RETURN:	The scale matrix
TMATRIX Matrix_Create_Scale(float x, float y, float z)
{
	TMATRIX m = { x, 0, 0, 0,
		          0, y, 0, 0,
		          0, 0, z, 0,
		          0, 0, 0, 1 };
	return m;
}

// Get a rotation matrix for rotation about the x-axis
//
// IN:		Deg		Angle to rotate ( Degree measure)
//
// RETURN:	A X-Rotation Matrix
TMATRIX Matrix_Create_Rotation_X(float Deg)
{
	// TODO LAB 2: Replace with your implementation.
	TMATRIX m = { 1, 0, 0, 0,
		          0, cosf(Degrees_To_Radians( Deg)), -sinf(Degrees_To_Radians(Deg)), 0,
		          0, sinf(Degrees_To_Radians(Deg)), cosf(Degrees_To_Radians(Deg)), 0,
		          0, 0, 0, 1 };
	return m;
}

// Get a rotation matrix for rotation about the y-axis
//
// IN:		Deg		Angle to rotate ( Degree measure)
//
// RETURN:	A Y-Rotation Matrix
TMATRIX Matrix_Create_Rotation_Y(float Deg)
{
	// TODO LAB 2: Replace with your implementation.
	TMATRIX m = { cosf(Degrees_To_Radians(Deg)), 0, sinf(Degrees_To_Radians(Deg)), 0,
		          0, 1, 0, 0,
		          -sinf(Degrees_To_Radians(Deg)), 0, cosf(Degrees_To_Radians(Deg)), 0,
		          0, 0, 0, 1 };
	return m;
}

// Get a rotation matrix for rotation about the z-axis
//
// IN:		Deg		Angle to rotate ( Degree measure)
//
// RETURN:	A Z-Rotation Matrix
TMATRIX Matrix_Create_Rotation_Z(float Deg)
{
	// TODO LAB 2: Replace with your implementation.
	TMATRIX m = { cosf(Degrees_To_Radians(Deg)),-sinf(Degrees_To_Radians(Deg)), 0, 0,
		          sinf(Degrees_To_Radians(Deg)), cosf(Degrees_To_Radians(Deg)), 0, 0,
		          0, 0, 1, 0,
		          0, 0, 0, 1 };
	return m;
}

// ADD two matrices together
//
// IN:		m		The first matrix
//			n		The second matrix
//
// RETURN: m + n
TMATRIX Matrix_Matrix_Add(TMATRIX m, TMATRIX n)
{
	m._e11 = m._e11 + n._e11;
	m._e12 = m._e12 + n._e12;
	m._e13 = m._e13 + n._e13;
	m._e14 = m._e14 + n._e14;
	m._e21 = m._e21 + n._e21;
	m._e22 = m._e22 + n._e22;
	m._e23 = m._e23 + n._e23;
	m._e24 = m._e24 + n._e24;
	m._e31 = m._e31 + n._e31;
	m._e32 = m._e32 + n._e32;
	m._e33 = m._e33 + n._e33;
	m._e34 = m._e34 + n._e34;
	m._e41 = m._e41 + n._e41;
	m._e42 = m._e42 + n._e42;
	m._e43 = m._e43 + n._e43;
	m._e44 = m._e44 + n._e44;

	return m;
}

// SUBTRACT two matrices
//
// IN:		m		The first matrix (left hand side)
//			n		The second matrix (right hand side)
//
// RETURN: m - n
TMATRIX Matrix_Matrix_Sub(TMATRIX m, TMATRIX n)
{
	m._e11 = m._e11 - n._e11;
	m._e12 = m._e12 - n._e12;
	m._e13 = m._e13 - n._e13;
	m._e14 = m._e14 - n._e14;
	m._e21 = m._e21 - n._e21;
	m._e22 = m._e22 - n._e22;
	m._e23 = m._e23 - n._e23;
	m._e24 = m._e24 - n._e24;
	m._e31 = m._e31 - n._e31;
	m._e32 = m._e32 - n._e32;
	m._e33 = m._e33 - n._e33;
	m._e34 = m._e34 - n._e34;
	m._e41 = m._e41 - n._e41;
	m._e42 = m._e42 - n._e42;
	m._e43 = m._e43 - n._e43;
	m._e44 = m._e44 - n._e44;

	return m;
}

// Multiply a matrix by a scalar
//
// IN:		m		The matrix to be scaled (right hand side)
//			s		The value to scale by   (left hand side)
//
// RETURN:	The matrix formed by s*[m]
TMATRIX Matrix_Scalar_Multiply(TMATRIX m, float s)
{
	m._e11 = m._e11 * s;
	m._e12 = m._e12 * s;
	m._e13 = m._e13 * s;
	m._e14 = m._e14 * s;
	m._e21 = m._e21 * s;
	m._e22 = m._e22 * s;
	m._e23 = m._e23 * s;
	m._e24 = m._e24 * s;
	m._e31 = m._e31 * s;
	m._e32 = m._e32 * s;
	m._e33 = m._e33 * s;
	m._e34 = m._e34 * s;
	m._e41 = m._e41 * s;
	m._e42 = m._e42 * s;
	m._e43 = m._e43 * s;
	m._e44 = m._e44 * s;

	return m;
}

// Negate a matrix
//
// IN:		m		The matrix to negate
//
// RETURN:  The negation of m
TMATRIX Matrix_Negate(TMATRIX m)
{
	m._e11 = m._e11 * - 1;
	m._e12 = m._e12 * - 1;
	m._e13 = m._e13 * - 1;
	m._e14 = m._e14 * - 1;
	m._e21 = m._e21 * - 1;
	m._e22 = m._e22 * - 1;
	m._e23 = m._e23 * - 1;
	m._e24 = m._e24 * - 1;
	m._e31 = m._e31 * - 1;
	m._e32 = m._e32 * - 1;
	m._e33 = m._e33 * - 1;
	m._e34 = m._e34 * - 1;
	m._e41 = m._e41 * - 1;
	m._e42 = m._e42 * - 1;
	m._e43 = m._e43 * - 1;
	m._e44 = m._e44 * - 1;

	return m;
}

// Transpose a matrix
//
// IN:		m		The matrix to transpose
//
// RETURN:	The transpose of m
TMATRIX Matrix_Transpose(TMATRIX m)
{
	TMATRIX mTemp;
	mTemp._e11 = m._e11;
	mTemp._e21 = m._e12;
	mTemp._e31 = m._e13;
	mTemp._e41 = m._e14;
	mTemp._e12 = m._e21;
	mTemp._e22 = m._e22;
	mTemp._e32 = m._e23;
	mTemp._e42 = m._e24;
	mTemp._e13 = m._e31;
	mTemp._e23 = m._e32;
	mTemp._e33 = m._e33;
	mTemp._e43 = m._e34;
	mTemp._e14 = m._e41;
	mTemp._e24 = m._e42;
	mTemp._e34 = m._e43;
	mTemp._e44 = m._e44;
	// TODO LAB 2: Replace with your implementation.
	return mTemp;
}

// Multipy a matrix and a vector
//
// IN:		m		The matrix (left hand side)
//			v		The vector (right hand side)
//
// RETURN:	[m]*v
TVECTOR Matrix_Vector_Multiply(TMATRIX m, TVECTOR v)
{
	// TODO LAB 2: Replace with your implementation.
	TVECTOR mTemp;
	mTemp.x = ((v.x * m._e11) + (v.y * m._e12) + (v.z * m._e13) + (v.w * m._e14));
	mTemp.y = ((v.x * m._e21) + (v.y * m._e22) + (v.z * m._e23) + (v.w * m._e24));
	mTemp.z = ((v.x * m._e31) + (v.y * m._e32) + (v.z * m._e33) + (v.w * m._e34));
	mTemp.w = ((v.x * m._e41) + (v.y * m._e42) + (v.z * m._e43) + (v.w * m._e44));
	return mTemp;
}

// Multipy a vector and a matrix
//
// IN:		v		The vector ( left hand side)
//			m		The matrix (right hand side)
//
// RETURN:	v*[m]
TVECTOR Vector_Matrix_Multiply(TVECTOR v, TMATRIX m)
{
	TVECTOR mTemp;
	mTemp.x = ((v.x * m._e11) + (v.y * m._e21) + (v.z * m._e31) + (v.w * m._e41));
	mTemp.y = ((v.x * m._e12) + (v.y * m._e22) + (v.z * m._e32) + (v.w * m._e42));
	mTemp.z = ((v.x * m._e13) + (v.y * m._e23) + (v.z * m._e33) + (v.w * m._e43));
	mTemp.w = ((v.x * m._e14) + (v.y * m._e24) + (v.z * m._e34) + (v.w * m._e44));
	return mTemp;								  
}
// Multiply a matrix by a matrix
//
// IN:		m		First Matrix (left hand side)
//			n		Second Matrix (right hand side)
//
// RETURN:	[m]*[n]
TMATRIX Matrix_Matrix_Multiply(TMATRIX m, TMATRIX n)
{
	TMATRIX mTemp;
	mTemp._e11 = ((m._e11 * n._e11) + (m._e12 * n._e21) + (m._e13 * n._e31) + (m._e14 * n._e41));
	mTemp._e12 = ((m._e11 * n._e12) + (m._e12 * n._e22) + (m._e13 * n._e32) + (m._e14 * n._e42));
	mTemp._e13 = ((m._e11 * n._e13) + (m._e12 * n._e23) + (m._e13 * n._e33) + (m._e14 * n._e43));
	mTemp._e14 = ((m._e11 * n._e14) + (m._e12 * n._e24) + (m._e13 * n._e34) + (m._e14 * n._e44));
	mTemp._e21 = ((m._e21 * n._e11) + (m._e22 * n._e21) + (m._e23 * n._e31) + (m._e24 * n._e41));
	mTemp._e22 = ((m._e21 * n._e12) + (m._e22 * n._e22) + (m._e23 * n._e32) + (m._e24 * n._e42));
	mTemp._e23 = ((m._e21 * n._e13) + (m._e22 * n._e23) + (m._e23 * n._e33) + (m._e24 * n._e43));
	mTemp._e24 = ((m._e21 * n._e14) + (m._e22 * n._e24) + (m._e23 * n._e34) + (m._e24 * n._e44));
	mTemp._e31 = ((m._e31 * n._e11) + (m._e32 * n._e21) + (m._e33 * n._e31) + (m._e34 * n._e41));
	mTemp._e32 = ((m._e31 * n._e12) + (m._e32 * n._e22) + (m._e33 * n._e32) + (m._e34 * n._e42));
	mTemp._e33 = ((m._e31 * n._e13) + (m._e32 * n._e23) + (m._e33 * n._e33) + (m._e34 * n._e43));
	mTemp._e34 = ((m._e31 * n._e14) + (m._e32 * n._e24) + (m._e33 * n._e34) + (m._e34 * n._e44));
	mTemp._e41 = ((m._e41 * n._e11) + (m._e42 * n._e21) + (m._e43 * n._e31) + (m._e44 * n._e41));
	mTemp._e42 = ((m._e41 * n._e12) + (m._e42 * n._e22) + (m._e43 * n._e32) + (m._e44 * n._e42));
	mTemp._e43 = ((m._e41 * n._e13) + (m._e42 * n._e23) + (m._e43 * n._e33) + (m._e44 * n._e43));
	mTemp._e44 = ((m._e41 * n._e14) + (m._e42 * n._e24) + (m._e43 * n._e34) + (m._e44 * n._e44));

	return mTemp;
}

////////////////////////////////////////////////////////////////////////
// Matrix Functions Lab # 3
///////////////////////////////////////////////////////////////////////

// HELPER FUNCTION  *** NOT GRADED, ONLY SUGGESTED ***
// USE THIS FUNCTION TO FIND THE DETERMINANT OF A 3*3
// MATRIX. IT CAN BE USED IN THE MATRIX DETERMINANT
// AND MATRIX INVERSE FUNCTIONS BELOW
// 
// RETURN:	The determinant of a 3x3 matrix
float Matrix_Determinant(float e_11,float e_12,float e_13,
						 float e_21,float e_22,float e_23,
						 float e_31,float e_32,float e_33)
{
	float mTemp;
	mTemp = ((e_11 * ((e_22 * e_33) - (e_32 * e_23))) - (e_12 * ((e_21 * e_33) - (e_31 * e_23))) + (e_13 * ((e_21 * e_32) - (e_31 * e_22))));

	return mTemp;
}

// Get the determinant of a matrix
//
// IN:		m		The ONE!
//
// RETURN:	It's deterinant
float Matrix_Determinant(TMATRIX m)
{
	float mTemp;

	mTemp = (  (m._e11 * Matrix_Determinant(m._e22, m._e23, m._e24, m._e32, m._e33, m._e34, m._e42, m._e43, m._e44))
			 - (m._e12 * Matrix_Determinant(m._e21, m._e23, m._e24, m._e31, m._e33, m._e34, m._e41, m._e43, m._e44))
			 + (m._e13 * Matrix_Determinant(m._e21, m._e22, m._e24, m._e31, m._e32, m._e34, m._e41, m._e42, m._e44))
			 - (m._e14 * Matrix_Determinant(m._e21, m._e22, m._e23, m._e31, m._e32, m._e33, m._e41, m._e42, m._e43))
			);

	return mTemp;
}

// Get the inverse of a matrix
//
// IN:		m		The matrix to inverse
//
// RETURN:	The Inverse of [m]
//
// NOTE: Returns the matrix itself if m is not invertable.
TMATRIX Matrix_Inverse(TMATRIX m)
{
	float mDet = Matrix_Determinant(m);

	float c11 =  Matrix_Determinant(m._e22, m._e23, m._e24, m._e32, m._e33, m._e34, m._e42, m._e43, m._e44);
	float c12 = -Matrix_Determinant(m._e21, m._e23, m._e24, m._e31, m._e33, m._e34, m._e41, m._e43, m._e44);
	float c13 =  Matrix_Determinant(m._e21, m._e22, m._e24, m._e31, m._e32, m._e34, m._e41, m._e42, m._e44);
	float c14 = -Matrix_Determinant(m._e21, m._e22, m._e23, m._e31, m._e32, m._e33, m._e41, m._e42, m._e43);
	float c21 = -Matrix_Determinant(m._e12, m._e13, m._e14, m._e32, m._e33, m._e34, m._e42, m._e43, m._e44);
	float c22 =  Matrix_Determinant(m._e11, m._e13, m._e14, m._e31, m._e33, m._e34, m._e41, m._e43, m._e44);
	float c23 = -Matrix_Determinant(m._e11, m._e12, m._e14, m._e31, m._e32, m._e34, m._e41, m._e42, m._e44);
	float c24 =  Matrix_Determinant(m._e11, m._e12, m._e13, m._e31, m._e32, m._e33, m._e41, m._e42, m._e43);
	float c31 =  Matrix_Determinant(m._e12, m._e13, m._e14, m._e22, m._e23, m._e24, m._e42, m._e43, m._e44);
	float c32 = -Matrix_Determinant(m._e11, m._e13, m._e14, m._e21, m._e23, m._e24, m._e41, m._e43, m._e44);
	float c33 =  Matrix_Determinant(m._e11, m._e12, m._e14, m._e21, m._e22, m._e24, m._e41, m._e42, m._e44);
	float c34 = -Matrix_Determinant(m._e11, m._e12, m._e13, m._e21, m._e22, m._e23, m._e41, m._e42, m._e43);
	float c41 = -Matrix_Determinant(m._e12, m._e13, m._e14, m._e22, m._e23, m._e24, m._e32, m._e33, m._e34);
	float c42 =  Matrix_Determinant(m._e11, m._e13, m._e14, m._e21, m._e23, m._e24, m._e31, m._e33, m._e34);
	float c43 = -Matrix_Determinant(m._e11, m._e12, m._e14, m._e21, m._e22, m._e24, m._e31, m._e32, m._e34);
	float c44 =  Matrix_Determinant(m._e11, m._e12, m._e13, m._e21, m._e22, m._e23, m._e31, m._e32, m._e33);

	TMATRIX mAdj;
	mAdj._e11 = c11;
	mAdj._e12 = c12;
	mAdj._e13 = c13;
	mAdj._e14 = c14;
	mAdj._e21 = c21;
	mAdj._e22 = c22;
	mAdj._e23 = c23;
	mAdj._e24 = c24;
	mAdj._e31 = c31;
	mAdj._e32 = c32;
	mAdj._e33 = c33;
	mAdj._e34 = c34;
	mAdj._e41 = c41;
	mAdj._e42 = c42;
	mAdj._e43 = c43;
	mAdj._e44 = c44;

	TMATRIX mInverse = Matrix_Transpose(mAdj);
	mInverse._e11 = mInverse._e11 / mDet;
	mInverse._e12 = mInverse._e12 / mDet;
	mInverse._e13 = mInverse._e13 / mDet;
	mInverse._e14 = mInverse._e14 / mDet;
	mInverse._e21 = mInverse._e21 / mDet;
	mInverse._e22 = mInverse._e22 / mDet;
	mInverse._e23 = mInverse._e23 / mDet;
	mInverse._e24 = mInverse._e24 / mDet;
	mInverse._e31 = mInverse._e31 / mDet;
	mInverse._e32 = mInverse._e32 / mDet;
	mInverse._e33 = mInverse._e33 / mDet;
	mInverse._e34 = mInverse._e34 / mDet;
	mInverse._e41 = mInverse._e41 / mDet;
	mInverse._e42 = mInverse._e42 / mDet;
	mInverse._e43 = mInverse._e43 / mDet;
	mInverse._e44 = mInverse._e44 / mDet;

	if (mDet == 0)
	{
		return m;
	}
	// TODO LAB 3: Replace with your implementation.
	return mInverse;
}

