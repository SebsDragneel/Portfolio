#ifndef _INTERPOLATOR_H_
#define _INTERPOLATOR_H_
#include <Windows.h>
#include <vector>
#include <math.h>
#include <algorithm>

#include "Animation/Animation.h"
#include "Math/matrix4.h"

#undef min
#undef max

template < typename T >
class Interpolator
{
public:

	Interpolator();
	virtual ~Interpolator();

	void SetAnimation(const Animation< T >* animation);
	const Animation< T >* GetAnimation() const;

	void AddTime(float time);
	void SetTime(float time);
	float GetTime() const;

	virtual void Process();

	const std::vector< T >& GetPose() const;

protected:

	void ProcessKeyframes(const std::vector< typename Animation< T >::KeyFrame >& key_frames);

	const Animation< T >* animation;
	float current_time;

	std::vector< T > pose;
};

template < typename T >
Interpolator< T >::Interpolator()
{
	animation = 0;
	current_time = 0.0f;
}

template < typename T >
Interpolator< T >::~Interpolator()
{
}

template < typename T >
void Interpolator< T >::SetAnimation(const Animation< T >* animation)
{
	// TODO
	this->animation = animation;
	current_time = 0;
}

template < typename T >
const Animation< T >* Interpolator< T >::GetAnimation() const
{
	return animation;
}

template < typename T >
void Interpolator< T >::AddTime(float time)
{
	SetTime(current_time + time);
}

template < typename T >
void Interpolator< T >::SetTime(float time)
{
	// TODO
	if (animation)
	{
		if (time > animation->GetDuration())
		{
			current_time = 0;
		}
		else if (time < 0)
		{
			current_time = animation->GetDuration();
		}
		else
		{
			current_time = time;
		}
	}
	else
		current_time = 0;
}

template < typename T >
float Interpolator< T >::GetTime() const
{
	return current_time;
}

template < typename T >
void Interpolator< T >::Process()
{
	if (animation == 0)
	{
		pose.clear();
		return;
	}

	ProcessKeyframes(animation->GetKeyFrames());
}

template < typename T >
const std::vector<T>& Interpolator< T >::GetPose() const
{
	return pose;
}

template < typename T >
void Interpolator< T >::ProcessKeyframes(const std::vector< typename Animation< T >::KeyFrame >& key_frames)
{
	// TODO: Fill out the "pose" vector.  You are responsible for sizing it appropriately.
	//  "key_frames" contains an array of poses.
	//  "current_time" contains our current time.
	float prev = -1.0f;
	float next = -1.0f;
	int Indexprev = 0;
	int Indexnext = 0;
	for (unsigned int i = 0; i < key_frames.size(); i++)
	{
		if (current_time < key_frames[i].time)
		{
			if (next == -1.0f || next > key_frames[i].time)
			{
				next = key_frames[i].time;
				Indexnext = i;
			}

		}
		else if (current_time >= key_frames[i].time)
		{
			if (prev == -1.0f || prev <= key_frames[i].time)
			{
				prev = key_frames[i].time;
				Indexprev = i;
			}
		}
	}

	float mTemp = 0.0f;
	if (prev == -1.0f)
	{
		for (unsigned int i = 0; i < key_frames.size(); i++)
		{
			if (mTemp < key_frames[i].time)
			{
				mTemp = key_frames[i].time;

				Indexprev = i;
			}
		}
		prev = 0.0f;
	}

	float mTemp2 = 0.0f;
	if (next == -1.0f)
	{
		for (unsigned int i = 0; i < key_frames.size(); i++)
		{
			if (mTemp2 > key_frames[i].time)
			{
				mTemp2 = key_frames[i].time;

				Indexnext = i;
			}
		}
		next = 0.0f;
	}

		float mRatio = (current_time - prev) / (next - prev);
		int mTotal = key_frames[Indexprev].nodes.size();
		pose.resize(mTotal);
		for (unsigned int i = 0; i < mTotal; i++)
		{
			vec3f PrevPoints = key_frames[Indexprev].nodes[i];
			vec3f NextPoints = key_frames[Indexnext].nodes[i];
			float x = PrevPoints.x +((NextPoints.x - PrevPoints.x) * mRatio);
			float y = PrevPoints.y + ((NextPoints.y - PrevPoints.y) * mRatio);
			float z = PrevPoints.z + ((NextPoints.z - PrevPoints.z) * mRatio);
			vec3f Interpol;
			Interpol.x = x;
			Interpol.y = y;
			Interpol.z = z;
			pose.push_back(Interpol);
		}

}

#endif // _INTERPOLATOR_H_