#include "VertLoader.h"

#include <fstream>
#include <iostream>
#include "Animation/Animation.h"
#include "Math/vec3.h"

bool VertLoader::Load( const std::string& file_name, Animation< vec3f >& animation )
{
    // TODO
	std::ifstream mFin;

	mFin.open(file_name, std::ios_base::in | std::ios_base::binary);

	if (mFin.is_open())
	{
		int NumOfKeyframes = 0;

		mFin.read((char*)&NumOfKeyframes, sizeof(NumOfKeyframes));

		for (int i = 0; i < NumOfKeyframes; i++)
		{
			float Time = 0;
			mFin.read((char*)&Time, sizeof(Time));

			int NodeCount = 0;
			mFin.read((char*)&NodeCount, sizeof(NodeCount));
			
			Animation<vec3f>::KeyFrame mKeyframe;
			mKeyframe.time = Time;
			mKeyframe.nodes.resize(NodeCount);
			

			for (int i = 0; i < NodeCount; i++)
			{
				vec3f B;
				mFin.read((char*)&B, 12);
				mKeyframe.nodes.push_back(B);	
			}

			animation.GetKeyFrames().push_back(mKeyframe);

		}
		mFin.close();
	}
	
    return true;
}