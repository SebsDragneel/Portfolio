#ifndef _APPCONFIG_H_
#define _APPCONFIG_H_

// Use this setting to build the example executable
// This changes the relative path to the assets directory
//#define BUILD_EXAMPLE

#endif // _APPCONFIG_H_