#include "Rasterization_Functions.h"

void main(void)
{
	float degrees = 0.0f;
	float checktime = 0.0f;
	XTime time;
	

	RS_Initialize(RASTER_WIDTH, RASTER_HEIGHT);


	Vertex GridWest[11];
	Vertex GridNorth[11];
	Vertex GridEast[11];
	Vertex GridSouth[11];


	float StartX = -0.5f;
	float endX = -0.5f;
	float StartZ = -0.5f;
	float endZ = -0.5f;


	for (int i = 0; i < 11; i++)
	{
		GridWest[i].x = -0.5f;
		GridWest[i].y = 0.0f;
		GridWest[i].z = StartZ;
		GridWest[i].w = 1;
		StartZ += 0.1f;
	}
	for (int i = 0; i < 11; i++)
	{
		GridNorth[i].x = StartX;
		GridNorth[i].y = 0.0f;
		GridNorth[i].z = 0.5f;
		GridNorth[i].w = 1;
		StartX += 0.1f;
	}
	for (int i = 0; i < 11; i++)
	{
		GridEast[i].x = 0.5;
		GridEast[i].y = 0.0f;
		GridEast[i].z = endZ;
		GridEast[i].w = 1;
		endZ += 0.1f;
	}
	for (int i = 0; i < 11; i++)
	{
		GridSouth[i].x = endX;
		GridSouth[i].y = 0.0f;
		GridSouth[i].z = -0.5f;
		GridSouth[i].w = 1;
		endX += 0.1f;
	}
	


	Vertex Cube[24];

	for (int i = 0; i < 24; i++)
		Cube[i].w = 1;
	//down face
		Cube[0].x = -0.25f;
		Cube[0].y = 0.0f;
		Cube[0].z = 0.25f;
		Cube[0].Color = 0x0000FF00;
		Cube[0].U = 1.0f;
		Cube[0].V = 0.0f;

		Cube[1].x = 0.25f;
		Cube[1].y = 0.0f;
		Cube[1].z = 0.25f;
		Cube[1].Color = 0x000000FF;
		Cube[1].U = 0.0f;
		Cube[1].V = 0.0f;


		
		Cube[2].x = 0.25f;
		Cube[2].y = 0.0f;
		Cube[2].z = -0.25f;
		Cube[2].Color = 0x00FF0000;
		Cube[2].U = 0.0f;
		Cube[2].V = 1.0f;

		Cube[3].x = -0.25f;
		Cube[3].y = 0.0f;
		Cube[3].z = -0.25f;
		Cube[3].Color = 0x000000FF;
		Cube[3].U = 1.0f;
		Cube[3].V = 1.0f;

		//upper face
		Cube[4].x = -0.25f;
		Cube[4].y = 0.5f;
		Cube[4].z = 0.25f;
		Cube[4].Color = 0x0000FF00;
		Cube[4].U = 0.0f;
		Cube[4].V = 0.0f;

		Cube[5].x = 0.25f;
		Cube[5].y = 0.5f;
		Cube[5].z = 0.25f;
		Cube[5].Color = 0x00FF0000;
		Cube[5].U = 1.0f;
		Cube[5].V = 0.0f;


		Cube[6].x = 0.25f;
		Cube[6].y = 0.5f;
		Cube[6].z = -0.25f;
		Cube[6].Color = 0x000000FF;
		Cube[6].U = 1.0f;
		Cube[6].V = 1.0f;


		Cube[7].x = -0.25f;
		Cube[7].y = 0.5f;
		Cube[7].z = -0.25f;
		Cube[7].Color = 0x000000FF;
		Cube[7].U = 0.0f;
		Cube[7].V = 1.0f;


		//front face
		Cube[8].x = -0.25f;
		Cube[8].y = 0.5f;
		Cube[8].z = -0.25f;
		Cube[8].Color = 0x000000FF;
		Cube[8].U = 0.0f;
		Cube[8].V = 0.0f;

		Cube[9].x = 0.25f;
		Cube[9].y = 0.5f;
		Cube[9].z = -0.25f;
		Cube[9].Color = 0x000000FF;
		Cube[9].U = 1.0f;
		Cube[9].V = 0.0f;

		Cube[10].x = -0.25f;
		Cube[10].y = 0.0f;
		Cube[10].z = -0.25f;
		Cube[10].Color = 0x000000FF;
		Cube[10].U = 0.0f;
		Cube[10].V = 1.0f;

		Cube[11].x = 0.25f;
		Cube[11].y = 0.0f;
		Cube[11].z = -0.25f;
		Cube[11].Color = 0x00FF0000;
		Cube[11].U = 1.0f;
		Cube[11].V = 1.0f;

		//back face
		Cube[12].x = 0.25f;
		Cube[12].y = 0.5f;
		Cube[12].z = 0.25f;
		Cube[12].Color = 0x00FF0000;
		Cube[12].U = 0.0f;
		Cube[12].V = 0.0f;

		Cube[13].x = -0.25f;
		Cube[13].y = 0.5f;
		Cube[13].z = 0.25f;
		Cube[13].Color = 0x0000FF00;
		Cube[13].U = 1.0f;
		Cube[13].V = 0.0f;


		Cube[14].x = 0.25f;
		Cube[14].y = 0.0f;
		Cube[14].z = 0.25f;
		Cube[14].Color = 0x000000FF;
		Cube[14].U = 0.0f;
		Cube[14].V = 1.0f;


		Cube[15].x = -0.25f;
		Cube[15].y = 0.0f;
		Cube[15].z = 0.25f;
		Cube[15].Color = 0x0000FF00;
		Cube[15].U = 1.0f;
		Cube[15].V = 1.0f;


		//left face
		Cube[16].x = -0.25f;
		Cube[16].y = 0.5f;
		Cube[16].z = 0.25f;
		Cube[16].Color = 0x0000FF00;
		Cube[16].U = 0.0f;
		Cube[16].V = 0.0f;

		Cube[17].x = -0.25f;
		Cube[17].y = 0.5f;
		Cube[17].z = -0.25f;
		Cube[17].Color = 0x000000FF;
		Cube[17].U = 1.0f;
		Cube[17].V = 0.0f;

		Cube[18].x = -0.25f;
		Cube[18].y = 0.0f;
		Cube[18].z = 0.25f;
		Cube[18].Color = 0x0000FF00;
		Cube[18].U = 0.0f;
		Cube[18].V = 1.0f;

		Cube[19].x = -0.25f;
		Cube[19].y = 0.0f;
		Cube[19].z = -0.25f;
		Cube[19].Color = 0x000000FF;
		Cube[19].U = 1.0f;
		Cube[19].V = 1.0f;

		//right face
		Cube[20].x = 0.25f;
		Cube[20].y = 0.5f;
		Cube[20].z = -0.25f;
		Cube[20].Color = 0x000000FF;
		Cube[20].U = 0.0f;
		Cube[20].V = 0.0f;

		Cube[21].x = 0.25f;
		Cube[21].y = 0.5f;
		Cube[21].z = 0.25f;
		Cube[21].Color = 0x00FF0000;
		Cube[21].U = 1.0f;
		Cube[21].V = 0.0f;

		Cube[22].x = 0.25f;
		Cube[22].y = 0.0f;
		Cube[22].z = -0.25f;
		Cube[22].Color = 0x00FF0000;
		Cube[22].U = 0.0f;
		Cube[22].V = 1.0f;

		Cube[23].x = 0.25f;
		Cube[23].y = 0.0f;
		Cube[23].z = 0.25f;
		Cube[23].Color = 0x000000FF;
		Cube[23].U = 1.0f;
		Cube[23].V = 1.0f;



			
		SV_GridMatrix = Matrix_Identity();



		SV_viewMatrix = Matrix_Matrix_Multiply(Matrix_Create_Translation(0,0,-1), MatrixCreateRotationX(-18));
			
		SV_viewMatrix = Matrix_Inverse(SV_viewMatrix);
		

		SV_ProjectionMatrix = PerspectiveProjection( 0.1f, 10.0f );


	do
	{
		ClearBuffer();
		time.Signal();

		checktime = checktime + abs(time.SmoothDelta());

		if (checktime >= (1 / 60))
		{
			degrees += 0.1f;
			checktime = 0;

		}
		
			if (degrees >= 360)
				degrees = 0;

			VertexShader = VS_Grid;  
			PixelShader = PS_White; 
							
			for (int i = 0; i < 11; i++)
			{
				DrawLine(GridWest[i], GridEast[i]);
				DrawLine(GridNorth[i], GridSouth[i]);
			}


			VertexShader = VS_Cube;
			PixelShader = PS_Green;
			SV_CubeMatrix = MatrixCreateRotationY(degrees);

			DrawLine(Cube[0], Cube[1]);
			DrawLine(Cube[1], Cube[2]);
			DrawLine(Cube[2], Cube[3]);
			DrawLine(Cube[3], Cube[0]);

			

					
			DrawLine(Cube[4], Cube[5]);
			DrawLine(Cube[5], Cube[6]);
			DrawLine(Cube[6], Cube[7]);
			DrawLine(Cube[7], Cube[4]);


					
			DrawLine(Cube[0], Cube[4]);
			DrawLine(Cube[1], Cube[5]);
			DrawLine(Cube[2], Cube[6]);
			DrawLine(Cube[3], Cube[7]);

			//triangle cross lines
			/*DrawLine(Cube[0], Cube[2]);
			DrawLine(Cube[4], Cube[6]);
			DrawLine(Cube[7], Cube[2]);
			DrawLine(Cube[5], Cube[0]);
			DrawLine(Cube[6], Cube[1]);
			DrawLine(Cube[4], Cube[3]);*/

			//down
			PixelShader = PS_Yellow;


			BruteForce(Cube[0], Cube[1], Cube[2]);
			BruteForce(Cube[0], Cube[3], Cube[2]);
			//upper
			PixelShader = PS_Magenta;
			BruteForce(Cube[4], Cube[5], Cube[6]);
			BruteForce(Cube[4], Cube[7], Cube[6]);

			//front
			/*PixelShader = PS_Green;*/
			BruteForce(Cube[8], Cube[9], Cube[11]);
			BruteForce(Cube[8], Cube[10], Cube[11]);
			//back
			PixelShader = PS_Cyan;
			BruteForce(Cube[12], Cube[13], Cube[15]);
			BruteForce(Cube[12], Cube[14], Cube[15]);
			//left
			PixelShader = PS_Blue;
			BruteForce(Cube[16], Cube[17], Cube[19]);
			BruteForce(Cube[16], Cube[18], Cube[19]);
			//right
			PixelShader = PS_Red;
			BruteForce(Cube[20], Cube[21], Cube[23]);
			BruteForce(Cube[20], Cube[22], Cube[23]);

			

	} while (RS_Update(Raster, NUM_PIXELS));

RS_Shutdown();
}
