// CGS HW Project A "Line Land".
// Author: L.Norri CD CGS, FullSail University

// Introduction:
// Welcome to the hardware project of the Computer Graphics Systems class.
// This assignment is fully guided but still requires significant effort on your part. 
// Future classes will demand the habits & foundation you develop right now!  
// It is CRITICAL that you follow each and every step. ESPECIALLY THE READING!!!

// TO BEGIN: Open the word document that acompanies this project and start from the top.

//************************************************************
//************ INCLUDES & DEFINES ****************************
//************************************************************

#include <iostream>
#include <ctime>
#include "XTime.h"



using namespace std;


// BEGIN PART 1
// TODO: PART 1 STEP 1a
#pragma comment (lib, "d3d11.lib")
#include <d3d11.h>
// TODO: PART 1 STEP 1b
#include <DirectXMath.h>
#include <DirectXPackedVector.h>
#include <DirectXColors.h>
#include <DirectXCollision.h>
using namespace DirectX;
// TODO: PART 2 STEP 6
#include "Trivial_VS.csh"
#include "Trivial_PS.csh"

#define BACKBUFFER_WIDTH	500
#define BACKBUFFER_HEIGHT	500
#define radius 0.2
#define PI 3.14159

//************************************************************
//************ SIMPLE WINDOWS APP CLASS **********************
//************************************************************

class DEMO_APP
{	
	HINSTANCE						application;
	WNDPROC							appWndProc;
	HWND							window;
	// TODO: PART 1 STEP 2
	ID3D11Device *device = 0;
	ID3D11DeviceContext *deviceContext = 0;
	ID3D11RenderTargetView *RTV = 0;
	IDXGISwapChain *swapChain = 0;
	ID3D11View *view = 0;
	ID3D11Debug *debugger = 0;
	ID3D11Texture2D *swapChainBuffer = 0;
	D3D11_VIEWPORT viewport;
	// TODO: PART 2 STEP 2
	ID3D11InputLayout* inputLayout;
	ID3D11Buffer *circleBuffer;
	#define numCircleVertices 365
	// BEGIN PART 5
	// TODO: PART 5 STEP 1
	ID3D11Buffer *gridBuffer;
	ID3D11Buffer *constantGridViewBuffer;
	ID3D11InputLayout* inputLayoutgrid;


	#define numGridVertices 1201
	// TODO: PART 2 STEP 4
	ID3D11VertexShader *vertexShader;
	ID3D11PixelShader *pixelShader;
	// BEGIN PART 3
	// TODO: PART 3 STEP 1
	ID3D11Buffer *constantViewBuffer;
	XTime timer;
	int XDir = 1;
	int YDir = 1;
	// TODO: PART 3 STEP 2b
	struct SEND_TO_VRAM
	{
		XMVECTORF32 constantColor;
		XMFLOAT2 constantOffset;
		XMFLOAT2 padding;
	};
	// TODO: PART 3 STEP 4a
	SEND_TO_VRAM toShader;
	SEND_TO_VRAM toShaderGridC;


public:
	// BEGIN PART 2
	// TODO: PART 2 STEP 1
	struct SIMPLE_VERTEX
	{
		XMFLOAT2 position2D;
	};
	bool PositiveX = true;
	bool PositiveY = true;
	DEMO_APP(HINSTANCE hinst, WNDPROC proc);
	bool Run();
	bool ShutDown();
};

//************************************************************
//************ CREATION OF OBJECTS & RESOURCES ***************
//************************************************************

DEMO_APP::DEMO_APP(HINSTANCE hinst, WNDPROC proc)
{
	// ****************** BEGIN WARNING ***********************// 
	// WINDOWS CODE, I DON'T TEACH THIS YOU MUST KNOW IT ALREADY! 
	application = hinst; 
	appWndProc = proc; 

	WNDCLASSEX  wndClass;
    ZeroMemory( &wndClass, sizeof( wndClass ) );
    wndClass.cbSize         = sizeof( WNDCLASSEX );             
    wndClass.lpfnWndProc    = appWndProc;						
    wndClass.lpszClassName  = L"DirectXApplication";            
	wndClass.hInstance      = application;		               
    wndClass.hCursor        = LoadCursor( NULL, IDC_ARROW );    
    wndClass.hbrBackground  = ( HBRUSH )( COLOR_WINDOWFRAME ); 
	//wndClass.hIcon			= LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_FSICON));
    RegisterClassEx( &wndClass );

	RECT window_size = { 0, 0, BACKBUFFER_WIDTH, BACKBUFFER_HEIGHT };
	AdjustWindowRect(&window_size, WS_OVERLAPPEDWINDOW, false);

	window = CreateWindow(	L"DirectXApplication", L"CGS Hardware Project",	WS_OVERLAPPEDWINDOW & ~(WS_THICKFRAME|WS_MAXIMIZEBOX), 
							CW_USEDEFAULT, CW_USEDEFAULT, window_size.right-window_size.left, window_size.bottom-window_size.top,					
							NULL, NULL,	application, this );												

    ShowWindow( window, SW_SHOW );
	//********************* END WARNING ************************//

	// TODO: PART 1 STEP 3a
	DXGI_SWAP_CHAIN_DESC swapChainDesc;

	ZeroMemory(&swapChainDesc, sizeof(DXGI_SWAP_CHAIN_DESC));

	swapChainDesc.BufferCount = 1;
	swapChainDesc.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
	swapChainDesc.BufferDesc.Height = BACKBUFFER_HEIGHT;
	swapChainDesc.BufferDesc.Width = BACKBUFFER_WIDTH;
	swapChainDesc.BufferDesc.RefreshRate.Denominator = 1;
	swapChainDesc.BufferDesc.RefreshRate.Numerator = 60;
	swapChainDesc.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
	swapChainDesc.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;
	swapChainDesc.OutputWindow = window;
	swapChainDesc.SampleDesc.Count = 1;
	swapChainDesc.SampleDesc.Quality = 0;
	swapChainDesc.Windowed = true;
	// TODO: PART 1 STEP 3b

	UINT flags = NULL;

#ifdef _DEBUG
		flags = D3D11_CREATE_DEVICE_DEBUG;
#endif

	HRESULT hr = D3D11CreateDeviceAndSwapChain(NULL, D3D_DRIVER_TYPE_HARDWARE, NULL, flags, NULL, NULL, D3D11_SDK_VERSION, &swapChainDesc, &swapChain, &device, NULL, &deviceContext);
	
	// TODO: PART 1 STEP 4
	hr = swapChain->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)&swapChainBuffer);
	// TODO: PART 1 STEP 5
	hr = device->CreateRenderTargetView(swapChainBuffer, NULL, &RTV);
	hr = device->QueryInterface(__uuidof(ID3D11Debug), (void**)&debugger);

	ZeroMemory(&viewport, sizeof(D3D11_VIEWPORT));

	viewport.TopLeftX = 0;
	viewport.TopLeftY = 0;
	viewport.Width = swapChainDesc.BufferDesc.Width;
	viewport.Height = swapChainDesc.BufferDesc.Height;
	viewport.MinDepth = 0;
	viewport.MaxDepth = 1;
	// TODO: PART 2 STEP 3a
	SIMPLE_VERTEX circle[numCircleVertices];

		for (unsigned int i = 0; i < numCircleVertices; ++i)
		{
			circle[i].position2D.x = radius * cos(i * PI / 180.0f);
			circle[i].position2D.y = radius * sin(i * PI / 180.0f);
		}

	// BEGIN PART 4
	// TODO: PART 4 STEP 1
		///I just changed the radius def I have from 1 to 0.2 which is the 80%
	// TODO: PART 2 STEP 3b
		D3D11_BUFFER_DESC circleBufferDesc;
		ZeroMemory(&circleBufferDesc, sizeof(D3D11_BUFFER_DESC));

		circleBufferDesc.Usage = D3D11_USAGE_IMMUTABLE;
		circleBufferDesc.ByteWidth = sizeof(SIMPLE_VERTEX)*numCircleVertices;
		circleBufferDesc.BindFlags = D3D11_BIND_VERTEX_BUFFER;
		circleBufferDesc.MiscFlags = 0;
		circleBufferDesc.StructureByteStride = 0;
    // TODO: PART 2 STEP 3c
		D3D11_SUBRESOURCE_DATA subResDatacircle;
		ZeroMemory(&subResDatacircle, sizeof(D3D11_SUBRESOURCE_DATA));
		subResDatacircle.pSysMem = circle;
		subResDatacircle.SysMemPitch = 0;
		subResDatacircle.SysMemSlicePitch = 0;
	// TODO: PART 2 STEP 3d
		device->CreateBuffer(&circleBufferDesc, &subResDatacircle, &circleBuffer);
	// TODO: PART 5 STEP 2a
		SIMPLE_VERTEX grid[numGridVertices];
		
	// TODO: PART 5 STEP 2b
		int i = 0;
		for (int y = 0; y < 20; y++)
		{
			int x;
			for ((y % 2 == 0) ? x = 1 : x = 0; x < 20; x += 2)
			{
				//upper triangle
				grid[i].position2D.x = (x * 0.1f) - 1.0f;
				grid[i].position2D.y = 1.0f - ((y + 1.0f) * 0.1f);
				i++;

				grid[i].position2D.x = (x * 0.1f) - 1.0f;
				grid[i].position2D.y = 1.0f - (y * 0.1f);
				i++;

				grid[i].position2D.x = ((x + 1.0f) * 0.1f) - 1.0;
				grid[i].position2D.y = 1.0f - (y * 0.1f);
				i++;

				//lower triangle
				grid[i].position2D.x = (x * 0.1f) - 1.0f;
				grid[i].position2D.y = 1.0f - ((y + 1.0f) * 0.1f);
				i++;

				grid[i].position2D.x = ((x + 1.0f) * 0.1f) - 1.0f;
				grid[i].position2D.y = 1.0f - (y * 0.1f);
				i++;

				grid[i].position2D.x = ((x + 1.0f) * 0.1f) - 1.0f;
				grid[i].position2D.y = 1.0f - ((y + 1.0f)* 0.1f);
				i++;
			}
		}
		/*grid[1200 - 1].position2D.x = 0.9f;
		grid[1200 - 1].position2D.y = -1.0f;
		grid[1200].position2D.x = 0.8f;
		grid[1200].position2D.y = -1.0f;
		grid[1200 - 2].position2D.x = 0.9f;
		grid[1200 - 2].position2D.y = -0.9f;*/

	// TODO: PART 5 STEP 3
		D3D11_BUFFER_DESC gridBufferDesc;
		ZeroMemory(&gridBufferDesc, sizeof(D3D11_BUFFER_DESC));
		gridBufferDesc.Usage = D3D11_USAGE_IMMUTABLE;
		gridBufferDesc.ByteWidth = sizeof(SIMPLE_VERTEX)*numGridVertices;
		gridBufferDesc.BindFlags = D3D11_BIND_VERTEX_BUFFER;
		gridBufferDesc.MiscFlags = 0;
		gridBufferDesc.StructureByteStride = 0;

		D3D11_SUBRESOURCE_DATA subResDataGrid;
		ZeroMemory(&subResDataGrid, sizeof(D3D11_SUBRESOURCE_DATA));
		subResDataGrid.pSysMem = grid;
		subResDataGrid.SysMemPitch = 0;
		subResDataGrid.SysMemSlicePitch = 0;

		device->CreateBuffer(&gridBufferDesc, &subResDataGrid, &gridBuffer);
	// TODO: PART 2 STEP 5
	/// ADD SHADERS TO PROJECT, SET BUILD OPTIONS & COMPILE
		
	// TODO: PART 2 STEP 7
		device->CreateVertexShader(Trivial_VS, sizeof(Trivial_VS), NULL, &vertexShader);
		device->CreatePixelShader(Trivial_PS, sizeof(Trivial_PS), NULL, &pixelShader);
	// TODO: PART 2 STEP 8a
		D3D11_INPUT_ELEMENT_DESC inputElementDesc[] =
		{
			{ "POSITION",0,DXGI_FORMAT_R32G32B32_FLOAT,0,D3D10_APPEND_ALIGNED_ELEMENT,D3D11_INPUT_PER_VERTEX_DATA,0 },
			{ "COLOR",0,DXGI_FORMAT_R32G32B32A32_FLOAT,0,D3D10_APPEND_ALIGNED_ELEMENT,D3D11_INPUT_PER_VERTEX_DATA,0 }
		};
	
	
	// TODO: PART 2 STEP 8b
		device->CreateInputLayout(inputElementDesc, 1, &Trivial_VS, sizeof(Trivial_VS), &inputLayout);
		device->CreateInputLayout(inputElementDesc, 1, &Trivial_VS, sizeof(Trivial_VS), &inputLayoutgrid);
	// TODO: PART 3 STEP 3
		D3D11_BUFFER_DESC constantBufferDesc;
		ZeroMemory(&constantBufferDesc, sizeof(D3D11_BUFFER_DESC));

		constantBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
		constantBufferDesc.ByteWidth = sizeof(SEND_TO_VRAM);
		constantBufferDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
		constantBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
		constantBufferDesc.MiscFlags = 0;
		constantBufferDesc.StructureByteStride = 0;

		device->CreateBuffer(&constantBufferDesc, NULL, &constantViewBuffer);
	
	// TODO: PART 3 STEP 4b
		toShader.constantOffset.x = 0;
		toShader.constantOffset.y = 0;
		toShader.constantColor = Colors::Yellow;

		
		D3D11_BUFFER_DESC constantGridBufferDesc;
		ZeroMemory(&constantGridBufferDesc, sizeof(D3D11_BUFFER_DESC));

		constantGridBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
		constantGridBufferDesc.ByteWidth = sizeof(SEND_TO_VRAM);
		constantGridBufferDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
		constantGridBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
		constantGridBufferDesc.MiscFlags = 0;
		constantGridBufferDesc.StructureByteStride = 0;

		device->CreateBuffer(&constantGridBufferDesc, NULL, &constantGridViewBuffer);

		toShaderGridC.constantOffset.x = 0;
		toShaderGridC.constantOffset.y = 0;
		toShaderGridC.constantColor = DirectX::Colors::Black;

}

//************************************************************
//************ EXECUTION *************************************
//************************************************************

bool DEMO_APP::Run()
{
	// TODO: PART 4 STEP 2	
	timer.Signal();
	///timer.TotalTime();
	// TODO: PART 4 STEP 3
	SIMPLE_VERTEX Velocity;
	Velocity.position2D.x = 1.0f;
	Velocity.position2D.y = 0.5f;
	
	if (PositiveX)
		toShader.constantOffset.x += Velocity.position2D.x * (float)abs(timer.SmoothDelta());
	else
		toShader.constantOffset.x -= Velocity.position2D.x * (float)abs(timer.SmoothDelta());
	if (PositiveY)
		toShader.constantOffset.y += Velocity.position2D.y * (float)abs(timer.SmoothDelta());
	else
		toShader.constantOffset.y -= Velocity.position2D.y * (float)abs(timer.SmoothDelta());
	// TODO: PART 4 STEP 5
	///LeftWall
	if (toShader.constantOffset.x < -1.0f)
		PositiveX = true;
	///RigthWall
	if (toShader.constantOffset.x > 1.0f)
		PositiveX = false;

	///TopWall
	if (toShader.constantOffset.y > 1.0f)
		PositiveY = false;
	///BottomWall
	if (toShader.constantOffset.y < -1.0f)
		PositiveY = true;
	// END PART 4

	// TODO: PART 1 STEP 7a
	deviceContext->OMSetRenderTargets(1, &RTV, 0);
	
	// TODO: PART 1 STEP 7b
	deviceContext->RSSetViewports(1, &viewport);
	// TODO: PART 1 STEP 7c
	deviceContext->ClearRenderTargetView(RTV, Colors::DarkBlue);

	// TODO: PART 5 STEP 4
	
	
	// TODO: PART 5 STEP 5
	D3D11_MAPPED_SUBRESOURCE mappedSubRes;
	ZeroMemory(&mappedSubRes, sizeof(mappedSubRes));
	deviceContext->Map(constantGridViewBuffer, NULL, D3D11_MAP_WRITE_DISCARD, NULL, &mappedSubRes);
	memcpy(mappedSubRes.pData, &toShaderGridC, sizeof(SEND_TO_VRAM));
	deviceContext->Unmap(constantGridViewBuffer, NULL);

	deviceContext->VSSetConstantBuffers(0, 1, &constantGridViewBuffer);
	// TODO: PART 5 STEP 6
	UINT stride = sizeof(SIMPLE_VERTEX);
	UINT offset = 0;
	deviceContext->IASetVertexBuffers(0, 1, &gridBuffer, &stride, &offset);

	deviceContext->VSSetShader(vertexShader, 0, 0);
	deviceContext->PSSetShader(pixelShader, 0, 0);

	deviceContext->IASetInputLayout(inputLayoutgrid);
	deviceContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

	
	// TODO: PART 5 STEP 7
	deviceContext->Draw(numGridVertices, 0);
	// END PART 5
	
	// TODO: PART 3 STEP 5
	ZeroMemory(&mappedSubRes, sizeof(mappedSubRes));
	deviceContext->Map(constantViewBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedSubRes);
	memcpy(mappedSubRes.pData, &toShader, sizeof(SEND_TO_VRAM));
	deviceContext->Unmap(constantViewBuffer, 0);
	// TODO: PART 3 STEP 6
	deviceContext->VSSetConstantBuffers(0, 1, &constantViewBuffer);
	// TODO: PART 2 STEP 9a
	stride = sizeof(SIMPLE_VERTEX);
	offset = 0;
	deviceContext->IASetVertexBuffers(0, 1, &circleBuffer, &stride, &offset);
	// TODO: PART 2 STEP 9b
	deviceContext->VSSetShader(vertexShader, 0, 0);
	deviceContext->PSSetShader(pixelShader, 0, 0);
	// TODO: PART 2 STEP 9c
	deviceContext->IASetInputLayout(inputLayout);

	// TODO: PART 2 STEP 9d
	deviceContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_LINESTRIP_ADJ);

	// TODO: PART 2 STEP 10
	deviceContext->Draw(numCircleVertices, 0);
	// END PART 2

	// TODO: PART 1 STEP 8
	swapChain->Present(0, 0);
	
	// END OF PART 1
	return true; 
}

//************************************************************
//************ DESTRUCTION ***********************************
//************************************************************

bool DEMO_APP::ShutDown()
{
	// TODO: PART 1 STEP 6
	deviceContext->ClearState();

	deviceContext->Release();
	swapChain->Release();
	device->Release();
	RTV->Release();
	debugger->Release();
	swapChainBuffer->Release();
	swapChainBuffer->Release();
	inputLayout->Release();
	circleBuffer->Release();
	constantViewBuffer->Release();
	vertexShader->Release();
	pixelShader->Release();
	inputLayoutgrid->Release();
	gridBuffer->Release();
	constantGridViewBuffer->Release();
	
	UnregisterClass( L"DirectXApplication", application ); 
	return true;
}

//************************************************************
//************ WINDOWS RELATED *******************************
//************************************************************

// ****************** BEGIN WARNING ***********************// 
// WINDOWS CODE, I DON'T TEACH THIS YOU MUST KNOW IT ALREADY!
	
int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR lpCmdLine,	int nCmdShow );						   
LRESULT CALLBACK WndProc(HWND hWnd,	UINT message, WPARAM wparam, LPARAM lparam );		
int WINAPI wWinMain( HINSTANCE hInstance, HINSTANCE, LPTSTR, int )
{
	srand(unsigned int(time(0)));
	DEMO_APP myApp(hInstance,(WNDPROC)WndProc);	
    MSG msg; ZeroMemory( &msg, sizeof( msg ) );
    while ( msg.message != WM_QUIT && myApp.Run() )
    {	
	    if ( PeekMessage( &msg, NULL, 0, 0, PM_REMOVE ) )
        { 
            TranslateMessage( &msg );
            DispatchMessage( &msg ); 
        }
    }
	myApp.ShutDown(); 
	return 0; 
}
LRESULT CALLBACK WndProc( HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam )
{
    if(GetAsyncKeyState(VK_ESCAPE))
		message = WM_DESTROY;
    switch ( message )
    {
        case ( WM_DESTROY ): { PostQuitMessage( 0 ); }
        break;
    }
    return DefWindowProc( hWnd, message, wParam, lParam );
}
//********************* END WARNING ************************//