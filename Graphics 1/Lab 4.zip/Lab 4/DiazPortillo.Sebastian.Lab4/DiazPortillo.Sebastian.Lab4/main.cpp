#include "Rasterization_Functions.h"

void main(void)
{
	float degrees = 0.0f;
	float checktime = 0.0f;
	XTime time;
	

	RS_Initialize(RASTER_WIDTH, RASTER_HEIGHT);


	Vertex GridWest[11];
	Vertex GridNorth[11];
	Vertex GridEast[11];
	Vertex GridSouth[11];


	float StartX = -0.5f;
	float endX = -0.5f;
	float StartZ = -0.5f;
	float endZ = -0.5f;


	for (int i = 0; i <= 11; i++)
	{
		GridWest[i].xyzw[0]	 = -0.5f;
		GridWest[i].xyzw[1]	 = 0.0f;
		GridWest[i].xyzw[2]	 = StartZ;
		GridWest[i].xyzw[3] = 1;
		StartZ += 0.1f;
	}
	for (int i = 0; i <= 11; i++)
	{
		GridNorth[i].xyzw[0] = StartX;
		GridNorth[i].xyzw[1] = 0.0f;
		GridNorth[i].xyzw[2] = 0.5f;
		GridNorth[i].xyzw[3] = 1;
		StartX += 0.1f;
	}
	for (int i = 0; i <= 11; i++)
	{
		GridEast[i].xyzw[0] = 0.5;
		GridEast[i].xyzw[1] = 0.0f;
		GridEast[i].xyzw[2] = endZ;
		GridEast[i].xyzw[3] = 1;
		endZ += 0.1f;
	}
	for (int i = 0; i <= 11; i++)
	{
		GridSouth[i].xyzw[0] = endX;
		GridSouth[i].xyzw[1] = 0.0f;
		GridSouth[i].xyzw[2] = -0.5f;
		GridSouth[i].xyzw[3] = 1;
		endX += 0.1f;
	}
	


	Vertex Cube[8];

	for (int i = 0; i < 8; i++)
	{
		Cube[i].xyzw[3] = 1;
	}

		Cube[0].xyzw[0] = -0.25f;
		Cube[0].xyzw[1] = 0.0f;
		Cube[0].xyzw[2] = 0.25f;
		

		Cube[1].xyzw[0] = 0.25f;
		Cube[1].xyzw[1] = 0.0f;
		Cube[1].xyzw[2] = 0.25f;
		

		Cube[2].xyzw[0] = 0.25f;
		Cube[2].xyzw[1] = 0.0f;
		Cube[2].xyzw[2] = -0.25f;
		

		Cube[3].xyzw[0] = -0.25f;
		Cube[3].xyzw[1] = 0.0f;
		Cube[3].xyzw[2] = -0.25f;

		Cube[4].xyzw[0] = -0.25f;
		Cube[4].xyzw[1] = 0.5f;
		Cube[4].xyzw[2] = 0.25f;


		Cube[5].xyzw[0] = 0.25f;
		Cube[5].xyzw[1] = 0.5f;
		Cube[5].xyzw[2] = 0.25f;


		Cube[6].xyzw[0] = 0.25f;
		Cube[6].xyzw[1] = 0.5f;
		Cube[6].xyzw[2] = -0.25f;


		Cube[7].xyzw[0] = -0.25f;
		Cube[7].xyzw[1] = 0.5f;
		Cube[7].xyzw[2] = -0.25f;
		
			
		SV_GridMatrix = Matrix_Identity();



		SV_viewMatrix = Matrix_Matrix_Multiply(Matrix_Create_Translation(0,0,-1), MatrixCreateRotationX(-18));
			
		SV_viewMatrix = Matrix_Inverse(SV_viewMatrix);
		

		SV_ProjectionMatrix = PerspectiveProjection( 0.1f, 10.0f );


		


	do
	{
		ClearBuffer();
		
		time.Signal();

		checktime = checktime + abs(time.SmoothDelta());

		if (checktime >= (1 / 60))
		{
			degrees += 0.1f;
			checktime = 0;

		}
		
			if (degrees >= 360)
				degrees = 0;

			VertexShader = VS_Grid;  
			PixelShader = PS_White; 
							
			for (int i = 0; i < 11; i++)
			{
				DrawLine2(GridWest[i], GridEast[i]);
				DrawLine2(GridNorth[i], GridSouth[i]);
			}


			VertexShader = VS_Cube;
			PixelShader = PS_Green;
			SV_CubeMatrix = MatrixCreateRotationY(degrees);
			/*SV_CubeMatrix._e42 -= 0.25;*/

			DrawLine2(Cube[0], Cube[1]);
			DrawLine2(Cube[1], Cube[2]);
			DrawLine2(Cube[2], Cube[3]);
			DrawLine2(Cube[3], Cube[0]);
					
			DrawLine2(Cube[4], Cube[5]);
			DrawLine2(Cube[5], Cube[6]);
			DrawLine2(Cube[6], Cube[7]);
			DrawLine2(Cube[7], Cube[4]);
					
			DrawLine2(Cube[0], Cube[4]);
			DrawLine2(Cube[1], Cube[5]);
			DrawLine2(Cube[2], Cube[6]);
			DrawLine2(Cube[3], Cube[7]);



			/*DrawLine(Triangle[1], Triangle[2]);
			DrawLine(Triangle[2], Triangle[0]);
			BruteForce(Triangle[0], Triangle[1], Triangle[2]);*/

	} while (RS_Update(Raster, NUM_PIXELS));

RS_Shutdown();
}
