#pragma once
#include "Math.h"
void(*VertexShader)(Vertex&) = 0;
void(*PixelShader)(unsigned int&) = 0;

TMATRIX SV_CubeMatrix;
TMATRIX SV_GridMatrix;
TMATRIX SV_viewMatrix;
TMATRIX SV_ProjectionMatrix;


Vertex line1;
Vertex line2;
Vertex line3;


void VS_Grid(Vertex &multiplyMe)
{
	multiplyMe = VectorMatrixMultiply(multiplyMe, SV_GridMatrix);
	multiplyMe = VectorMatrixMultiply(multiplyMe, SV_viewMatrix);
	multiplyMe = VectorMatrixMultiply(multiplyMe, SV_ProjectionMatrix);


	multiplyMe.xyzw[0] = multiplyMe.xyzw[0] / multiplyMe.xyzw[3];
	multiplyMe.xyzw[1] = multiplyMe.xyzw[1] / multiplyMe.xyzw[3];
	multiplyMe.xyzw[2] = multiplyMe.xyzw[2] / multiplyMe.xyzw[3];
}

void VS_Cube(Vertex &multiplyMe)
{
	multiplyMe = VectorMatrixMultiply(multiplyMe, SV_CubeMatrix);
	multiplyMe = VectorMatrixMultiply(multiplyMe, SV_viewMatrix);
	multiplyMe = VectorMatrixMultiply(multiplyMe, SV_ProjectionMatrix);


	multiplyMe.xyzw[0] = multiplyMe.xyzw[0] / multiplyMe.xyzw[3];
	multiplyMe.xyzw[1] = multiplyMe.xyzw[1] / multiplyMe.xyzw[3];
	multiplyMe.xyzw[2] = multiplyMe.xyzw[2] / multiplyMe.xyzw[3];

}
void PS_White(unsigned int &makeWhite)
{
	makeWhite = 0xFFFFFFFF;
}

void PS_Green(unsigned int &makeWhite)
{
	makeWhite = 0xFF00FF00;
}

void PS_ColorBlend(unsigned int &color)
{
	unsigned  int AlphaO = (line1.Color & 0xFF000000) >> 24;
	unsigned	int RedO = (line1.Color & 0x00FF0000) >> 16;
	unsigned  int GreenO = (line1.Color & 0x0000FF00) >> 8;
	unsigned   int BlueO = (line1.Color & 0x000000FF);

	unsigned  int AlphaC = (line2.Color & 0xFF000000) >> 24;
	unsigned	int RedC = (line2.Color & 0x00FF0000) >> 16;
	unsigned  int GreenC = (line2.Color & 0x0000FF00) >> 8;
	unsigned   int BlueC = (line2.Color & 0x000000FF);

	unsigned  int AlphaF = (line3.Color & 0xFF000000) >> 24;
	unsigned	int RedF = (line3.Color & 0x00FF0000) >> 16;
	unsigned  int GreenF = (line3.Color & 0x0000FF00) >> 8;
	unsigned   int BlueF = (line3.Color & 0x000000FF);


	unsigned	int BAlpha = AlphaO * line3.xyzw[2] + AlphaC * line1.xyzw[0] + AlphaF * line2.xyzw[1];
	unsigned	int BRed = RedO * line3.xyzw[2] + RedC * line1.xyzw[0] + RedF * line2.xyzw[1];
	unsigned	int BGreen = GreenO * line3.xyzw[2] + GreenC * line1.xyzw[0] + GreenF * line2.xyzw[1];
	unsigned	int BBlue = BlueO * line3.xyzw[2] + BlueC * line1.xyzw[0] + BlueF * line2.xyzw[1];

	BAlpha = BAlpha << 24;
	BRed = BRed << 16;
	BGreen = BGreen << 8;

	color = BAlpha | BRed | BGreen | BBlue;

}