#include <iostream>
#include "RasterSurface.h"
#include "tiles_12.h"
#include "fire_02.h"
#include "fire_01.h"
#include "time.h"

#include "XTime.h"
#define RASTER_WIDTH 500
#define RASTER_HEIGHT 500
#define NUM_PIXELS (RASTER_WIDTH * RASTER_HEIGHT)
using namespace std;


unsigned int Raster[NUM_PIXELS];


void ClearBuffer()
{
	for (unsigned int  i = 0; i < NUM_PIXELS; i++)
	{
			Raster[i] = 0x000000FF;
	}
}

unsigned int Convert2Dto1D(unsigned int  mWidth, unsigned int mHight)
{
	return mWidth * mHight;
}
void DrawPixel(unsigned int mPixel, unsigned int mColor)
{
	Raster[mPixel] = mColor;
}

unsigned int ColorBlend(unsigned int Current, unsigned int Original)
{
	int Alpha = (Original & 0x000000FF) << 24;
	int Red =   (Original & 0x0000FF00) << 8;
	int Green = (Original & 0x00FF0000) >> 8 ;
	int Blue =  (Original & 0xFF000000) >> 24;


	Original = Alpha | Red | Green | Blue;
	

       int AlphaO = ( Original & 0xFF000000) >> 24;
	   int RedO = ( Original & 0x00FF0000) >> 16;
	   int GreenO = ( Original & 0x0000FF00) >> 8;
	   int BlueO = ( Original & 0x000000FF);
	
	   int AlphaC = (Current & 0xFF000000) >> 24;
	   int RedC = (Current & 0x00FF0000) >> 16;
	   int GreenC = (Current & 0x0000FF00) >> 8;
	   int BlueC = (Current & 0x000000FF);

		float R = (float)(AlphaO / 255.0f);

		int BAlpha = (AlphaO - AlphaC) * R + AlphaC;
		int BRed =   (RedO - RedC) * R + RedC;
		int BGreen = (GreenO - GreenC) * R + GreenC;
		int BBlue =  (BlueO - BlueC) * R + BlueC;

		BAlpha = BAlpha << 24;
		BRed = BRed << 16;
		BGreen = BGreen << 8;

		Current = BAlpha | BRed | BGreen | BBlue;

		return Current;


}
void BLITBlockImageTransfer(unsigned int* mRaster,const unsigned int *mRom, unsigned int mWidthROM, unsigned int mHeightROM, unsigned int RSX, unsigned int RSY, unsigned int mWidthBlock, unsigned int mHeightBlock, unsigned int x, unsigned int y)
{
	for (unsigned int j = 0; j < mHeightBlock; j++)
	{
		for (unsigned int i = 0 ; i < mWidthBlock; i++)
		{		
			mRaster[x +  y * RASTER_WIDTH + i + (j * RASTER_WIDTH)] = ColorBlend(mRaster[x + y * RASTER_WIDTH + i + (j * RASTER_WIDTH)], mRom[RSX + RSY * mWidthROM + i + (j * mWidthROM)]);
		}
	}
	/*Pointer to Source Image Array(Pixels)
		Pointer to Destination Screen Array(Pixels)
		Source Image Array Dimensions(Width & Height)
		Destination Screen Array Dimensions(Width & Height)
		Source Image Sub - Rectangle to be Copied(ex: Left Top Right Bottom)
		Destination Copy - To Location X & Y(Drawing Position)*/
}

int main(void)
{
	ClearBuffer();
	
	RS_Initialize(RASTER_WIDTH, RASTER_HEIGHT);
	//color format XRGB
	XTime timer;
	unsigned int counter = 0;
	float checktime = 0;
	srand(time(NULL));
	unsigned int Random = rand()  % 400;
	unsigned int Random2 = rand() % 400;
	unsigned int Random3 = rand() % 400;
	unsigned int Random4 = rand() % 400;
	unsigned int Random5 = rand() % 400;
	unsigned int Random6 = rand() % 400;
	unsigned int Random7 = rand() % 400;
	unsigned int Random8 = rand() % 400;
	unsigned int Random9 = rand() % 400;
	unsigned int Random10 = rand() % 400;
	unsigned int Random11 = rand() % 400;
	unsigned int Random12 = rand() % 400;
	unsigned int Random13 = rand() % 400;
	unsigned int Random14 = rand() % 400;
	unsigned int Random15 = rand() % 400;
	unsigned int Random16 = rand() % 400;
	unsigned int Random17 = rand() % 400;
	unsigned int Random18 = rand() % 400;
	unsigned int Random19 = rand() % 400;
	unsigned int Random20 = rand() % 400;
	do
	{
		timer.Signal();
		
		checktime += timer.SmoothDelta();

		if (checktime >= (1 / 60))
		{
			if (counter >= 62)
				counter = 0;

			checktime = 0;
			counter++;
		}

		
		for (unsigned int i = 0; i < RASTER_HEIGHT; i+= 32)
		{
			for (unsigned int j = 0; j < RASTER_WIDTH; j += 32)
			{
				BLITBlockImageTransfer(Raster, tiles_12_pixels, tiles_12_width, tiles_12_height, 288, 128, 32, 32, j, i);
			}
		}
		
				BLITBlockImageTransfer(Raster, tiles_12_pixels, tiles_12_width, tiles_12_height, 321, 17, 63, 78, Random, Random2);
				BLITBlockImageTransfer(Raster, tiles_12_pixels, tiles_12_width, tiles_12_height, 321, 17, 63, 78, Random3, Random4);
				BLITBlockImageTransfer(Raster, tiles_12_pixels, tiles_12_width, tiles_12_height, 321, 17, 63, 78, Random5, Random6);
				BLITBlockImageTransfer(Raster, tiles_12_pixels, tiles_12_width, tiles_12_height, 321, 17, 63, 78, Random7, Random8);
				BLITBlockImageTransfer(Raster, tiles_12_pixels, tiles_12_width, tiles_12_height, 321, 17, 63, 78, Random9, Random10);
				BLITBlockImageTransfer(Raster, tiles_12_pixels, tiles_12_width, tiles_12_height, 321, 17, 63, 78, Random11, Random12);
				BLITBlockImageTransfer(Raster, tiles_12_pixels, tiles_12_width, tiles_12_height, 321, 17, 63, 78, Random13, Random14);
				BLITBlockImageTransfer(Raster, tiles_12_pixels, tiles_12_width, tiles_12_height, 321, 17, 63, 78, Random15, Random16);
				BLITBlockImageTransfer(Raster, tiles_12_pixels, tiles_12_width, tiles_12_height, 321, 17, 63, 78, Random17, Random18);
				BLITBlockImageTransfer(Raster, tiles_12_pixels, tiles_12_width, tiles_12_height, 321, 17, 63, 78, Random19, Random20);


		BLITBlockImageTransfer(Raster, fire_02_pixels, fire_02_width, fire_02_height, counter % 8 * 128, counter / 8 * 128, counter % 8 + 1 * 128, counter / 8 + 1 * 128, 0,0);
		//BLITBlockImageTransfer(Raster, fire_01_pixels, fire_01_width, fire_01_height, counter % 8 * 128, counter / 8 * 128, counter % 8 + 1 * 128, counter / 8 + 1 * 128, 0, 0);


				
	
	} while (RS_Update(Raster, NUM_PIXELS));



	RS_Shutdown();

	/*bool RS_Initialize(unsigned int _width, unsigned int _height);
	bool RS_Update(const unsigned int* _xrgbPixels, const unsigned int _numPixels);
	bool RS_Shutdown(void);*/


	return 0;
}