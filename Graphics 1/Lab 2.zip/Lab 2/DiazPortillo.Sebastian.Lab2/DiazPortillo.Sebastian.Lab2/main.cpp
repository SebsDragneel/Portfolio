#include <iostream>
#include <ctime>
#include "RasterSurface.h"
#include <windows.h>
#define RASTER_WIDTH 500
#define RASTER_HEIGHT 500
#define NUM_PIXELS (RASTER_WIDTH * RASTER_HEIGHT)
using namespace std;

unsigned int Raster[NUM_PIXELS];

struct Point
{
	float x;
	float y;
};
struct Star
{
	unsigned int x;
	unsigned int y;
};

Star Stars[2500];
void ClearBuffer()
{
	for (unsigned int i = 0; i < NUM_PIXELS; i++)
	{
		Raster[i] = 0x00000000;
	}
}

void DrawPixel(unsigned int x, unsigned int y, unsigned int mColor)
{
	Raster[x + y *RASTER_WIDTH] = mColor;
}

void Bresenham(unsigned int StartY, unsigned int StartX, unsigned int endY, unsigned int endX)
{
		int DeltaX1 = 0;
		int DeltaY1 = 0;
		int DeltaX2 = 0;
		int DeltaY2 = 0;
		int DeltaX = endX - StartX;
		int DeltaY = endY - StartY;

		if (DeltaX < 0)
			DeltaX1 = -1; 
		else if (DeltaX > 0)
			DeltaX1 = 1;

		if (DeltaY < 0)
			DeltaY1 = -1; 
		else if (DeltaY>0) 
			DeltaY1 = 1;

		if (DeltaX < 0)
			DeltaX2 = -1;
		else if (DeltaX > 0)
			DeltaX2 = 1;

		int LongestDelta = abs(DeltaX);
		int ShortestDelta = abs(DeltaY);

		if (!(LongestDelta > ShortestDelta)) 
		{
			LongestDelta = abs(DeltaY);
			ShortestDelta = abs(DeltaX);

			if (DeltaY < 0)
				DeltaY2 = -1;
			else if (DeltaY > 0)
				DeltaY2 = 1;

			DeltaX2 = 0;
		}

		int Numerator = LongestDelta >> 1;

		for (int i = 0; i <= LongestDelta; i++)
		{
			DrawPixel(StartX, StartY, 0xFFFF0000);
			Numerator += ShortestDelta;

			if (!(Numerator < LongestDelta)) 
			{
				Numerator -= LongestDelta;
				StartX += DeltaX1;
				StartY += DeltaY1;
			}
			else 
			{
				StartX += DeltaX2;
				StartY += DeltaY2;
			}
		}
}

void Midpoint(unsigned int StartY, unsigned int StartX, unsigned int endY, unsigned int endX)
{
	int DeltaX, DeltaY, Distance, IncrementY, IncrementE, IncrementNE;
	int SlopeMoreThan1 = 0;

	DeltaX = StartX - endX;
	DeltaY = StartY - endY;

	DeltaX = abs(DeltaX);
	DeltaY = abs(DeltaY);

	if (DeltaY > DeltaX)
	{
		swap(StartX, StartY);
		swap(endX, endY);
		swap(DeltaX, DeltaY);
		SlopeMoreThan1 = 1;
	}

	if (StartX > endX)
	{
		swap(StartX, endX);
		swap(StartY, endY);
	}

	if (StartY > endY)
		IncrementY = -1;
	else
		IncrementY = 1;

	Distance = 2 * DeltaY - DeltaX;
	IncrementE = 2 * DeltaY;
	IncrementNE = 2 * (DeltaY - DeltaX);

	while (StartX < endX)
	{
		if (Distance <= 0)
			Distance += IncrementE;
		else
		{
			Distance += IncrementNE;
			StartY += IncrementY;
		}

		StartX++;

		if (SlopeMoreThan1)
			DrawPixel(StartY, StartX, 0xFF00FF00);
		else
			DrawPixel(StartX, StartY, 0xFF00FF00);
	}
}


unsigned int ColorBlend(unsigned int Current, unsigned int Original, float R)
{


	unsigned  int AlphaO = (Original & 0xFF000000) >> 24;
	unsigned	int RedO = (Original & 0x00FF0000) >> 16;
	unsigned  int GreenO = (Original & 0x0000FF00) >> 8;
	unsigned   int BlueO = (Original & 0x000000FF);

	unsigned  int AlphaC = (Current & 0xFF000000) >> 24;
	unsigned	int RedC = (Current & 0x00FF0000) >> 16;
	unsigned  int GreenC = (Current & 0x0000FF00) >> 8;
	unsigned   int BlueC = (Current & 0x000000FF);

	


	unsigned	int BAlpha = (AlphaO - AlphaC) * R + AlphaC;
	unsigned	int BRed = (RedO - RedC) * R + RedC;
	unsigned	int BGreen = (GreenO - GreenC) * R + GreenC;
	unsigned	int BBlue = (BlueO - BlueC) * R + BlueC;

	BAlpha = BAlpha << 24;
	BRed = BRed << 16;
	BGreen = BGreen << 8;

	Current = BAlpha | BRed | BGreen | BBlue;

	return Current;


}
float Lerp(float start, float end, float ratio)
{
 return	(end - start) * ratio + start;
}
void Parametric(unsigned int StartY, unsigned int StartX, unsigned int endY, unsigned int endX)
{
	int DeltaX = endX - StartX;
	int DeltaY = endY - StartY;
	int LongestDelta = 0;

	if ((abs(DeltaX) > abs(DeltaY)))
		LongestDelta = abs(DeltaX);
	else
		LongestDelta = abs(DeltaY);

	for (int i = 0; i < LongestDelta; i++)
	{
		float Ratio = i / (float)LongestDelta;
		float currentX = Lerp(StartX, endX, Ratio);
		float currentY = Lerp(StartY, endY, Ratio);
		DrawPixel(currentX, currentY, ColorBlend(0xFFFF00FF, 0xFF00FFFF, Ratio));
	}
}

int main(void)
{
	
	int StartXRandB = 0;
	int StartYRandB = 0;
	  int EndXRandB = 0;
	  int EndYRandB = 0;
	  int StartXRandM = 0;
	  int StartYRandM = 0;
	  int EndXRandM = 0;
	  int EndYRandM = 0;
	  int StartXRandP = 0;
	  int StartYRandP = 0;
	  int EndXRandP = 0;
	  int EndYRandP = 0;
	bool DrawB = false;
	bool DrawM = false;
	bool DrawP = false;

	ClearBuffer();

	RS_Initialize(RASTER_WIDTH, RASTER_HEIGHT);

	
	
	for (int i = 0; i < 2500; i++)
	{
		Stars[i].x = rand() % RASTER_WIDTH;
		Stars[i].y = rand() % RASTER_HEIGHT;
	}
	
	do
	{
		
		for (int i = 0; i < 2500; i++)
		{
			DrawPixel(Stars[i].x, Stars[i].y, 0xFFFFFFFF);
		}

		if (GetAsyncKeyState('1'))
		{
			StartXRandB = rand() % RASTER_WIDTH;
			StartYRandB= rand() % RASTER_HEIGHT;
			EndXRandB = rand() % RASTER_WIDTH;
			EndYRandB = rand() % RASTER_HEIGHT;
			DrawB = true;
			DrawM = false;
			DrawP = false;
		}
		if (GetAsyncKeyState('2'))
		{
			StartXRandM = rand() % RASTER_WIDTH;
			StartYRandM = rand() % RASTER_HEIGHT;
			EndXRandM = rand() % RASTER_WIDTH;
			EndYRandM = rand() % RASTER_HEIGHT;
			DrawB = false;
			DrawM = true;
			DrawP = false;
		}
		if (GetAsyncKeyState('3'))
		{
			StartXRandP = rand() % RASTER_WIDTH;
			StartYRandP = rand() % RASTER_HEIGHT;
			EndXRandP = rand() % RASTER_WIDTH;
			EndYRandP = rand() % RASTER_HEIGHT;
			DrawB = false;
			DrawM = false;
			DrawP = true;
		}
		if (GetAsyncKeyState('4'))
		{
			DrawB = false;
			DrawM = false;
			DrawP = false;
			StartXRandB = 0;
			StartYRandB = 0;
			EndXRandB = 0;
			EndYRandB = 0;
			StartXRandM = 0;
			StartYRandM = 0;
			EndXRandM = 0;
			EndYRandM = 0;
			StartXRandP = 0;
			StartYRandP = 0;
			EndXRandP = 0;
			EndYRandP = 0;

			ClearBuffer();
		}
		Sleep(150);

		if (DrawB)
		{

			ClearBuffer();	
			Bresenham(StartYRandB, StartXRandB, EndYRandB, EndXRandB);
			Midpoint(StartYRandM, StartXRandM, EndYRandM, EndXRandM);
			Parametric(StartYRandP, StartXRandP, EndYRandP, EndXRandP);
			DrawPixel(StartXRandB, StartYRandB, 0x00FFFF00);
			DrawPixel(EndXRandB, EndYRandB, 0x00FFFF00);
			DrawPixel(StartXRandM, StartYRandM, 0x00FFFF00);
			DrawPixel(EndXRandM, EndYRandM, 0x00FFFF00);
			DrawPixel(StartXRandP, StartYRandP, 0x00FFFF00);
			DrawPixel(EndXRandP, EndYRandP, 0x00FFFF00);
			
		}
		
		if (DrawM)
		{
			ClearBuffer();
			Bresenham(StartYRandB, StartXRandB, EndYRandB, EndXRandB);
			Midpoint(StartYRandM, StartXRandM, EndYRandM, EndXRandM);
			Parametric(StartYRandP, StartXRandP, EndYRandP, EndXRandP);
			DrawPixel(StartXRandB, StartYRandB, 0x00FFFF00);
			DrawPixel(EndXRandB, EndYRandB, 0x00FFFF00);
			DrawPixel(StartXRandM, StartYRandM, 0x00FFFF00);
			DrawPixel(EndXRandM, EndYRandM, 0x00FFFF00);
			DrawPixel(StartXRandP, StartYRandP, 0x00FFFF00);
			DrawPixel(EndXRandP, EndYRandP, 0x00FFFF00);
		}
		if (DrawP)
		{
			ClearBuffer();
			Bresenham(StartYRandB, StartXRandB, EndYRandB, EndXRandB);
			Midpoint(StartYRandM, StartXRandM, EndYRandM, EndXRandM);
			Parametric(StartYRandP, StartXRandP, EndYRandP, EndXRandP);
			DrawPixel(StartXRandB, StartYRandB, 0x00FFFF00);
			DrawPixel(EndXRandB, EndYRandB, 0x00FFFF00);
			DrawPixel(StartXRandM, StartYRandM, 0x00FFFF00);
			DrawPixel(EndXRandM, EndYRandM, 0x00FFFF00);
			DrawPixel(StartXRandP, StartYRandP, 0x00FFFF00);
			DrawPixel(EndXRandP, EndYRandP, 0x00FFFF00);
		}
		


		Bresenham(100, 0, 400, 499);
		Midpoint(110, 0, 410, 499);
		Parametric(120, 0, 420, 499);

	} while (RS_Update(Raster, NUM_PIXELS));

	RS_Shutdown();

	return 0;
}