#pragma once
#include "defines.h"

float ImplicitLineEquation(Point A, Point B, Point C)
{
	float result = 0;
	result = ((A.y - B.y)*C.x) + ((B.x - A.x)*C.y) + (A.x * B.y) - (A.y * B.x);
	return result;
}

TMATRIX Matrix_Matrix_Add(TMATRIX m, TMATRIX n)
{
	m._e11 = m._e11 + n._e11;
	m._e12 = m._e12 + n._e12;
	m._e13 = m._e13 + n._e13;
	m._e14 = m._e14 + n._e14;
	m._e21 = m._e21 + n._e21;
	m._e22 = m._e22 + n._e22;
	m._e23 = m._e23 + n._e23;
	m._e24 = m._e24 + n._e24;
	m._e31 = m._e31 + n._e31;
	m._e32 = m._e32 + n._e32;
	m._e33 = m._e33 + n._e33;
	m._e34 = m._e34 + n._e34;
	m._e41 = m._e41 + n._e41;
	m._e42 = m._e42 + n._e42;
	m._e43 = m._e43 + n._e43;
	m._e44 = m._e44 + n._e44;

	return m;
}

float Degrees_To_Radians(float Deg)
{
	return Deg * PI / 180.0f;
}

TMATRIX Matrix_Identity(void)
{
	TMATRIX m = { 1, 0, 0, 0,
		0, 1, 0, 0,
		0, 0, 1, 0,
		0, 0, 0, 1 };
	return m;
}


TMATRIX Matrix_Create_Translation(float x, float y, float z)
{
	TMATRIX m = { 1, 0, 0, 0,
		0, 1, 0, 0,
		0, 0, 1, 0,
		x, y, z, 1 };
	return m;
}
TMATRIX MatrixCreateRotationZ(float Deg)
{
	TMATRIX m = { cosf(Degrees_To_Radians(Deg)),-sinf(Degrees_To_Radians(Deg)), 0, 0,
		sinf(Degrees_To_Radians(Deg)), cosf(Degrees_To_Radians(Deg)), 0, 0,
		0, 0, 1, 0,
		0, 0, 0, 1 };
	return m;
}

TMATRIX MatrixCreateRotationX(float Deg)
{
	TMATRIX m = { 1, 0, 0, 0,
		0, cosf(Degrees_To_Radians(Deg)), -sinf(Degrees_To_Radians(Deg)), 0,
		0, sinf(Degrees_To_Radians(Deg)), cosf(Degrees_To_Radians(Deg)), 0,
		0, 0, 0, 1 };
	return m;
}

TMATRIX MatrixCreateRotationY(float Deg)
{
	TMATRIX m = { cosf(Degrees_To_Radians(Deg)), 0, sinf(Degrees_To_Radians(Deg)), 0,
		0, 1, 0, 0,
		-sinf(Degrees_To_Radians(Deg)), 0, cosf(Degrees_To_Radians(Deg)), 0,
		0, 0, 0, 1 };
	return m;
}

Vertex VectorMatrixMultiply(Vertex v, TMATRIX m)
{
	Vertex mTemp;
	mTemp.x = ((v.x * m._e11) + (v.y * m._e21) + (v.z * m._e31) + (v.w * m._e41));
	mTemp.y = ((v.x * m._e12) + (v.y * m._e22) + (v.z * m._e32) + (v.w * m._e42));
	mTemp.z = ((v.x * m._e13) + (v.y * m._e23) + (v.z * m._e33) + (v.w * m._e43));
	mTemp.w = ((v.x * m._e14) + (v.y * m._e24) + (v.z * m._e34) + (v.w * m._e44));
	return mTemp;
}

TMATRIX Matrix_Matrix_Multiply(TMATRIX m, TMATRIX n)
{
	TMATRIX mTemp;
	mTemp._e11 = ((m._e11 * n._e11) + (m._e12 * n._e21) + (m._e13 * n._e31) + (m._e14 * n._e41));
	mTemp._e12 = ((m._e11 * n._e12) + (m._e12 * n._e22) + (m._e13 * n._e32) + (m._e14 * n._e42));
	mTemp._e13 = ((m._e11 * n._e13) + (m._e12 * n._e23) + (m._e13 * n._e33) + (m._e14 * n._e43));
	mTemp._e14 = ((m._e11 * n._e14) + (m._e12 * n._e24) + (m._e13 * n._e34) + (m._e14 * n._e44));
	mTemp._e21 = ((m._e21 * n._e11) + (m._e22 * n._e21) + (m._e23 * n._e31) + (m._e24 * n._e41));
	mTemp._e22 = ((m._e21 * n._e12) + (m._e22 * n._e22) + (m._e23 * n._e32) + (m._e24 * n._e42));
	mTemp._e23 = ((m._e21 * n._e13) + (m._e22 * n._e23) + (m._e23 * n._e33) + (m._e24 * n._e43));
	mTemp._e24 = ((m._e21 * n._e14) + (m._e22 * n._e24) + (m._e23 * n._e34) + (m._e24 * n._e44));
	mTemp._e31 = ((m._e31 * n._e11) + (m._e32 * n._e21) + (m._e33 * n._e31) + (m._e34 * n._e41));
	mTemp._e32 = ((m._e31 * n._e12) + (m._e32 * n._e22) + (m._e33 * n._e32) + (m._e34 * n._e42));
	mTemp._e33 = ((m._e31 * n._e13) + (m._e32 * n._e23) + (m._e33 * n._e33) + (m._e34 * n._e43));
	mTemp._e34 = ((m._e31 * n._e14) + (m._e32 * n._e24) + (m._e33 * n._e34) + (m._e34 * n._e44));
	mTemp._e41 = ((m._e41 * n._e11) + (m._e42 * n._e21) + (m._e43 * n._e31) + (m._e44 * n._e41));
	mTemp._e42 = ((m._e41 * n._e12) + (m._e42 * n._e22) + (m._e43 * n._e32) + (m._e44 * n._e42));
	mTemp._e43 = ((m._e41 * n._e13) + (m._e42 * n._e23) + (m._e43 * n._e33) + (m._e44 * n._e43));
	mTemp._e44 = ((m._e41 * n._e14) + (m._e42 * n._e24) + (m._e43 * n._e34) + (m._e44 * n._e44));

	return mTemp;
}

TMATRIX Matrix_Transpose(TMATRIX m)
{
	TMATRIX mTemp;
	mTemp._e11 = m._e11;
	mTemp._e21 = m._e12;
	mTemp._e31 = m._e13;
	mTemp._e41 = m._e14;
	mTemp._e12 = m._e21;
	mTemp._e22 = m._e22;
	mTemp._e32 = m._e23;
	mTemp._e42 = m._e24;
	mTemp._e13 = m._e31;
	mTemp._e23 = m._e32;
	mTemp._e33 = m._e33;
	mTemp._e43 = m._e34;
	mTemp._e14 = m._e41;
	mTemp._e24 = m._e42;
	mTemp._e34 = m._e43;
	mTemp._e44 = m._e44;
	return mTemp;
}

float Matrix_Determinant(float e_11, float e_12, float e_13,
	float e_21, float e_22, float e_23,
	float e_31, float e_32, float e_33)
{
	float mTemp;
	mTemp = ((e_11 * ((e_22 * e_33) - (e_32 * e_23))) - (e_12 * ((e_21 * e_33) - (e_31 * e_23))) + (e_13 * ((e_21 * e_32) - (e_31 * e_22))));

	return mTemp;
}

float Matrix_Determinant(TMATRIX m)
{
	float mTemp;

	mTemp = ((m._e11 * Matrix_Determinant(m._e22, m._e23, m._e24, m._e32, m._e33, m._e34, m._e42, m._e43, m._e44))
		- (m._e12 * Matrix_Determinant(m._e21, m._e23, m._e24, m._e31, m._e33, m._e34, m._e41, m._e43, m._e44))
		+ (m._e13 * Matrix_Determinant(m._e21, m._e22, m._e24, m._e31, m._e32, m._e34, m._e41, m._e42, m._e44))
		- (m._e14 * Matrix_Determinant(m._e21, m._e22, m._e23, m._e31, m._e32, m._e33, m._e41, m._e42, m._e43))
		);

	return mTemp;
}
TMATRIX Matrix_Inverse(TMATRIX m)
{
	float mDet = Matrix_Determinant(m);

	float c11 = Matrix_Determinant(m._e22, m._e23, m._e24, m._e32, m._e33, m._e34, m._e42, m._e43, m._e44);
	float c12 = -Matrix_Determinant(m._e21, m._e23, m._e24, m._e31, m._e33, m._e34, m._e41, m._e43, m._e44);
	float c13 = Matrix_Determinant(m._e21, m._e22, m._e24, m._e31, m._e32, m._e34, m._e41, m._e42, m._e44);
	float c14 = -Matrix_Determinant(m._e21, m._e22, m._e23, m._e31, m._e32, m._e33, m._e41, m._e42, m._e43);
	float c21 = -Matrix_Determinant(m._e12, m._e13, m._e14, m._e32, m._e33, m._e34, m._e42, m._e43, m._e44);
	float c22 = Matrix_Determinant(m._e11, m._e13, m._e14, m._e31, m._e33, m._e34, m._e41, m._e43, m._e44);
	float c23 = -Matrix_Determinant(m._e11, m._e12, m._e14, m._e31, m._e32, m._e34, m._e41, m._e42, m._e44);
	float c24 = Matrix_Determinant(m._e11, m._e12, m._e13, m._e31, m._e32, m._e33, m._e41, m._e42, m._e43);
	float c31 = Matrix_Determinant(m._e12, m._e13, m._e14, m._e22, m._e23, m._e24, m._e42, m._e43, m._e44);
	float c32 = -Matrix_Determinant(m._e11, m._e13, m._e14, m._e21, m._e23, m._e24, m._e41, m._e43, m._e44);
	float c33 = Matrix_Determinant(m._e11, m._e12, m._e14, m._e21, m._e22, m._e24, m._e41, m._e42, m._e44);
	float c34 = -Matrix_Determinant(m._e11, m._e12, m._e13, m._e21, m._e22, m._e23, m._e41, m._e42, m._e43);
	float c41 = -Matrix_Determinant(m._e12, m._e13, m._e14, m._e22, m._e23, m._e24, m._e32, m._e33, m._e34);
	float c42 = Matrix_Determinant(m._e11, m._e13, m._e14, m._e21, m._e23, m._e24, m._e31, m._e33, m._e34);
	float c43 = -Matrix_Determinant(m._e11, m._e12, m._e14, m._e21, m._e22, m._e24, m._e31, m._e32, m._e34);
	float c44 = Matrix_Determinant(m._e11, m._e12, m._e13, m._e21, m._e22, m._e23, m._e31, m._e32, m._e33);

	TMATRIX mAdj;
	mAdj._e11 = c11;
	mAdj._e12 = c12;
	mAdj._e13 = c13;
	mAdj._e14 = c14;
	mAdj._e21 = c21;
	mAdj._e22 = c22;
	mAdj._e23 = c23;
	mAdj._e24 = c24;
	mAdj._e31 = c31;
	mAdj._e32 = c32;
	mAdj._e33 = c33;
	mAdj._e34 = c34;
	mAdj._e41 = c41;
	mAdj._e42 = c42;
	mAdj._e43 = c43;
	mAdj._e44 = c44;

	TMATRIX mInverse = Matrix_Transpose(mAdj);
	mInverse._e11 = mInverse._e11 / mDet;
	mInverse._e12 = mInverse._e12 / mDet;
	mInverse._e13 = mInverse._e13 / mDet;
	mInverse._e14 = mInverse._e14 / mDet;
	mInverse._e21 = mInverse._e21 / mDet;
	mInverse._e22 = mInverse._e22 / mDet;
	mInverse._e23 = mInverse._e23 / mDet;
	mInverse._e24 = mInverse._e24 / mDet;
	mInverse._e31 = mInverse._e31 / mDet;
	mInverse._e32 = mInverse._e32 / mDet;
	mInverse._e33 = mInverse._e33 / mDet;
	mInverse._e34 = mInverse._e34 / mDet;
	mInverse._e41 = mInverse._e41 / mDet;
	mInverse._e42 = mInverse._e42 / mDet;
	mInverse._e43 = mInverse._e43 / mDet;
	mInverse._e44 = mInverse._e44 / mDet;

	if (mDet == 0)
	{
		return m;
	}

	return mInverse;
}

TMATRIX PerspectiveProjection(float zNear, float zFar)
{
	float YScale, XScale;
	YScale = 1.0f / tanf(Degrees_To_Radians(0.5f * HorizontalFOV));
	XScale = YScale * aspectratio;
	TMATRIX Projection = { XScale, 0, 0, 0,
							0, YScale, 0, 0,
							0, 0,zFar / (zFar - zNear), 1,
							0, 0,-(zFar * zNear) / (zFar - zNear), 0 };
	return Projection;
}

unsigned int UVToScreen(float U, float V)
{
	int iU = (unsigned int)(U * /*Newlatest_width*/ flower_width);
	int iV = (unsigned int)(V * /*Newlatest_height*/ flower_height);

		unsigned int makeWhite = /*Newlatest_pixels*/ flower_pixels[iU + iV * /*Newlatest_width*/ flower_width];
		return makeWhite;
}

float Min(float n1, float n2, float n3)
{
	float min = 0;

	if (n1 < n2 && n1 < n3)
		min = n1;
	if (n2 < n1 && n2 < n3)
		min = n2;
	if (n3 < n1 && n3 < n2)
		min = n3;

	return min;
}

float Max(float n1, float n2, float n3)
{
	float max = 0;
	if (n1 > n2 && n1 > n3)
		max = n1;
	if (n2 > n1 && n2 > n3)
		max = n2;
	if (n3 > n1 && n3 > n2)
		max = n3;

	return max;
}
