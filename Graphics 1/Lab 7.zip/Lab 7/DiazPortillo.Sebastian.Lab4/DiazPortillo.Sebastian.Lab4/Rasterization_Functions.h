#pragma once
#include "Shaders.h"

void ClearBuffer()
{
	for (unsigned int i = 0; i < NUM_PIXELS; i++)
	{
		Raster[i] = 0x00000000;
		Depth[i] = 1.0f;
	}
}

void DrawPixel(unsigned int x, unsigned int y, unsigned int mColor, float z)
{
	if (!(x > RASTER_WIDTH || y > RASTER_HEIGHT))
	{
		if ( z < Depth[x + y *RASTER_WIDTH])
		{
			Raster[x + y *RASTER_WIDTH] = mColor;
			Depth[x + y *RASTER_WIDTH] = z;
		}
	}
}


Point CartesianToScreen(Vertex ToConvert)
{
	Point point;
	float x = ToConvert.x;
	float y = ToConvert.y;
	float z = ToConvert.z;
	unsigned int color = ToConvert.Color;

	point.x = (x + 1.0f) * (RASTER_WIDTH / 2.0f);
	point.y = (1.0f - y) * (RASTER_HEIGHT / 2.0f);
	point.z = z;
	point.U = ToConvert.U;
	point.V = ToConvert.V;
	point.Color = color;
	return point;
}

unsigned int ConvertColor (unsigned int Original)
{
	unsigned	int Alpha = (Original & 0x000000FF) << 24;
	unsigned	int Red = (Original & 0x0000FF00) << 8;
	unsigned	int Green = (Original & 0x00FF0000) >> 8;
	unsigned	int Blue = (Original & 0xFF000000) >> 24;


	Original = Alpha | Red | Green | Blue;

	return Original;
}
unsigned int ColorBlend1(unsigned int Current, unsigned int Original)
{
	unsigned	int Alpha = (Original & 0x000000FF) << 24;
	unsigned	int Red = (Original & 0x0000FF00) << 8;
	unsigned	int Green = (Original & 0x00FF0000) >> 8;
	unsigned	int Blue = (Original & 0xFF000000) >> 24;


	Original = Alpha | Red | Green | Blue;


	unsigned  int AlphaO = (Original & 0xFF000000) >> 24;
	unsigned	int RedO = (Original & 0x00FF0000) >> 16;
	unsigned  int GreenO = (Original & 0x0000FF00) >> 8;
	unsigned   int BlueO = (Original & 0x000000FF);

	unsigned  int AlphaC = (Current & 0xFF000000) >> 24;
	unsigned	int RedC = (Current & 0x00FF0000) >> 16;
	unsigned  int GreenC = (Current & 0x0000FF00) >> 8;
	unsigned   int BlueC = (Current & 0x000000FF);

	float R = AlphaO / 255.0f;

	unsigned	int BAlpha = (unsigned int)((AlphaO - AlphaC) * R + AlphaC);
	unsigned	int BRed = (unsigned int)((RedO - RedC) * R + RedC);
	unsigned	int BGreen = (unsigned int)((GreenO - GreenC) * R + GreenC);
	unsigned	int BBlue = (unsigned int)((BlueO - BlueC) * R + BlueC);

	BAlpha = BAlpha << 24;
	BRed = BRed << 16;
	BGreen = BGreen << 8;

	Current = BAlpha | BRed | BGreen | BBlue;

	return Current;


}

unsigned int ColorBlend(unsigned int Current, unsigned int Original, float R)
{
	unsigned  int AlphaO = (Original & 0xFF000000) >> 24;
	unsigned	int RedO = (Original & 0x00FF0000) >> 16;
	unsigned  int GreenO = (Original & 0x0000FF00) >> 8;
	unsigned   int BlueO = (Original & 0x000000FF);

	unsigned  int AlphaC = (Current & 0xFF000000) >> 24;
	unsigned	int RedC = (Current & 0x00FF0000) >> 16;
	unsigned  int GreenC = (Current & 0x0000FF00) >> 8;
	unsigned   int BlueC = (Current & 0x000000FF);




	unsigned	int BAlpha = (unsigned int)((AlphaO - AlphaC) * R + AlphaC);
	unsigned	int BRed = (unsigned int)((RedO - RedC) * R + RedC);
	unsigned	int BGreen = (unsigned int)((GreenO - GreenC) * R + GreenC);
	unsigned	int BBlue = (unsigned int)((BlueO - BlueC) * R + BlueC);

	BAlpha = BAlpha << 24;
	BRed = BRed << 16;
	BGreen = BGreen << 8;

	Current = BAlpha | BRed | BGreen | BBlue;

	return Current;
}


void DrawLine(Vertex start, Vertex end)
{
	// Copy input data and send through shaders
	Vertex copy_start = start;
	Vertex copy_end = end;
	// Use vertex shader to modify incoming copies only.
	if (VertexShader)
	{
		VertexShader(copy_start);
		VertexShader(copy_end);
	}
	// original plotting variables adapted to use new cartesian data
	Point screen_start = CartesianToScreen(copy_start);
	Point screen_end = CartesianToScreen(copy_end);

	float DeltaX = screen_end.x - screen_start.x;
	float DeltaY = screen_end.y - screen_start.y;
	float Longest = (abs(DeltaX) > abs(DeltaY)) ? abs(DeltaX) : abs(DeltaY);

	for (int i = 0; i < Longest; i++)
	{
		float r = i / (float)Longest;
		float currentX = (screen_end.x - screen_start.x) * r + screen_start.x;
		float currentY = (screen_end.y - screen_start.y) * r + screen_start.y;
		float currentZ = (screen_end.z - screen_start.z) * r + screen_start.z;

		unsigned int color;

		if (PixelShader)
		{
			PixelShader(color);
			DrawPixel((unsigned int)currentX, (unsigned int)currentY, color, currentZ);
		}
		else
		{
			DrawPixel((unsigned int)currentX, (unsigned int)currentY, 0xFFFF00FF, currentZ);
		}
	}


}
float Ratio(float a, float b, float c, float Alpha, float Beta, float Gamma)
{
	float ZRatio = (a * Alpha) + (b* Beta) + (c *Gamma);
	return ZRatio;
}

void BruteForce(Vertex &l1, Vertex &l2, Vertex &l3)
{
	Vertex copy_line1 = l1;
	Vertex copy_line2 = l2;
	Vertex copy_line3 = l3;


	if (VertexShader)
	{
		VertexShader(copy_line1);
		VertexShader(copy_line2);
		VertexShader(copy_line3);
	}

	copy_line1.U = l1.U;
	copy_line2.U = l2.U;
	copy_line3.U = l3.U;

	copy_line1.V = l1.V;
	copy_line2.V = l2.V;
	copy_line3.V = l3.V;

	copy_line1.U = l1.U / copy_line1.w;
	copy_line2.U = l2.U / copy_line2.w;
	copy_line3.U = l3.U / copy_line3.w;

	copy_line1.V = l1.V / copy_line1.w;
	copy_line2.V = l2.V / copy_line2.w;
	copy_line3.V = l3.V / copy_line3.w;

	float RA = 1 / copy_line1.w;
	float RB = 1 / copy_line2.w;
	float RC = 1 / copy_line3.w;

	Point screen_line1 = CartesianToScreen(copy_line1);
	Point screen_line2 = CartesianToScreen(copy_line2);
	Point screen_line3 = CartesianToScreen(copy_line3);

	float StartX = Min(screen_line1.x, screen_line2.x, screen_line3.x);
	float StartY = Min(screen_line1.y, screen_line2.y, screen_line3.y);
	float EndX = Max(screen_line1.x, screen_line2.x, screen_line3.x);
	float EndY = Max(screen_line1.y, screen_line2.y, screen_line3.y);
	


	screen_line1.Color = l1.Color;
	screen_line2.Color = l2.Color;
	screen_line3.Color = l3.Color;

	float Beta = ImplicitLineEquation(screen_line1, screen_line3, screen_line2);
	float Gamma = ImplicitLineEquation(screen_line2, screen_line1, screen_line3);
	float Alpha = ImplicitLineEquation(screen_line3, screen_line2, screen_line1);

	for (float j = StartY; j <= EndY; j++)
	{
		for (float i = StartX; i <= EndX; i++)
		{
			Point screenline;
			screenline.x = i;
			screenline.y = j;

			float b = ImplicitLineEquation(screen_line1, screen_line3, screenline);
			float y = ImplicitLineEquation(screen_line2, screen_line1, screenline);
			float a = ImplicitLineEquation(screen_line3, screen_line2, screenline);

			Vertex ratio;

			ratio.x = b / Beta;
			ratio.y = y / Gamma;
			ratio.z = a / Alpha;

			if (ratio.x >= 0 && ratio.x <= 1 && ratio.y >= 0 && ratio.y <= 1 && ratio.z >= 0 && ratio.z <= 1)
			{
				float interpU = Ratio(screen_line1.U, screen_line2.U, screen_line3.U, ratio.z, ratio.x, ratio.y);
				float interpV = Ratio(screen_line1.V, screen_line2.V, screen_line3.V, ratio.z, ratio.x, ratio.y);
				float interpZ = Ratio(screen_line1.z, screen_line2.z, screen_line3.z, ratio.z, ratio.x, ratio.y);
				float interpR = Ratio( RA, RB, RC, ratio.z, ratio.x, ratio.y);
				Point NewZ;			 
				NewZ.U = interpU / interpR;
				NewZ.V = interpV / interpR;
				NewZ.z = interpZ;

				unsigned int Level = ((interpZ - 0.1f) / (10 - 0.1f)) * Newlatest_numlevels;
				unsigned int offset = Newlatest_leveloffsets[Level];
				unsigned int newWidth = Newlatest_width >> Level;
				unsigned int newHeight = Newlatest_height >> Level;

				NewZ.U *= newWidth;
				NewZ.V *= newHeight;


				
				if (PixelShader)
				{
					line1.x = ratio.x;
					line2.y = ratio.y;
					line3.z = ratio.z;
					line1.Color = screen_line1.Color;
					line2.Color = screen_line2.Color;
					line3.Color = screen_line3.Color;
			

					unsigned int newcolors = UVToScreen(NewZ.U, NewZ.V, offset, newWidth);
					newcolors = ConvertColor(newcolors);
				/*	unsigned int colors;
					PixelShader(colors);*/

					DrawPixel((unsigned int)screenline.x, (unsigned int)screenline.y, newcolors, NewZ.z);
				}
				else
					DrawPixel((unsigned int)screenline.x, (unsigned int)screenline.y, 0x00FF0000, NewZ.z);
			}
		}
	}
}


void CreateStars()
{
	if (VertexShader)
	{
		for (int  i = 0; i < NUM_Stars; i++)
		{
			Vertex Copy;
			Copy = Stars[i];
			VertexShader(Copy);
			Point screen = CartesianToScreen(Copy);
			DrawPixel(screen.x, screen.y, 0x00FFFFFF, screen.z);
		}	
	}
}

void CreateMap()
{
	if (VertexShader)
	{
		for (unsigned int i = 0; i < 2532; i+=3)
		{
			BruteForce(Map[StoneHenge_indicies[i]], Map[StoneHenge_indicies[i+1]], Map[StoneHenge_indicies[i+2]]);
		}
	}
}