#pragma once
#include <random>
#include <iostream>
#include <ctime>
#include <windows.h>
#include "RasterSurface.h"
#include "XTime.h"
#include "Newlatest.h"
#include "StoneHenge.h"
#define PI 3.14159f
#define RASTER_WIDTH 800
#define RASTER_HEIGHT 600
#define HorizontalFOV 90
#define NUM_Stars 3000
#define NUM_PixelsMAP 1457
#define aspectratio ((float)RASTER_HEIGHT / (float)RASTER_WIDTH)
#define VerticalFOV (HorizontalFOV * aspectratio)
#define NUM_PIXELS (RASTER_WIDTH * RASTER_HEIGHT)
using namespace std;
unsigned int Raster[NUM_PIXELS];
float Depth[NUM_PIXELS];



struct Vertex 
{ 
	float x;
	float y;
	float z;
	float w;
	float U;
	float V;
	float nx;
	float ny;
	float nz;

	unsigned int  Color;
};
struct Point
{
	float x;
	float y;
	float z;
	float U;
	float V;
	unsigned int  Color;
};


typedef union TMATRIX
{
	float e[16];
	struct
	{
		float _e11, _e12, _e13, _e14;
		float _e21, _e22, _e23, _e24;
		float _e31, _e32, _e33, _e34;
		float _e41, _e42, _e43, _e44;
	};
}*LPTMATRIX;


Vertex Map[NUM_PixelsMAP];
Vertex Stars[NUM_Stars];


