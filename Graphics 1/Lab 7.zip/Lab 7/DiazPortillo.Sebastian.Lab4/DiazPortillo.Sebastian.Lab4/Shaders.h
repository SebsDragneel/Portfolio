#pragma once
#include "Math.h"
void(*VertexShader)(Vertex&) = 0;
void(*PixelShader)(unsigned int&) = 0;

TMATRIX SV_CubeMatrix;
TMATRIX SV_GridMatrix;
TMATRIX SV_viewMatrix;
TMATRIX SV_ProjectionMatrix;


Vertex line1;
Vertex line2;
Vertex line3;


void VS_Map(Vertex &multiplyMe)
{
	multiplyMe = VectorMatrixMultiply(multiplyMe, SV_GridMatrix);
	multiplyMe = VectorMatrixMultiply(multiplyMe, SV_viewMatrix);
	multiplyMe = VectorMatrixMultiply(multiplyMe, SV_ProjectionMatrix);


	multiplyMe.x = multiplyMe.x / multiplyMe.w;
	multiplyMe.y = multiplyMe.y / multiplyMe.w;
	multiplyMe.z = multiplyMe.z / multiplyMe.w;
}

void VS_Stars(Vertex &multiplyMe)
{
	multiplyMe = VectorMatrixMultiply(multiplyMe, SV_GridMatrix);
	multiplyMe = VectorMatrixMultiply(multiplyMe, SV_viewMatrix);
	multiplyMe = VectorMatrixMultiply(multiplyMe, SV_ProjectionMatrix);

	multiplyMe.x = multiplyMe.x / multiplyMe.w;
	multiplyMe.y = multiplyMe.y / multiplyMe.w;
	multiplyMe.z = multiplyMe.z / multiplyMe.w;
}

void VS_Grid(Vertex &multiplyMe)
{
	multiplyMe = VectorMatrixMultiply(multiplyMe, SV_GridMatrix);
	multiplyMe = VectorMatrixMultiply(multiplyMe, SV_viewMatrix);
	multiplyMe = VectorMatrixMultiply(multiplyMe, SV_ProjectionMatrix);


	multiplyMe.x = multiplyMe.x / multiplyMe.w;
	multiplyMe.y = multiplyMe.y / multiplyMe.w;
	multiplyMe.z = multiplyMe.z / multiplyMe.w;
}

void VS_Cube(Vertex &multiplyMe)
{
	multiplyMe = VectorMatrixMultiply(multiplyMe, SV_CubeMatrix);
	multiplyMe = VectorMatrixMultiply(multiplyMe, SV_viewMatrix);
	multiplyMe = VectorMatrixMultiply(multiplyMe, SV_ProjectionMatrix);


	multiplyMe.x = multiplyMe.x / multiplyMe.w;
	multiplyMe.y = multiplyMe.y / multiplyMe.w;
	multiplyMe.z = multiplyMe.z / multiplyMe.w;
}

void PS_White(unsigned int &makeWhite)
{

	makeWhite = 0x00FFFFFF;
} 


void PS_Green(unsigned int &makeWhite)
{
	makeWhite = 0x0000FF00;
}
void PS_Red(unsigned int &makeWhite)
{
	makeWhite = 0x00FF0000;
}

void PS_Blue(unsigned int &makeWhite)
{
	makeWhite = 0xFF0000FF;
}

void PS_Magenta(unsigned int &makeWhite)
{
	makeWhite = 0x00FF00FF;
}
void PS_Cyan(unsigned int &makeWhite)
{
	makeWhite = 0x0000FFFF;
}

void PS_Yellow(unsigned int &makeWhite)
{
	makeWhite = 0x00FFFF00;
}

void PS_ColorBlend(unsigned int &color)
{
	unsigned  int AlphaO = (line1.Color & 0xFF000000) >> 24;
	unsigned	int RedO = (line1.Color & 0x00FF0000) >> 16;
	unsigned  int GreenO = (line1.Color & 0x0000FF00) >> 8;
	unsigned   int BlueO = (line1.Color & 0x000000FF);

	unsigned  int AlphaC = (line2.Color & 0xFF000000) >> 24;
	unsigned	int RedC = (line2.Color & 0x00FF0000) >> 16;
	unsigned  int GreenC = (line2.Color & 0x0000FF00) >> 8;
	unsigned   int BlueC = (line2.Color & 0x000000FF);

	unsigned  int AlphaF = (line3.Color & 0xFF000000) >> 24;
	unsigned	int RedF = (line3.Color & 0x00FF0000) >> 16;
	unsigned  int GreenF = (line3.Color & 0x0000FF00) >> 8;
	unsigned   int BlueF = (line3.Color & 0x000000FF);


	unsigned	int BAlpha = (unsigned int)(AlphaO * line3.z + AlphaC * line1.x + AlphaF * line2.y);
	unsigned	int BRed = (unsigned int)(RedO * line3.z + RedC * line1.x + RedF * line2.y);
	unsigned	int BGreen = (unsigned int)(GreenO * line3.z + GreenC * line1.x + GreenF * line2.y);
	unsigned	int BBlue = (unsigned int)(BlueO * line3.z + BlueC * line1.x + BlueF * line2.y);

	BAlpha = BAlpha << 24;
	BRed = BRed << 16;
	BGreen = BGreen << 8;

	color = BAlpha | BRed | BGreen | BBlue;

}