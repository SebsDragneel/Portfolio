#pragma once
#include <iostream>
#include <ctime>
#include <windows.h>
#include "RasterSurface.h"
#include "XTime.h"
#define PI 3.14159
#define RASTER_WIDTH 500
#define RASTER_HEIGHT 500
#define NUM_PIXELS (RASTER_WIDTH * RASTER_HEIGHT)
using namespace std;

unsigned int Raster[NUM_PIXELS];


struct Vertex 
{ 
	float xyzw[4]; 
	unsigned int  Color;
};
struct Point
{
	float x;
	float y;
	unsigned int  Color;
};


typedef union TMATRIX
{
	float e[16];

	struct
	{
		float _e11, _e12, _e13, _e14;
		float _e21, _e22, _e23, _e24;
		float _e31, _e32, _e33, _e34;
		float _e41, _e42, _e43, _e44;
	};
}*LPTMATRIX;





