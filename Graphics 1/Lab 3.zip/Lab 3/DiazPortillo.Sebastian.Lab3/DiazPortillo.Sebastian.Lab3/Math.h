#pragma once
#include "defines.h"

//3.	Create an array of 3 vertex structure objects,
//and define their information.Make sure to not exceed the bounds of NDC.For the color,
//make each verex a different value,
//preferable RED GREEN and BLUE.

float ImplicitLineEquation(    Point A, Point B, Point C) 
{
	float result = 0;
	result = ((A.y - B.y)*C.x) + ((B.x - A.x)*C.y) + (A.x * B.y) - (A.y * B.x);
	return result;
}



float Degrees_To_Radians(float Deg)
{
	return Deg * PI / 180.0f;
}

TMATRIX MatrixCreateRotationZ(float Deg)
{
	TMATRIX m = { cosf(Degrees_To_Radians(Deg)),-sinf(Degrees_To_Radians(Deg)), 0, 0,
				  sinf(Degrees_To_Radians(Deg)), cosf(Degrees_To_Radians(Deg)), 0, 0,
																		  0, 0, 1, 0,
																		  0, 0, 0, 1 };
	return m;
}

Vertex VectorMatrixMultiply(Vertex v, TMATRIX m)
{
	Vertex mTemp;
	mTemp.xyzw[0] = ((v.xyzw[0] * m._e11) + (v.xyzw[1] * m._e21) + (v.xyzw[2] * m._e31) + (v.xyzw[3] * m._e41));
	mTemp.xyzw[1] = ((v.xyzw[0] * m._e12) + (v.xyzw[1] * m._e22) + (v.xyzw[2] * m._e32) + (v.xyzw[3] * m._e42));
	mTemp.xyzw[2] = ((v.xyzw[0] * m._e13) + (v.xyzw[1] * m._e23) + (v.xyzw[2] * m._e33) + (v.xyzw[3] * m._e43));
	mTemp.xyzw[3] = ((v.xyzw[0] * m._e14) + (v.xyzw[1] * m._e24) + (v.xyzw[2] * m._e34) + (v.xyzw[3] * m._e44));
	return mTemp;
}


