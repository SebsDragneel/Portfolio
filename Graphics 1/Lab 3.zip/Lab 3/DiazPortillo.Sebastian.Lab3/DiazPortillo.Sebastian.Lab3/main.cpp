#include "Rasterization_Functions.h"

void main(void)
{
	float degrees = 0;
	float checktime = 0;
	XTime time;
	

	RS_Initialize(RASTER_WIDTH, RASTER_HEIGHT);


	Vertex Triangle[3];

		Triangle[0].xyzw[0] = 0.5f;
		Triangle[0].xyzw[1] = 0.0f;
		Triangle[0].xyzw[2] = -0.5f;
		Triangle[0].xyzw[3] = 0.3f;
		Triangle[0].Color = 0xFFFF0000;

		Triangle[1].xyzw[0] = 0.0f;
		Triangle[1].xyzw[1] = 0.5f;
		Triangle[1].xyzw[2] = -0.5f;
		Triangle[1].xyzw[3] = 0.2f;
		Triangle[1].Color = 0xFF00FF00;

		Triangle[2].xyzw[0] = -0.5f;
		Triangle[2].xyzw[1] = 0.0f;
		Triangle[2].xyzw[2] = -0.5f;
		Triangle[2].xyzw[3] = 0.1f;
		Triangle[2].Color = 0xFF0000FF;
			



	do
	{
		ClearBuffer();
		
		time.Signal();

		checktime = checktime + time.SmoothDelta();

		if (checktime >= (1 / 60))
		{
			degrees += 0.1f;
			checktime = 0;

		}
		
			if (degrees >= 360)
				degrees = 0;

			VertexShader = VS_World;  
			PixelShader = PS_ColorBlend; 
							
			SV_WorldMatrix = MatrixCreateRotationZ(degrees);


		
			DrawLine(Triangle[0], Triangle[1]);
			DrawLine(Triangle[1], Triangle[2]);
			DrawLine(Triangle[2], Triangle[0]);
			BruteForce(Triangle[0], Triangle[1], Triangle[2]);

	} while (RS_Update(Raster, NUM_PIXELS));

RS_Shutdown();
}
