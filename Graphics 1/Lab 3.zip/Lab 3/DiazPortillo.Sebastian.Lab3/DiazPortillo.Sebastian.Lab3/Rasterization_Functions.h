#pragma once
#include "Shaders.h"

void ClearBuffer()
{
	for (unsigned int i = 0; i < NUM_PIXELS; i++)
	{
		Raster[i] = 0x00000000;
	}
}

void DrawPixel(unsigned int x, unsigned int y, unsigned int mColor)
{
	Raster[x + y *RASTER_WIDTH] = mColor;
}


Point CartesianToScreen( Vertex ToConvert)
{
	Point point;
	float x = ToConvert.xyzw[0];
	float y = ToConvert.xyzw[1];
	unsigned int color = ToConvert.Color;

		point.x = (x + 1.0f) * (RASTER_WIDTH / 2.0f);
		point.y = (1.0f - y) * (RASTER_HEIGHT / 2.0f);
		point.Color = color;
		return point;
}


unsigned int ColorBlend(unsigned int Current, unsigned int Original, float R)
{
	unsigned  int AlphaO = (Original & 0xFF000000) >> 24;
	unsigned	int RedO = (Original & 0x00FF0000) >> 16;
	unsigned  int GreenO = (Original & 0x0000FF00) >> 8;
	unsigned   int BlueO = (Original & 0x000000FF);

	unsigned  int AlphaC = (Current & 0xFF000000) >> 24;
	unsigned	int RedC = (Current & 0x00FF0000) >> 16;
	unsigned  int GreenC = (Current & 0x0000FF00) >> 8;
	unsigned   int BlueC = (Current & 0x000000FF);




	unsigned	int BAlpha = (AlphaO - AlphaC) * R + AlphaC;
	unsigned	int BRed = (RedO - RedC) * R + RedC;
	unsigned	int BGreen = (GreenO - GreenC) * R + GreenC;
	unsigned	int BBlue = (BlueO - BlueC) * R + BlueC;

	BAlpha = BAlpha << 24;
	BRed = BRed << 16;
	BGreen = BGreen << 8;

	Current = BAlpha | BRed | BGreen | BBlue;

	return Current;
}


void DrawLine(Vertex start, Vertex end)
{
	// Copy input data and send through shaders
	Vertex copy_start = start;
	Vertex copy_end = end;
	// Use vertex shader to modify incoming copies only.
	if (VertexShader)
	{
		VertexShader(copy_start);
		VertexShader(copy_end);
	}
	// original plotting variables adapted to use new cartesian data
	Point screen_start = CartesianToScreen(copy_start);
	Point screen_end = CartesianToScreen(copy_end);

	float DeltaX = screen_end.x - screen_start.x;
	float DeltaY = screen_end.y - screen_start.y;
	float Longest = (abs(DeltaX) > abs(DeltaY)) ? abs(DeltaX) : abs(DeltaY);

	for (int i = 0; i < Longest; i++)
	{
		float r = i / (float)Longest;
		float currentX = (screen_end.x - screen_start.x) * r + screen_start.x;
		float currentY = (screen_end.y - screen_start.y) * r + screen_start.y;
		DrawPixel(currentX, currentY, 0xFFFFFFFF); /* ColorBlend(Color1, Color2, r)*/
	}
	

}

void BruteForce(Vertex l1, Vertex l2, Vertex l3)
{
	Vertex copy_line1 = l1;
	Vertex copy_line2 = l2;
	Vertex copy_line3 = l3;

	if (VertexShader)
	{
		VertexShader(copy_line1);
		VertexShader(copy_line2);
		VertexShader(copy_line3);
	}

	Point screen_line1 = CartesianToScreen(copy_line1);
	Point screen_line2 = CartesianToScreen(copy_line2);
	Point screen_line3 = CartesianToScreen(copy_line3);

	screen_line1.Color = l1.Color;
	screen_line2.Color = l2.Color;
	screen_line3.Color = l3.Color;

	float Beta = ImplicitLineEquation(screen_line1, screen_line3, screen_line2);
	float Gamma = ImplicitLineEquation(screen_line2, screen_line1, screen_line3);
	float Alpha = ImplicitLineEquation(screen_line3, screen_line2, screen_line1);

	for (int j = 0; j < RASTER_HEIGHT; j++)
	{
		for (int i = 0; i < RASTER_WIDTH; i++)
		{
			Point screenline;
			screenline.x = i;
			screenline.y = j;

			float b = ImplicitLineEquation(screen_line1, screen_line3, screenline);   
			float y = ImplicitLineEquation(screen_line2, screen_line1, screenline);   
			float a = ImplicitLineEquation(screen_line3, screen_line2, screenline); 

			Vertex ratio;

			ratio.xyzw[0] = b / Beta;
			ratio.xyzw[1] = y / Gamma;
			ratio.xyzw[2] = a / Alpha;
				

			if (ratio.xyzw[0] >= 0 && ratio.xyzw[0] <= 1 && ratio.xyzw[1] >= 0 && ratio.xyzw[1] <= 1 && ratio.xyzw[2] >= 0 && ratio.xyzw[2] <= 1)
			{
				if (PixelShader)
				{
					line1.xyzw[0] = ratio.xyzw[0];
					line2.xyzw[1] = ratio.xyzw[1];
					line3.xyzw[2] = ratio.xyzw[2];
					line1.Color = screen_line1.Color;
					line2.Color = screen_line2.Color;
					line3.Color = screen_line3.Color;


					unsigned int colors;
					PixelShader(colors);

					DrawPixel(screenline.x, screenline.y, colors);
				}
				/*else
				{

				}*/
			}

		}
	}
	
	
}